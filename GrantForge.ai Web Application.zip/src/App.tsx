import React, { useState, useEffect } from 'react';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';
import { apiRequest, supabase } from './utils/supabase/client';



// Import components
import { Dashboard } from './components/Dashboard';
import { EnhancedResearchHub } from './components/EnhancedResearchHub';
import { WritingWorkspace } from './components/WritingWorkspace';
import { KanbanBoard } from './components/KanbanBoard';
import { KPIDashboard } from './components/KPIDashboard';
import { SuperAdminDashboard } from './components/SuperAdminDashboard';
import { UserManagement } from './components/UserManagement';
import { DailyAlerts } from './components/DailyAlerts';
import { ClientIntakeForm } from './components/ClientIntakeForm';
import { ClientManagement } from './components/ClientManagement';
import { IntakeFormDemo } from './components/IntakeFormDemo';
import { SystemHealth } from './components/SystemHealth';
import { ProfileSettings } from './components/ProfileSettings';
import { SuperAdminSettings } from './components/SuperAdminSettings';
import { LoadingScreen } from './components/auth/LoadingScreen';
import { AuthScreen } from './components/auth/AuthScreen';
import { Header } from './components/layout/Header';

// Import utilities
import { checkSession, handleDemoLogin, handleLogout } from './utils/auth/authHelpers';
import { DemoAccountType } from './utils/auth/demoAccounts';
import { getRoleDisplayText } from './utils/auth/roleUtils';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'writer';
  organization: string;
  avatar?: string;
}

interface AuthForm {
  email: string;
  password: string;
  name?: string;
  role?: string;
  organization?: string;
}

export default function App() {
  
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [authForm, setAuthForm] = useState<AuthForm>({
    email: '',
    password: '',
    name: '',
    role: 'writer',
    organization: ''
  });
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  // Impersonation state - for super admin to view other users' accounts
  const [originalUser, setOriginalUser] = useState<User | null>(null);
  const [isImpersonating, setIsImpersonating] = useState(false);

  // Check for existing session on app load and set up auth listener
  useEffect(() => {
    const initSession = async () => {
      try {
        const sessionUser = await checkSession();
        setUser(sessionUser);
      } catch (error: any) {
        console.error('Failed to initialize session:', error);
        // If there's an auth error on initialization, clear any auth state
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    // Set up auth state change listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event);
      
      if (event === 'SIGNED_OUT' || event === 'TOKEN_REFRESHED') {
        if (event === 'SIGNED_OUT') {
          setUser(null);
          setOriginalUser(null);
          setIsImpersonating(false);
          setCurrentPage('dashboard');
        } else if (event === 'TOKEN_REFRESHED' && session?.user) {
          // Refresh user data when token is refreshed
          try {
            const sessionUser = await checkSession();
            if (sessionUser) {
              setUser(sessionUser);
            }
          } catch (error) {
            console.error('Error refreshing user data:', error);
          }
        }
      }
      
      if (event === 'SIGNED_IN' && session?.user && !user) {
        // Handle sign-in if user is not already set
        try {
          const sessionUser = await checkSession();
          if (sessionUser) {
            setUser(sessionUser);
          }
        } catch (error) {
          console.error('Error setting user after sign-in:', error);
        }
      }
    });

    initSession();

    // Cleanup subscription on unmount
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const onDemoLogin = async (demoType: DemoAccountType) => {
    setAuthLoading(true);
    setAuthError('');
    
    const result = await handleDemoLogin(demoType);
    if (result.user) {
      setUser(result.user);
      const roleDisplay = getRoleDisplayText(demoType);
      toast.success(`Welcome! You're now logged in as ${roleDisplay}.`);
    } else if (result.error) {
      setAuthError(result.error);
      toast.error(result.error);
    }
    
    setAuthLoading(false);
  };

  const onAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError('');

    try {
      if (authMode === 'login') {
        const { data: { session }, error } = await supabase.auth.signInWithPassword({
          email: authForm.email,
          password: authForm.password,
        });

        if (error) {
          console.error('Login error:', error);
          
          if (error.message.includes('Invalid login credentials')) {
            setAuthError('Invalid email or password. Please check your credentials or sign up for a new account.');
            toast.error('Invalid email or password. Please check your credentials or try a demo account.');
            setTimeout(() => {
              setAuthMode('signup');
              setAuthForm(prev => ({ ...prev, password: '' })); // Clear password for security
            }, 3000);
          } else if (error.message.includes('refresh') || error.message.includes('token')) {
            // Handle refresh token errors during login
            setAuthError('Session expired. Please try logging in again.');
            toast.error('Session expired. Please try again.');
            // Clear any stale auth data
            try {
              await supabase.auth.signOut({ scope: 'local' });
            } catch (e) {
              // Ignore errors
            }
          } else {
            setAuthError(error.message);
            toast.error(error.message);
          }
          return;
        }

        if (session?.user) {
          try {
            const profile = await apiRequest('/auth/profile');
            setUser({
              id: session.user.id,
              name: profile.profile?.name || session.user.user_metadata?.name || 'User',
              email: session.user.email || '',
              role: profile.profile?.role || session.user.user_metadata?.role || 'writer',
              organization: profile.profile?.organization || session.user.user_metadata?.organization || 'Unknown',
              avatar: profile.profile?.avatar || session.user.user_metadata?.avatar
            });
          } catch (profileError) {
            setUser({
              id: session.user.id,
              name: session.user.user_metadata?.name || 'User',
              email: session.user.email || '',
              role: session.user.user_metadata?.role || 'writer',
              organization: session.user.user_metadata?.organization || 'Unknown',
              avatar: session.user.user_metadata?.avatar
            });
          }
          toast.success('Logged in successfully!');
        }
      } else {
        // Sign up
        if (!authForm.name || !authForm.organization) {
          setAuthError('Please fill in all required fields');
          toast.error('Please fill in all required fields');
          return;
        }

        if (authForm.password.length < 6) {
          setAuthError('Password must be at least 6 characters');
          toast.error('Password must be at least 6 characters');
          return;
        }

        try {
          const response = await apiRequest('/auth/signup', {
            method: 'POST',
            body: JSON.stringify({
              email: authForm.email,
              password: authForm.password,
              name: authForm.name,
              role: authForm.role,
              organization: authForm.organization
            })
          });

          if (response.user) {
            const { data: { session }, error } = await supabase.auth.signInWithPassword({
              email: authForm.email,
              password: authForm.password,
            });

            if (error) {
              toast.error('Account created but login failed. Please try logging in manually.');
              setAuthMode('login');
              setAuthForm(prev => ({ ...prev, name: '', organization: '' }));
              return;
            }

            if (session?.user) {
              setUser({
                id: session.user.id,
                name: authForm.name!,
                email: authForm.email,
                role: authForm.role as any,
                organization: authForm.organization!,
                avatar: session.user.user_metadata?.avatar
              });
              toast.success('Account created and logged in successfully!');
            }
          }
        } catch (signupError: any) {
          console.error('Signup error:', signupError);
          
          // Handle different error formats from the API
          const errorMessage = signupError.message || signupError.error || 'Failed to create account';
          const errorCode = signupError.code;
          
          // Check for email already exists error
          if (errorCode === 'EMAIL_ALREADY_EXISTS' || 
              errorMessage.includes('already been registered') || 
              errorMessage.includes('User already registered') ||
              errorMessage.includes('already exists')) {
            setAuthError('An account with this email already exists. Please sign in instead.');
            toast.error('Account already exists with this email. Switching to sign in...');
            setTimeout(() => {
              setAuthMode('login');
              setAuthForm(prev => ({ 
                ...prev, 
                name: '', 
                organization: '', 
                role: 'writer',
                password: '' // Clear password for security
              }));
              setAuthError(''); // Clear error when switching modes
            }, 2000);
          } else {
            setAuthError(errorMessage);
            toast.error(errorMessage);
          }
        }
      }
    } catch (error: any) {
      console.error('Auth error:', error);
      const errorMessage = error.message || 'Authentication failed';
      setAuthError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setAuthLoading(false);
    }
  };

  const onLogout = async () => {
    const result = await handleLogout();
    if (result.success) {
      setUser(null);
      setOriginalUser(null);
      setIsImpersonating(false);
      setCurrentPage('dashboard');
      setAuthError('');
      toast.success('Logged out successfully');
    } else {
      toast.error(result.error || 'Error logging out');
    }
  };

  const onToggleMode = () => {
    const newMode = authMode === 'login' ? 'signup' : 'login';
    setAuthMode(newMode);
    setAuthForm({ email: '', password: '', name: '', role: 'writer', organization: '' });
    setAuthError('');
    
    // Show helpful message when switching modes
    if (newMode === 'login') {
      toast.info('Already have an account? Welcome back!');
    } else {
      toast.info('New to GrantForge.ai? Let\'s get you set up!');
    }
  };

  // Impersonation functions
  const onImpersonate = (targetUser: User) => {
    if (user?.role === 'super-admin' && !isImpersonating) {
      setOriginalUser(user);
      setUser(targetUser);
      setIsImpersonating(true);
      setCurrentPage('dashboard');
      toast.success(`Now viewing as ${targetUser.name} (${targetUser.role})`);
    }
  };

  const onStopImpersonating = () => {
    if (isImpersonating && originalUser) {
      setUser(originalUser);
      setOriginalUser(null);
      setIsImpersonating(false);
      setCurrentPage('users');
      toast.success('Returned to Super Admin view');
    }
  };

  // Show loading screen while checking session
  if (loading) {
    return (
      <LoadingScreen 
        message="Loading your dashboard..."
      />
    );
  }

  // Show authentication screen if not logged in
  if (!user) {
    return (
      <AuthScreen
        authMode={authMode}
        authForm={authForm}
        setAuthForm={setAuthForm}
        onAuth={onAuth}
        onDemoLogin={onDemoLogin}
        authLoading={authLoading}
        authError={authError}
        onToggleMode={onToggleMode}
      />
    );
  }

  // Role-based navigation with clear separation of responsibilities
  const getNavigation = () => {
    if (user.role === 'super-admin' && !isImpersonating) {
      // Super Admin: Platform administration only
      return [
        { id: 'dashboard', label: 'Dashboard', roles: ['super-admin'] },
        { id: 'users', label: 'User Management', roles: ['super-admin'] },
        { id: 'system', label: 'System Health', roles: ['super-admin'] },
        { id: 'settings', label: 'Platform Settings', roles: ['super-admin'] },
      ];
    } else {
      // Grant-focused roles with appropriate permissions
      return [
        // Core grant functionality - available to all grant roles
        { id: 'dashboard', label: 'Dashboard', roles: ['admin', 'writer'] },
        { id: 'research', label: 'Research Hub', roles: ['admin', 'writer'] },
        { id: 'writing', label: 'Writing & Collaboration', roles: ['admin', 'writer'] },
        { id: 'kanban', label: 'Grant Pipeline', roles: ['admin', 'writer'] },
        { id: 'alerts', label: 'Daily Alerts', roles: ['admin', 'writer'] },
        
        // Administrative functions - admin only
        { id: 'clients', label: 'Client Management', roles: ['admin'] },
        { id: 'intake', label: 'Client Intake', roles: ['admin'] },
        { id: 'kpi', label: 'Team Analytics', roles: ['admin'] },
      ];
    }
  };

  const navigation = getNavigation().filter(item => item.roles.includes(user.role));

  const renderPage = () => {
    // Profile settings - accessible to all users
    if (currentPage === 'profile') {
      return <ProfileSettings user={user} onUserUpdate={setUser} onNavigate={setCurrentPage} />;
    }

    // Super Admin pages (when not impersonating)
    if (user.role === 'super-admin' && !isImpersonating) {
      switch (currentPage) {
        case 'dashboard':
          return <SuperAdminDashboard user={user} />;
        case 'users':
          return <UserManagement user={user} onImpersonate={onImpersonate} />;
        case 'system':
          return <SystemHealth user={user} />;
        case 'settings':
          return <SuperAdminSettings user={user} onNavigate={setCurrentPage} />;
        default:
          return <SuperAdminDashboard user={user} />;
      }
    }

    // Grant-focused roles (including when super admin is impersonating)
    switch (currentPage) {
      // Core grant functionality - accessible to all grant roles
      case 'dashboard':
        return <Dashboard user={user} onNavigate={setCurrentPage} />;
      case 'research':
        return <EnhancedResearchHub user={user} onNavigate={setCurrentPage} />;
      case 'writing':
        return <WritingWorkspace user={user} onNavigate={setCurrentPage} />;
      case 'kanban':
        return <KanbanBoard user={user} onNavigate={setCurrentPage} />;
      case 'alerts':
        return <DailyAlerts user={user} onNavigate={setCurrentPage} />;
      
      // Administrative functions - admin only (with fallback to dashboard)
      case 'clients':
        return user.role === 'admin' ? <ClientManagement user={user} /> : <Dashboard user={user} onNavigate={setCurrentPage} />;
      case 'intake':
        return user.role === 'admin' ? <IntakeFormDemo user={user} /> : <Dashboard user={user} onNavigate={setCurrentPage} />;
      case 'kpi':
        return user.role === 'admin' ? <KPIDashboard user={user} /> : <Dashboard user={user} onNavigate={setCurrentPage} />;
      
      default:
        return <Dashboard user={user} onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header 
        user={user}
        currentPage={currentPage}
        navigation={navigation}
        onNavigate={setCurrentPage}
        onLogout={onLogout}
        isImpersonating={isImpersonating}
        originalUser={originalUser}
        onStopImpersonating={onStopImpersonating}
      />
      <main className="min-h-[calc(100vh-73px)]">
        {renderPage()}
      </main>
      <Toaster />
    </div>
  );
}