export interface GrantSource {
  id: string;
  name: string;
  description: string;
  baseUrl: string;
  apiKey?: string;
  enabled: boolean;
  priority: number; // Higher priority sources are preferred for deduplication
  rateLimitPerMinute: number;
  lastUpdated?: string;
}

export interface RawGrantData {
  source: string;
  sourceId: string;
  rawData: any;
  fetchedAt: string;
}

export interface NormalizedGrant {
  // Unique identifier across all sources
  id: string;
  
  // Core grant information
  title: string;
  description: string;
  summary?: string;
  
  // Funding details
  funder: string;
  fundingAgency: string;
  amount: string;
  amountMin?: number;
  amountMax?: number;
  totalFunding?: string;
  
  // Dates and deadlines
  deadline: string;
  applicationDueDate?: string;
  noticeOfIntentDeadline?: string;
  projectStartDate?: string;
  projectEndDate?: string;
  
  // Classification
  category: string;
  subcategory?: string;
  cfda?: string;
  opportunityNumber: string;
  programNumber?: string;
  
  // Eligibility and requirements
  eligibility: string[];
  eligibilityCriteria?: string;
  matchRequired: boolean;
  matchPercentage?: number;
  
  // Geographic scope
  location: string;
  geographicScope: 'National' | 'Regional' | 'State' | 'Local' | 'Tribal';
  restrictedStates?: string[];
  
  // Application details
  applicationProcess?: string;
  requiredDocuments?: string[];
  contactInfo?: {
    name?: string;
    email?: string;
    phone?: string;
    address?: string;
  };
  
  // Classification metadata
  tags: string[];
  keywords: string[];
  difficulty: 'Easy' | 'Medium' | 'Hard';
  competitionLevel: 'Low' | 'Medium' | 'High';
  
  // Source information
  sources: {
    source: string;
    sourceId: string;
    sourceUrl: string;
    confidence: number; // 0-1 confidence in data quality
    lastUpdated: string;
  }[];
  
  // Status and metadata
  status: 'Open' | 'Closed' | 'Archived' | 'Upcoming';
  isNew: boolean;
  isFeatured: boolean;
  lastUpdated: string;
  
  // User interaction
  saved?: boolean;
  viewed?: boolean;
  applied?: boolean;
  notes?: string;
  
  // Computed fields
  daysUntilDeadline?: number;
  relevanceScore?: number;
  matchScore?: number;
}

export interface SearchFilters {
  keyword?: string;
  category?: string;
  agency?: string;
  eligibility?: string[];
  location?: string;
  amountMin?: number;
  amountMax?: number;
  deadline?: {
    min?: string;
    max?: string;
  };
  sources?: string[];
  difficulty?: string[];
  status?: string[];
  tags?: string[];
  includeExpired?: boolean;
  sortBy?: 'relevance' | 'deadline' | 'amount' | 'updated';
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export interface SearchResult {
  grants: NormalizedGrant[];
  total: number;
  sources: {
    [sourceId: string]: {
      count: number;
      status: 'success' | 'error' | 'timeout';
      error?: string;
      fetchTime: number;
    };
  };
  searchTime: number;
  cached: boolean;
  filters: SearchFilters;
  suggestions?: string[];
}

export interface DeduplicationRule {
  fields: string[];
  threshold: number;
  strategy: 'exact' | 'fuzzy' | 'semantic';
}

export class SearchService {
  private sources: Map<string, GrantSource> = new Map();
  private cache: Map<string, { result: SearchResult; expires: number }> = new Map();
  private rateLimit: Map<string, { count: number; resetTime: number }> = new Map();
  
  constructor() {
    this.initializeSources();
  }

  private initializeSources() {
    const sources: GrantSource[] = [
      {
        id: 'grants-gov',
        name: 'Grants.gov',
        description: 'Federal grant opportunities from all agencies',
        baseUrl: 'https://api.grants.gov/v1/api',
        enabled: true,
        priority: 10,
        rateLimitPerMinute: 60
      },
      {
        id: 'sam-gov',
        name: 'SAM.gov',
        description: 'System for Award Management - federal procurement and grants',
        baseUrl: 'https://api.sam.gov/prod/opportunities/v2',
        enabled: true,
        priority: 9,
        rateLimitPerMinute: 30
      },
      {
        id: 'schoolsafety-gov',
        name: 'SchoolSafety.gov',
        description: 'School safety and security grant opportunities',
        baseUrl: 'https://www.schoolsafety.gov/api',
        enabled: true,
        priority: 7,
        rateLimitPerMinute: 20
      },
      {
        id: 'candid',
        name: 'Candid (Foundation Center)',
        description: 'Foundation and private funding opportunities',
        baseUrl: 'https://api.candid.org/v1',
        enabled: true,
        priority: 8,
        rateLimitPerMinute: 15
      },
      {
        id: 'grantwatch',
        name: 'GrantWatch',
        description: 'Comprehensive grant database including state and local opportunities',
        baseUrl: 'https://api.grantwatch.com/v1',
        enabled: true,
        priority: 6,
        rateLimitPerMinute: 25
      },
      {
        id: 'state-doe',
        name: 'State DOE Aggregator',
        description: 'Aggregated state department of education grants',
        baseUrl: 'https://api.stategrants.edu/v1',
        enabled: true,
        priority: 5,
        rateLimitPerMinute: 40
      }
    ];

    sources.forEach(source => this.sources.set(source.id, source));
  }

  async search(filters: SearchFilters): Promise<SearchResult> {
    const startTime = Date.now();
    const cacheKey = this.generateCacheKey(filters);
    
    // Check cache first
    const cached = this.getFromCache(cacheKey);
    if (cached) {
      return { ...cached, cached: true };
    }

    // Determine which sources to search
    const sourcesToSearch = this.getEnabledSources(filters.sources);
    
    // Execute parallel searches with rate limiting
    const searchPromises = sourcesToSearch.map(source => 
      this.searchSource(source, filters)
    );

    const sourceResults = await Promise.allSettled(searchPromises);
    
    // Collect results and handle errors
    const allGrants: NormalizedGrant[] = [];
    const sourceStats: SearchResult['sources'] = {};

    sourceResults.forEach((result, index) => {
      const source = sourcesToSearch[index];
      const fetchTime = Date.now() - startTime;

      if (result.status === 'fulfilled') {
        allGrants.push(...result.value.grants);
        sourceStats[source.id] = {
          count: result.value.grants.length,
          status: 'success',
          fetchTime
        };
      } else {
        sourceStats[source.id] = {
          count: 0,
          status: 'error',
          error: result.reason?.message || 'Unknown error',
          fetchTime
        };
      }
    });

    // Normalize and deduplicate
    const normalizedGrants = await this.normalizeGrants(allGrants);
    const deduplicatedGrants = await this.deduplicateGrants(normalizedGrants);
    
    // Apply final filtering and sorting
    const filteredGrants = this.applyClientSideFilters(deduplicatedGrants, filters);
    const sortedGrants = this.sortGrants(filteredGrants, filters);
    
    // Paginate results
    const paginatedGrants = this.paginateResults(sortedGrants, filters);

    const searchResult: SearchResult = {
      grants: paginatedGrants,
      total: sortedGrants.length,
      sources: sourceStats,
      searchTime: Date.now() - startTime,
      cached: false,
      filters,
      suggestions: await this.generateSearchSuggestions(filters, sortedGrants)
    };

    // Cache the result
    this.setCache(cacheKey, searchResult);

    return searchResult;
  }

  private async searchSource(source: GrantSource, filters: SearchFilters): Promise<{ grants: NormalizedGrant[] }> {
    // Check rate limit
    if (!this.checkRateLimit(source.id)) {
      throw new Error(`Rate limit exceeded for ${source.name}`);
    }

    switch (source.id) {
      case 'grants-gov':
        return this.searchGrantsGov(filters);
      case 'sam-gov':
        return this.searchSamGov(filters);
      case 'schoolsafety-gov':
        return this.searchSchoolSafetyGov(filters);
      case 'candid':
        return this.searchCandid(filters);
      case 'grantwatch':
        return this.searchGrantWatch(filters);
      case 'state-doe':
        return this.searchStateDOE(filters);
      default:
        throw new Error(`Unknown source: ${source.id}`);
    }
  }

  private async searchGrantsGov(filters: SearchFilters): Promise<{ grants: NormalizedGrant[] }> {
    // Use existing Grants.gov implementation from the backend
    const response = await fetch('/api/grants/search?' + new URLSearchParams({
      keyword: filters.keyword || '',
      category: filters.category || '',
      agency: filters.agency || '',
      limit: (filters.limit || 50).toString()
    }));

    if (!response.ok) {
      throw new Error('Grants.gov search failed');
    }

    const data = await response.json();
    return {
      grants: data.grants.map((grant: any) => this.normalizeGrantsGovData(grant))
    };
  }

  private async searchSamGov(filters: SearchFilters): Promise<{ grants: NormalizedGrant[] }> {
    // SAM.gov typically requires authentication, so this would be a mock implementation
    // In a real implementation, you'd need to register for API access
    return {
      grants: this.generateMockSamGovData(filters)
    };
  }

  private async searchSchoolSafetyGov(filters: SearchFilters): Promise<{ grants: NormalizedGrant[] }> {
    // SchoolSafety.gov mock implementation
    // Focus on safety and security related grants
    return {
      grants: this.generateMockSchoolSafetyData(filters)
    };
  }

  private async searchCandid(filters: SearchFilters): Promise<{ grants: NormalizedGrant[] }> {
    // Candid (Foundation Center) mock implementation
    // Focus on foundation and private funding
    return {
      grants: this.generateMockCandidData(filters)
    };
  }

  private async searchGrantWatch(filters: SearchFilters): Promise<{ grants: NormalizedGrant[] }> {
    // GrantWatch mock implementation
    // Comprehensive database including state and local
    return {
      grants: this.generateMockGrantWatchData(filters)
    };
  }

  private async searchStateDOE(filters: SearchFilters): Promise<{ grants: NormalizedGrant[] }> {
    // State DOE aggregator mock implementation
    // State-specific education grants
    return {
      grants: this.generateMockStateDOEData(filters)
    };
  }

  private normalizeGrantsGovData(grant: any): NormalizedGrant {
    return {
      id: `grants-gov-${grant.id}`,
      title: grant.title || 'Untitled Grant',
      description: grant.description || '',
      funder: grant.funder || 'Unknown Agency',
      fundingAgency: grant.funder || 'Unknown Agency',
      amount: grant.amount || 'Amount TBD',
      deadline: grant.deadline || '',
      category: grant.category || 'General',
      eligibility: Array.isArray(grant.eligibility) ? grant.eligibility : [grant.eligibility || 'See opportunity details'],
      matchRequired: grant.matchRequired || false,
      location: grant.location || 'National',
      geographicScope: 'National',
      tags: grant.tags || [],
      keywords: this.extractKeywords(grant.title + ' ' + grant.description),
      difficulty: this.assessDifficulty(grant),
      competitionLevel: 'Medium',
      sources: [{
        source: 'grants-gov',
        sourceId: grant.id,
        sourceUrl: grant.link || '',
        confidence: 0.9,
        lastUpdated: grant.lastUpdated || new Date().toISOString()
      }],
      status: this.normalizeStatus(grant.status || 'Open'),
      isNew: grant.isNew || false,
      isFeatured: false,
      lastUpdated: grant.lastUpdated || new Date().toISOString(),
      opportunityNumber: grant.opportunityNumber || '',
      cfda: grant.cfda || ''
    };
  }

  private generateMockSamGovData(filters: SearchFilters): NormalizedGrant[] {
    // Mock SAM.gov data focusing on federal procurement and larger grants
    const baseGrants = [
      {
        title: 'Infrastructure Investment and Jobs Act Education Grants',
        funder: 'Department of Transportation',
        amount: '$10,000,000',
        category: 'Infrastructure',
        description: 'Funding for educational infrastructure improvements including technology and safety upgrades.'
      },
      {
        title: 'STEM Education Partnership Grants',
        funder: 'Department of Commerce',
        amount: '$2,500,000',
        category: 'STEM Education',
        description: 'Public-private partnerships to enhance STEM education in underserved communities.'
      }
    ];

    return baseGrants.map((grant, index) => ({
      id: `sam-gov-${Date.now()}-${index}`,
      title: grant.title,
      description: grant.description,
      funder: grant.funder,
      fundingAgency: grant.funder,
      amount: grant.amount,
      deadline: new Date(Date.now() + (30 + index * 15) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      category: grant.category,
      eligibility: ['State governments', 'Local governments', 'Public schools'],
      matchRequired: true,
      matchPercentage: 25,
      location: 'National',
      geographicScope: 'National' as const,
      tags: ['Federal', 'Infrastructure', grant.category],
      keywords: this.extractKeywords(grant.title + ' ' + grant.description),
      difficulty: 'Hard' as const,
      competitionLevel: 'High' as const,
      sources: [{
        source: 'sam-gov',
        sourceId: `sam-${index}`,
        sourceUrl: `https://sam.gov/opportunity/${index}`,
        confidence: 0.85,
        lastUpdated: new Date().toISOString()
      }],
      status: 'Open' as const,
      isNew: index === 0,
      isFeatured: index === 0,
      lastUpdated: new Date().toISOString(),
      opportunityNumber: `SAM-2024-${String(index + 1).padStart(3, '0')}`
    }));
  }

  private generateMockSchoolSafetyData(filters: SearchFilters): NormalizedGrant[] {
    const baseGrants = [
      {
        title: 'School Safety Infrastructure Grants',
        funder: 'Department of Homeland Security',
        amount: '$500,000',
        category: 'School Safety',
        description: 'Funding for physical security improvements including access control and emergency communications.'
      },
      {
        title: 'Mental Health and Crisis Response Program',
        funder: 'Department of Health and Human Services',
        amount: '$750,000',
        category: 'Mental Health',
        description: 'Support for school-based mental health services and crisis intervention programs.'
      }
    ];

    return baseGrants.map((grant, index) => ({
      id: `schoolsafety-gov-${Date.now()}-${index}`,
      title: grant.title,
      description: grant.description,
      funder: grant.funder,
      fundingAgency: grant.funder,
      amount: grant.amount,
      deadline: new Date(Date.now() + (45 + index * 20) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      category: grant.category,
      eligibility: ['Public K-12 schools', 'School districts', 'Charter schools'],
      matchRequired: false,
      location: 'National',
      geographicScope: 'National' as const,
      tags: ['Safety', 'Security', 'K-12'],
      keywords: this.extractKeywords(grant.title + ' ' + grant.description),
      difficulty: 'Medium' as const,
      competitionLevel: 'Medium' as const,
      sources: [{
        source: 'schoolsafety-gov',
        sourceId: `ss-${index}`,
        sourceUrl: `https://schoolsafety.gov/grants/${index}`,
        confidence: 0.8,
        lastUpdated: new Date().toISOString()
      }],
      status: 'Open' as const,
      isNew: false,
      isFeatured: false,
      lastUpdated: new Date().toISOString(),
      opportunityNumber: `SS-2024-${String(index + 1).padStart(3, '0')}`
    }));
  }

  private generateMockCandidData(filters: SearchFilters): NormalizedGrant[] {
    const baseGrants = [
      {
        title: 'Gates Foundation Education Innovation Grant',
        funder: 'Bill & Melinda Gates Foundation',
        amount: '$1,000,000',
        category: 'Education Innovation',
        description: 'Supporting innovative approaches to improve educational outcomes for underserved students.'
      },
      {
        title: 'Walton Family Foundation Charter School Growth',
        funder: 'Walton Family Foundation',
        amount: '$300,000',
        category: 'Charter Schools',
        description: 'Funding to support the growth and sustainability of high-quality charter schools.'
      }
    ];

    return baseGrants.map((grant, index) => ({
      id: `candid-${Date.now()}-${index}`,
      title: grant.title,
      description: grant.description,
      funder: grant.funder,
      fundingAgency: grant.funder,
      amount: grant.amount,
      deadline: new Date(Date.now() + (60 + index * 30) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      category: grant.category,
      eligibility: ['Nonprofit organizations', 'Public schools', 'Educational institutions'],
      matchRequired: false,
      location: 'National',
      geographicScope: 'National' as const,
      tags: ['Foundation', 'Private Funding', grant.category],
      keywords: this.extractKeywords(grant.title + ' ' + grant.description),
      difficulty: 'Medium' as const,
      competitionLevel: 'High' as const,
      sources: [{
        source: 'candid',
        sourceId: `candid-${index}`,
        sourceUrl: `https://candid.org/grants/${index}`,
        confidence: 0.75,
        lastUpdated: new Date().toISOString()
      }],
      status: 'Open' as const,
      isNew: index === 1,
      isFeatured: index === 0,
      lastUpdated: new Date().toISOString(),
      opportunityNumber: `CAND-2024-${String(index + 1).padStart(3, '0')}`
    }));
  }

  private generateMockGrantWatchData(filters: SearchFilters): NormalizedGrant[] {
    const baseGrants = [
      {
        title: 'Texas Education Agency STEM Innovation Grant',
        funder: 'Texas Education Agency',
        amount: '$150,000',
        category: 'STEM Education',
        description: 'State funding for innovative STEM programs in Texas public schools.',
        location: 'Texas'
      },
      {
        title: 'California Arts in Education Initiative',
        funder: 'California Department of Education',
        amount: '$200,000',
        category: 'Arts Education',
        description: 'Supporting arts integration in California K-12 schools.',
        location: 'California'
      }
    ];

    return baseGrants.map((grant, index) => ({
      id: `grantwatch-${Date.now()}-${index}`,
      title: grant.title,
      description: grant.description,
      funder: grant.funder,
      fundingAgency: grant.funder,
      amount: grant.amount,
      deadline: new Date(Date.now() + (20 + index * 10) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      category: grant.category,
      eligibility: ['Public schools', 'School districts', 'Educational nonprofits'],
      matchRequired: true,
      matchPercentage: 10,
      location: grant.location,
      geographicScope: 'State' as const,
      restrictedStates: [grant.location],
      tags: ['State Funding', grant.category, grant.location],
      keywords: this.extractKeywords(grant.title + ' ' + grant.description),
      difficulty: 'Easy' as const,
      competitionLevel: 'Low' as const,
      sources: [{
        source: 'grantwatch',
        sourceId: `gw-${index}`,
        sourceUrl: `https://grantwatch.com/grant/${index}`,
        confidence: 0.7,
        lastUpdated: new Date().toISOString()
      }],
      status: 'Open' as const,
      isNew: true,
      isFeatured: false,
      lastUpdated: new Date().toISOString(),
      opportunityNumber: `GW-${grant.location.substring(0, 2).toUpperCase()}-2024-${String(index + 1).padStart(3, '0')}`
    }));
  }

  private generateMockStateDOEData(filters: SearchFilters): NormalizedGrant[] {
    const states = ['New York', 'Florida', 'Illinois', 'Pennsylvania', 'Ohio'];
    const baseGrants = states.map((state, index) => ({
      title: `${state} Every Student Succeeds Act Implementation`,
      funder: `${state} Department of Education`,
      amount: '$400,000',
      category: 'ESSA Implementation',
      description: `State funding to support ESSA compliance and improvement initiatives in ${state} schools.`,
      location: state
    }));

    return baseGrants.map((grant, index) => ({
      id: `state-doe-${Date.now()}-${index}`,
      title: grant.title,
      description: grant.description,
      funder: grant.funder,
      fundingAgency: grant.funder,
      amount: grant.amount,
      deadline: new Date(Date.now() + (35 + index * 7) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      category: grant.category,
      eligibility: ['Public school districts', 'Charter schools', 'Educational service agencies'],
      matchRequired: false,
      location: grant.location,
      geographicScope: 'State' as const,
      restrictedStates: [grant.location],
      tags: ['State DOE', 'ESSA', grant.location],
      keywords: this.extractKeywords(grant.title + ' ' + grant.description),
      difficulty: 'Medium' as const,
      competitionLevel: 'Medium' as const,
      sources: [{
        source: 'state-doe',
        sourceId: `doe-${index}`,
        sourceUrl: `https://${grant.location.toLowerCase().replace(' ', '')}.gov/education/grants/${index}`,
        confidence: 0.8,
        lastUpdated: new Date().toISOString()
      }],
      status: 'Open' as const,
      isNew: index < 2,
      isFeatured: false,
      lastUpdated: new Date().toISOString(),
      opportunityNumber: `${grant.location.substring(0, 2).toUpperCase()}DOE-2024-${String(index + 1).padStart(3, '0')}`
    }));
  }

  private async normalizeGrants(grants: NormalizedGrant[]): Promise<NormalizedGrant[]> {
    return grants.map(grant => ({
      ...grant,
      // Normalize common fields
      title: this.normalizeTitle(grant.title),
      description: this.normalizeDescription(grant.description),
      amount: this.normalizeAmount(grant.amount),
      deadline: this.normalizeDate(grant.deadline),
      category: this.normalizeCategory(grant.category),
      eligibility: this.normalizeEligibility(grant.eligibility),
      tags: this.normalizeTags(grant.tags),
      daysUntilDeadline: this.calculateDaysUntilDeadline(grant.deadline)
    }));
  }

  private async deduplicateGrants(grants: NormalizedGrant[]): Promise<NormalizedGrant[]> {
    const deduplicationRules: DeduplicationRule[] = [
      { fields: ['title', 'funder'], threshold: 0.9, strategy: 'fuzzy' },
      { fields: ['opportunityNumber'], threshold: 1.0, strategy: 'exact' },
      { fields: ['title', 'deadline', 'amount'], threshold: 0.8, strategy: 'fuzzy' }
    ];

    const groups = this.groupSimilarGrants(grants, deduplicationRules);
    const deduplicated = groups.map(group => this.mergeGrantGroup(group));
    
    return deduplicated.sort((a, b) => b.sources.length - a.sources.length);
  }

  private groupSimilarGrants(grants: NormalizedGrant[], rules: DeduplicationRule[]): NormalizedGrant[][] {
    const groups: NormalizedGrant[][] = [];
    const processed = new Set<string>();

    grants.forEach(grant => {
      if (processed.has(grant.id)) return;

      const similarGrants = [grant];
      processed.add(grant.id);

      grants.forEach(otherGrant => {
        if (processed.has(otherGrant.id)) return;

        const similarity = this.calculateSimilarity(grant, otherGrant, rules);
        if (similarity > 0.8) {
          similarGrants.push(otherGrant);
          processed.add(otherGrant.id);
        }
      });

      groups.push(similarGrants);
    });

    return groups;
  }

  private calculateSimilarity(grant1: NormalizedGrant, grant2: NormalizedGrant, rules: DeduplicationRule[]): number {
    let maxSimilarity = 0;

    rules.forEach(rule => {
      const similarity = this.calculateFieldSimilarity(grant1, grant2, rule);
      maxSimilarity = Math.max(maxSimilarity, similarity);
    });

    return maxSimilarity;
  }

  private calculateFieldSimilarity(grant1: NormalizedGrant, grant2: NormalizedGrant, rule: DeduplicationRule): number {
    const values1 = rule.fields.map(field => (grant1 as any)[field]?.toString().toLowerCase() || '');
    const values2 = rule.fields.map(field => (grant2 as any)[field]?.toString().toLowerCase() || '');

    if (rule.strategy === 'exact') {
      return values1.every((val, idx) => val === values2[idx]) ? 1.0 : 0.0;
    }

    // Fuzzy string similarity (simplified Jaro-Winkler-like)
    const combined1 = values1.join(' ');
    const combined2 = values2.join(' ');
    
    return this.fuzzyStringSimilarity(combined1, combined2);
  }

  private fuzzyStringSimilarity(str1: string, str2: string): number {
    if (str1 === str2) return 1.0;
    if (str1.length === 0 || str2.length === 0) return 0.0;

    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;

    if (longer.length === 0) return 1.0;

    const editDistance = this.levenshteinDistance(str1, str2);
    return (longer.length - editDistance) / longer.length;
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));

    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;

    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const substitutionCost = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          matrix[j - 1][i] + 1,
          matrix[j - 1][i - 1] + substitutionCost
        );
      }
    }

    return matrix[str2.length][str1.length];
  }

  private mergeGrantGroup(grants: NormalizedGrant[]): NormalizedGrant {
    if (grants.length === 1) return grants[0];

    // Sort by source priority and confidence
    const sortedGrants = grants.sort((a, b) => {
      const aSource = this.sources.get(a.sources[0].source);
      const bSource = this.sources.get(b.sources[0].source);
      
      if (aSource && bSource) {
        if (aSource.priority !== bSource.priority) {
          return bSource.priority - aSource.priority;
        }
        return b.sources[0].confidence - a.sources[0].confidence;
      }
      
      return 0;
    });

    const primary = sortedGrants[0];
    const allSources = grants.flatMap(g => g.sources);

    return {
      ...primary,
      sources: allSources,
      // Merge tags and keywords
      tags: [...new Set(grants.flatMap(g => g.tags))],
      keywords: [...new Set(grants.flatMap(g => g.keywords))],
      // Use the most recent update
      lastUpdated: grants.reduce((latest, grant) => 
        grant.lastUpdated > latest ? grant.lastUpdated : latest, 
        grants[0].lastUpdated
      )
    };
  }

  // Utility methods for normalization
  private normalizeTitle(title: string): string {
    return title.trim().replace(/\s+/g, ' ');
  }

  private normalizeDescription(description: string): string {
    return description.trim().replace(/\s+/g, ' ').substring(0, 500);
  }

  private normalizeAmount(amount: string): string {
    // Extract numbers and format consistently
    const numbers = amount.match(/[\d,]+/g);
    if (numbers) {
      const num = parseInt(numbers[0].replace(/,/g, ''));
      return `$${num.toLocaleString()}`;
    }
    return amount;
  }

  private normalizeDate(date: string): string {
    try {
      return new Date(date).toISOString().split('T')[0];
    } catch {
      return date;
    }
  }

  private normalizeCategory(category: string): string {
    const categoryMap: { [key: string]: string } = {
      'stem education': 'STEM Education',
      'stem': 'STEM Education',
      'science education': 'STEM Education',
      'teacher training': 'Teacher Quality',
      'professional development': 'Teacher Quality',
      'school safety': 'School Safety',
      'safety': 'School Safety',
      'infrastructure': 'Infrastructure',
      'technology': 'Technology',
      'arts': 'Arts Education',
      'arts education': 'Arts Education'
    };

    const normalized = category.toLowerCase();
    return categoryMap[normalized] || category;
  }

  private normalizeEligibility(eligibility: string[]): string[] {
    const eligibilityMap: { [key: string]: string } = {
      'public schools': 'Public Schools',
      'public school': 'Public Schools',
      'school districts': 'School Districts',
      'school district': 'School Districts',
      'charter schools': 'Charter Schools',
      'charter school': 'Charter Schools',
      'nonprofits': 'Nonprofit Organizations',
      'nonprofit': 'Nonprofit Organizations',
      'state governments': 'State Governments',
      'local governments': 'Local Governments'
    };

    return eligibility.map(item => {
      const normalized = item.toLowerCase();
      return eligibilityMap[normalized] || item;
    });
  }

  private normalizeTags(tags: string[]): string[] {
    return [...new Set(tags.map(tag => tag.trim()).filter(Boolean))];
  }

  private calculateDaysUntilDeadline(deadline: string): number {
    try {
      const deadlineDate = new Date(deadline);
      const today = new Date();
      const diffTime = deadlineDate.getTime() - today.getTime();
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    } catch {
      return -1;
    }
  }

  private extractKeywords(text: string): string[] {
    // Simple keyword extraction
    const stopWords = new Set(['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should']);
    
    return text
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 3 && !stopWords.has(word))
      .slice(0, 10);
  }

  private assessDifficulty(grant: any): 'Easy' | 'Medium' | 'Hard' {
    let score = 0;
    
    // Amount-based difficulty
    const amount = parseInt(grant.amount?.replace(/[^\d]/g, '') || '0');
    if (amount > 1000000) score += 3;
    else if (amount > 100000) score += 2;
    else score += 1;
    
    // Match requirement
    if (grant.matchRequired) score += 1;
    
    // Federal vs state/local
    if (grant.source === 'grants-gov' || grant.source === 'sam-gov') score += 1;
    
    if (score >= 5) return 'Hard';
    if (score >= 3) return 'Medium';
    return 'Easy';
  }

  private normalizeStatus(status: string): 'Open' | 'Closed' | 'Archived' | 'Upcoming' {
    const statusMap: { [key: string]: 'Open' | 'Closed' | 'Archived' | 'Upcoming' } = {
      'open': 'Open',
      'active': 'Open',
      'available': 'Open',
      'closed': 'Closed',
      'expired': 'Closed',
      'archived': 'Archived',
      'upcoming': 'Upcoming',
      'future': 'Upcoming'
    };

    return statusMap[status.toLowerCase()] || 'Open';
  }

  // Helper methods
  private getEnabledSources(requestedSources?: string[]): GrantSource[] {
    const allSources = Array.from(this.sources.values()).filter(s => s.enabled);
    
    if (requestedSources && requestedSources.length > 0) {
      return allSources.filter(s => requestedSources.includes(s.id));
    }
    
    return allSources;
  }

  private checkRateLimit(sourceId: string): boolean {
    const source = this.sources.get(sourceId);
    if (!source) return false;

    const now = Date.now();
    const rateData = this.rateLimit.get(sourceId);

    if (!rateData || now > rateData.resetTime) {
      this.rateLimit.set(sourceId, {
        count: 1,
        resetTime: now + 60000 // 1 minute
      });
      return true;
    }

    if (rateData.count < source.rateLimitPerMinute) {
      rateData.count++;
      return true;
    }

    return false;
  }

  private generateCacheKey(filters: SearchFilters): string {
    return `search:${JSON.stringify(filters)}`;
  }

  private getFromCache(key: string): SearchResult | null {
    const cached = this.cache.get(key);
    if (cached && cached.expires > Date.now()) {
      return cached.result;
    }
    this.cache.delete(key);
    return null;
  }

  private setCache(key: string, result: SearchResult): void {
    this.cache.set(key, {
      result,
      expires: Date.now() + 300000 // 5 minutes
    });
  }

  private applyClientSideFilters(grants: NormalizedGrant[], filters: SearchFilters): NormalizedGrant[] {
    let filtered = grants;

    if (filters.amountMin || filters.amountMax) {
      filtered = filtered.filter(grant => {
        const amount = parseInt(grant.amount.replace(/[^\d]/g, '') || '0');
        const min = filters.amountMin || 0;
        const max = filters.amountMax || Infinity;
        return amount >= min && amount <= max;
      });
    }

    if (filters.deadline) {
      filtered = filtered.filter(grant => {
        const deadline = new Date(grant.deadline);
        const min = filters.deadline?.min ? new Date(filters.deadline.min) : new Date(0);
        const max = filters.deadline?.max ? new Date(filters.deadline.max) : new Date('2099-12-31');
        return deadline >= min && deadline <= max;
      });
    }

    if (filters.difficulty && filters.difficulty.length > 0) {
      filtered = filtered.filter(grant => filters.difficulty!.includes(grant.difficulty));
    }

    if (filters.status && filters.status.length > 0) {
      filtered = filtered.filter(grant => filters.status!.includes(grant.status));
    }

    if (!filters.includeExpired) {
      filtered = filtered.filter(grant => grant.daysUntilDeadline && grant.daysUntilDeadline >= 0);
    }

    return filtered;
  }

  private sortGrants(grants: NormalizedGrant[], filters: SearchFilters): NormalizedGrant[] {
    const sortBy = filters.sortBy || 'relevance';
    const sortOrder = filters.sortOrder || 'desc';

    return grants.sort((a, b) => {
      let comparison = 0;

      switch (sortBy) {
        case 'deadline':
          comparison = new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
          break;
        case 'amount':
          const amountA = parseInt(a.amount.replace(/[^\d]/g, '') || '0');
          const amountB = parseInt(b.amount.replace(/[^\d]/g, '') || '0');
          comparison = amountA - amountB;
          break;
        case 'updated':
          comparison = new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
          break;
        case 'relevance':
        default:
          // Sort by relevance score, sources count, and newness
          comparison = (b.sources.length - a.sources.length) || 
                      (Number(b.isNew) - Number(a.isNew)) ||
                      (Number(b.isFeatured) - Number(a.isFeatured));
          break;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }

  private paginateResults(grants: NormalizedGrant[], filters: SearchFilters): NormalizedGrant[] {
    const limit = filters.limit || 50;
    const offset = filters.offset || 0;
    return grants.slice(offset, offset + limit);
  }

  private async generateSearchSuggestions(filters: SearchFilters, results: NormalizedGrant[]): Promise<string[]> {
    const suggestions: string[] = [];

    // Suggest popular categories from results
    const categories = results.map(g => g.category);
    const categoryCount = categories.reduce((acc, cat) => {
      acc[cat] = (acc[cat] || 0) + 1;
      return acc;
    }, {} as { [key: string]: number });

    const topCategories = Object.entries(categoryCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([cat]) => cat);

    suggestions.push(...topCategories);

    // Suggest related keywords
    const keywords = results.flatMap(g => g.keywords).slice(0, 5);
    suggestions.push(...keywords);

    return [...new Set(suggestions)].slice(0, 5);
  }

  // Public methods for managing sources
  getSources(): GrantSource[] {
    return Array.from(this.sources.values());
  }

  getSource(id: string): GrantSource | undefined {
    return this.sources.get(id);
  }

  updateSource(id: string, updates: Partial<GrantSource>): boolean {
    const source = this.sources.get(id);
    if (source) {
      this.sources.set(id, { ...source, ...updates });
      return true;
    }
    return false;
  }

  clearCache(): void {
    this.cache.clear();
  }
}

// Singleton instance
export const searchService = new SearchService();