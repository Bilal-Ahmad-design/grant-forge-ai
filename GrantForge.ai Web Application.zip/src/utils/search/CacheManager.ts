export interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number; // Time to live in milliseconds
  accessCount: number;
  lastAccessed: number;
}

export interface CacheStats {
  totalEntries: number;
  totalSize: number;
  hitRate: number;
  missRate: number;
  averageAge: number;
}

export class CacheManager<T> {
  private cache = new Map<string, CacheEntry<T>>();
  private maxSize: number;
  private defaultTTL: number;
  private hits = 0;
  private misses = 0;

  constructor(maxSize = 1000, defaultTTL = 300000) { // 5 minutes default
    this.maxSize = maxSize;
    this.defaultTTL = defaultTTL;
  }

  set(key: string, data: T, ttl?: number): void {
    const now = Date.now();
    const entry: CacheEntry<T> = {
      data,
      timestamp: now,
      ttl: ttl || this.defaultTTL,
      accessCount: 0,
      lastAccessed: now
    };

    // If cache is full, remove least recently used items
    if (this.cache.size >= this.maxSize) {
      this.evictLRU();
    }

    this.cache.set(key, entry);
  }

  get(key: string): T | null {
    const entry = this.cache.get(key);
    
    if (!entry) {
      this.misses++;
      return null;
    }

    const now = Date.now();
    
    // Check if entry has expired
    if (now - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      this.misses++;
      return null;
    }

    // Update access statistics
    entry.accessCount++;
    entry.lastAccessed = now;
    this.hits++;

    return entry.data;
  }

  has(key: string): boolean {
    const entry = this.cache.get(key);
    if (!entry) return false;

    const now = Date.now();
    if (now - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return false;
    }

    return true;
  }

  delete(key: string): boolean {
    return this.cache.delete(key);
  }

  clear(): void {
    this.cache.clear();
    this.hits = 0;
    this.misses = 0;
  }

  keys(): string[] {
    const now = Date.now();
    const validKeys: string[] = [];

    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp <= entry.ttl) {
        validKeys.push(key);
      } else {
        this.cache.delete(key);
      }
    }

    return validKeys;
  }

  size(): number {
    // Clean expired entries first
    this.cleanExpired();
    return this.cache.size;
  }

  getStats(): CacheStats {
    this.cleanExpired();
    
    const now = Date.now();
    const entries = Array.from(this.cache.values());
    const totalAccesses = this.hits + this.misses;
    
    return {
      totalEntries: entries.length,
      totalSize: this.estimateSize(),
      hitRate: totalAccesses > 0 ? this.hits / totalAccesses : 0,
      missRate: totalAccesses > 0 ? this.misses / totalAccesses : 0,
      averageAge: entries.length > 0 
        ? entries.reduce((sum, entry) => sum + (now - entry.timestamp), 0) / entries.length
        : 0
    };
  }

  // Clean up expired entries
  cleanExpired(): void {
    const now = Date.now();
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key);
      }
    }
  }

  // Evict least recently used items when cache is full
  private evictLRU(): void {
    let oldestKey = '';
    let oldestTime = Date.now();

    for (const [key, entry] of this.cache.entries()) {
      if (entry.lastAccessed < oldestTime) {
        oldestTime = entry.lastAccessed;
        oldestKey = key;
      }
    }

    if (oldestKey) {
      this.cache.delete(oldestKey);
    }
  }

  // Estimate memory usage (rough calculation)
  private estimateSize(): number {
    let size = 0;
    for (const [key, entry] of this.cache.entries()) {
      size += key.length * 2; // Approximate string size
      size += JSON.stringify(entry.data).length * 2; // Approximate data size
      size += 64; // Approximate entry metadata size
    }
    return size;
  }

  // Get entries sorted by access frequency
  getFrequentlyAccessed(limit = 10): Array<{ key: string; data: T; accessCount: number }> {
    const entries = Array.from(this.cache.entries())
      .map(([key, entry]) => ({ key, data: entry.data, accessCount: entry.accessCount }))
      .sort((a, b) => b.accessCount - a.accessCount)
      .slice(0, limit);

    return entries;
  }

  // Prefetch commonly accessed data
  prefetch(keys: string[], fetcher: (key: string) => Promise<T>): Promise<void[]> {
    const promises = keys
      .filter(key => !this.has(key))
      .map(async (key) => {
        try {
          const data = await fetcher(key);
          this.set(key, data);
        } catch (error) {
          console.warn(`Failed to prefetch data for key: ${key}`, error);
        }
      });

    return Promise.all(promises);
  }
}

// Specialized cache for search results
export class SearchCache extends CacheManager<any> {
  constructor() {
    super(500, 300000); // 500 entries, 5 minutes TTL
  }

  generateSearchKey(filters: any): string {
    // Create a consistent key from search filters
    const normalizedFilters = {
      ...filters,
      // Sort arrays to ensure consistent keys
      difficulty: filters.difficulty?.sort(),
      sources: filters.sources?.sort(),
      tags: filters.tags?.sort()
    };

    return `search:${JSON.stringify(normalizedFilters)}`;
  }

  cacheSearch(filters: any, results: any): void {
    const key = this.generateSearchKey(filters);
    this.set(key, results);
  }

  getCachedSearch(filters: any): any | null {
    const key = this.generateSearchKey(filters);
    return this.get(key);
  }

  // Get similar searches that might be relevant
  getSimilarSearches(filters: any, limit = 5): Array<{ key: string; similarity: number; data: any }> {
    const searchKey = this.generateSearchKey(filters);
    const allKeys = this.keys().filter(key => key.startsWith('search:'));
    
    const similarities = allKeys
      .map(key => {
        const similarity = this.calculateSearchSimilarity(searchKey, key);
        return { key, similarity, data: this.get(key) };
      })
      .filter(item => item.similarity > 0.5 && item.data)
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit);

    return similarities;
  }

  private calculateSearchSimilarity(key1: string, key2: string): number {
    if (key1 === key2) return 1.0;

    try {
      const filters1 = JSON.parse(key1.replace('search:', ''));
      const filters2 = JSON.parse(key2.replace('search:', ''));

      let commonFields = 0;
      let totalFields = 0;

      const fields = ['keyword', 'category', 'agency', 'location'];
      
      for (const field of fields) {
        totalFields++;
        if (filters1[field] === filters2[field]) {
          commonFields++;
        }
      }

      return totalFields > 0 ? commonFields / totalFields : 0;
    } catch {
      return 0;
    }
  }
}

// Global search cache instance
export const searchCache = new SearchCache();

// Performance monitoring for search operations
export class SearchPerformanceMonitor {
  private searchTimes: number[] = [];
  private errorCount = 0;
  private successCount = 0;

  recordSearch(duration: number, success: boolean): void {
    if (success) {
      this.searchTimes.push(duration);
      this.successCount++;
    } else {
      this.errorCount++;
    }

    // Keep only last 100 search times
    if (this.searchTimes.length > 100) {
      this.searchTimes.shift();
    }
  }

  getAverageSearchTime(): number {
    if (this.searchTimes.length === 0) return 0;
    return this.searchTimes.reduce((sum, time) => sum + time, 0) / this.searchTimes.length;
  }

  getMedianSearchTime(): number {
    if (this.searchTimes.length === 0) return 0;
    const sorted = [...this.searchTimes].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 === 0 
      ? (sorted[mid - 1] + sorted[mid]) / 2
      : sorted[mid];
  }

  getPercentile(percentile: number): number {
    if (this.searchTimes.length === 0) return 0;
    const sorted = [...this.searchTimes].sort((a, b) => a - b);
    const index = Math.ceil((percentile / 100) * sorted.length) - 1;
    return sorted[Math.max(0, index)];
  }

  getSuccessRate(): number {
    const total = this.successCount + this.errorCount;
    return total > 0 ? this.successCount / total : 0;
  }

  getStats() {
    return {
      averageTime: this.getAverageSearchTime(),
      medianTime: this.getMedianSearchTime(),
      p95Time: this.getPercentile(95),
      p99Time: this.getPercentile(99),
      successRate: this.getSuccessRate(),
      totalSearches: this.successCount + this.errorCount,
      errorCount: this.errorCount
    };
  }

  reset(): void {
    this.searchTimes = [];
    this.errorCount = 0;
    this.successCount = 0;
  }
}

// Global performance monitor instance
export const searchPerformanceMonitor = new SearchPerformanceMonitor();