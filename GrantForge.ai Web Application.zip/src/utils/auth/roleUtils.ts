import { Crown, Settings, PenTool, BookOpen, User } from 'lucide-react';

export const getRoleDisplay = (role: string) => {
  switch (role) {
    case 'super-admin':
      return { name: 'Super Admin', icon: Crown, color: 'bg-purple-600 text-white' };
    case 'admin':
      return { name: 'Administrator', icon: Settings, color: 'bg-indigo text-white' };
    case 'writer':
      return { name: 'Grant Writer', icon: PenTool, color: 'bg-emerald text-white' };
    default:
      return { name: 'User', icon: User, color: 'bg-slate-500 text-white' };
  }
};

export const getRoleDisplayText = (demoType: string) => {
  const roleDisplayMap = {
    'super-admin': 'Super Admin',
    'admin': 'Admin',
    'writer': 'Grant Writer'
  };
  return roleDisplayMap[demoType as keyof typeof roleDisplayMap] || 'User';
};