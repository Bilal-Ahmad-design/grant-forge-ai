export const demoAccounts = [
  {
    email: 'superadmin@grantforge.ai',
    password: 'demo123456',
    name: 'Sarah Johnson',
    role: 'super-admin',
    organization: 'GrantForge.ai',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=400&q=80'
  },
  {
    email: 'admin@grantforge.ai',
    password: 'demo123456',
    name: 'Michael Rodriguez',
    role: 'admin',
    organization: 'Propel Grant Solutions',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
  },
  {
    email: 'writer@grantforge.ai',
    password: 'demo123456',
    name: 'Dr. Lisa Chen',
    role: 'writer',
    organization: 'Propel Grant Solutions',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
  }
];

export type DemoAccountType = 'super-admin' | 'admin' | 'writer';