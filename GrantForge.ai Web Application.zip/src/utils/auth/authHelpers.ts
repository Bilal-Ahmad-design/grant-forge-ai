import { apiRequest, supabase } from '../supabase/client';
import { demoAccounts, DemoAccountType } from './demoAccounts';
import { getRoleDisplayText } from './roleUtils';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
  avatar?: string;
}

export const checkSession = async (): Promise<User | null> => {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    
    // Handle refresh token errors specifically
    if (error) {
      console.warn('Session error:', error.message);
      
      // If it's a refresh token error, clear the session
      if (error.message.includes('refresh') || error.message.includes('token')) {
        console.log('Clearing invalid session due to token error');
        await clearInvalidSession();
        return null;
      }
      
      // For other auth errors, also clear session to be safe
      if (error.message.includes('Auth') || error.message.includes('session')) {
        console.log('Clearing session due to auth error');
        await clearInvalidSession();
        return null;
      }
      
      return null;
    }
    
    if (session?.user) {
      try {
        const profile = await apiRequest('/auth/profile');
        return {
          id: session.user.id,
          name: profile.profile?.name || session.user.user_metadata?.name || 'User',
          email: session.user.email || '',
          role: profile.profile?.role || session.user.user_metadata?.role || 'junior-writer',
          organization: profile.profile?.organization || session.user.user_metadata?.organization || 'Unknown',
          avatar: profile.profile?.avatar || session.user.user_metadata?.avatar
        };
      } catch (profileError) {
        console.warn('Profile fetch error:', profileError);
        // If profile fetch fails, still set basic user info
        return {
          id: session.user.id,
          name: session.user.user_metadata?.name || 'User',
          email: session.user.email || '',
          role: session.user.user_metadata?.role || 'junior-writer',
          organization: session.user.user_metadata?.organization || 'Unknown',
          avatar: session.user.user_metadata?.avatar
        };
      }
    }
    return null;
  } catch (error: any) {
    console.error('Session check error:', error);
    
    // Handle specific auth errors
    if (error.message?.includes('refresh') || 
        error.message?.includes('token') || 
        error.message?.includes('Invalid Refresh Token')) {
      console.log('Clearing invalid session due to refresh token error');
      await clearInvalidSession();
    }
    
    return null;
  }
};

// Helper function to clear invalid sessions
const clearInvalidSession = async (): Promise<void> => {
  try {
    // Clear the session from Supabase
    await supabase.auth.signOut({ scope: 'local' });
    
    // Clear any localStorage items that might contain stale auth data
    const keysToRemove = [
      'supabase.auth.token',
      'sb-auth-token',
      'supabase.auth.refreshToken'
    ];
    
    keysToRemove.forEach(key => {
      try {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
      } catch (e) {
        // Ignore storage errors
      }
    });
    
    console.log('Successfully cleared invalid session');
  } catch (error) {
    console.warn('Error clearing session:', error);
    // Even if signOut fails, we should clear localStorage
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch (e) {
      console.warn('Could not clear storage:', e);
    }
  }
};

export const handleDemoLogin = async (demoType: DemoAccountType): Promise<{ user?: User; error?: string }> => {
  try {
    const demoCredentials = demoAccounts.find(account => account.role === demoType);
    if (!demoCredentials) {
      throw new Error('Demo account not found');
    }

    // First try to create demo user if it doesn't exist
    try {
      await apiRequest('/auth/signup', {
        method: 'POST',
        body: JSON.stringify(demoCredentials)
      });
    } catch (signupError) {
      // Demo user might already exist, that's okay
      console.log('Demo user might already exist, continuing with login');
    }

    // Now try to login
    const { data: { session }, error } = await supabase.auth.signInWithPassword({
      email: demoCredentials.email,
      password: demoCredentials.password,
    });

    if (error) {
      throw error;
    }

    if (session?.user) {
      const user = {
        id: session.user.id,
        name: demoCredentials.name,
        email: demoCredentials.email,
        role: demoCredentials.role as any,
        organization: demoCredentials.organization,
        avatar: (demoCredentials as any).avatar
      };
      
      return { user };
    }
    
    throw new Error('Failed to create session');
  } catch (error: any) {
    console.error('Demo login error:', error);
    return { error: 'Demo login failed. Please try signing up manually.' };
  }
};

export const handleLogout = async (): Promise<{ success: boolean; error?: string }> => {
  try {
    // Use the same clearing approach as invalid sessions
    await clearInvalidSession();
    return { success: true };
  } catch (error: any) {
    console.error('Logout error:', error);
    
    // Even if logout fails, try to clear local storage
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch (storageError) {
      console.warn('Could not clear storage during logout:', storageError);
    }
    
    // Return success anyway since we cleared local data
    return { success: true };
  }
};