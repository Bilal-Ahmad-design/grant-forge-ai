/**
 * Cache Management Utilities for GrantForge.ai
 * Handles browser cache clearing to prevent loading issues
 */

interface CacheManager {
  clearAllCache(): Promise<void>;
  clearBrowserStorage(): void;
  clearServiceWorkerCache(): Promise<void>;
  addCacheBustingHeaders(): void;
  getAppVersion(): string;
  shouldClearCache(): boolean;
}

class CacheManagerImpl implements CacheManager {
  private readonly APP_VERSION = '1.0.0';
  private readonly VERSION_KEY = 'grantforge_app_version';
  private readonly LAST_CLEAR_KEY = 'grantforge_last_cache_clear';

  /**
   * Clear all types of cache
   */
  async clearAllCache(): Promise<void> {
    console.log('🧹 Clearing all browser cache...');
    
    try {
      // Clear browser storage
      this.clearBrowserStorage();
      
      // Clear service worker cache
      await this.clearServiceWorkerCache();
      
      // Add cache busting headers
      this.addCacheBustingHeaders();
      
      // Mark cache as cleared
      this.markCacheCleared();
      
      console.log('✅ Cache cleared successfully');
    } catch (error) {
      console.error('❌ Error clearing cache:', error);
    }
  }

  /**
   * Clear browser storage (localStorage, sessionStorage)
   */
  clearBrowserStorage(): void {
    try {
      // Get important data we want to keep
      const importantKeys = [
        'supabase.auth.token',
        'sb-*', // Supabase auth keys
        this.VERSION_KEY,
        this.LAST_CLEAR_KEY
      ];

      // Clear localStorage except for important keys
      const localStorageKeysToKeep: { [key: string]: string } = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && importantKeys.some(pattern => 
          pattern.includes('*') ? key.startsWith(pattern.replace('*', '')) : key === pattern
        )) {
          localStorageKeysToKeep[key] = localStorage.getItem(key) || '';
        }
      }

      // Clear all localStorage
      localStorage.clear();

      // Restore important keys
      Object.entries(localStorageKeysToKeep).forEach(([key, value]) => {
        localStorage.setItem(key, value);
      });

      // Clear sessionStorage completely
      sessionStorage.clear();

      console.log('🗂️ Browser storage cleared');
    } catch (error) {
      console.error('Error clearing browser storage:', error);
    }
  }

  /**
   * Clear service worker cache
   */
  async clearServiceWorkerCache(): Promise<void> {
    try {
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const registration of registrations) {
          await registration.unregister();
          console.log('🔧 Service worker unregistered');
        }
      }

      // Clear caches API if available
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(
          cacheNames.map(cacheName => caches.delete(cacheName))
        );
        console.log('💾 Cache storage cleared');
      }
    } catch (error) {
      console.error('Error clearing service worker cache:', error);
    }
  }

  /**
   * Add cache busting headers
   */
  addCacheBustingHeaders(): void {
    try {
      // Add meta tags to prevent caching
      const metaTags = [
        { name: 'cache-control', content: 'no-cache, no-store, must-revalidate' },
        { name: 'pragma', content: 'no-cache' },
        { name: 'expires', content: '0' }
      ];

      metaTags.forEach(tag => {
        let metaElement = document.querySelector(`meta[http-equiv="${tag.name}"]`) as HTMLMetaElement;
        if (!metaElement) {
          metaElement = document.createElement('meta');
          metaElement.httpEquiv = tag.name;
          document.head.appendChild(metaElement);
        }
        metaElement.content = tag.content;
      });

      console.log('🏷️ Cache-busting headers added');
    } catch (error) {
      console.error('Error adding cache-busting headers:', error);
    }
  }

  /**
   * Get current app version
   */
  getAppVersion(): string {
    return this.APP_VERSION;
  }

  /**
   * Check if cache should be cleared based on version or time
   */
  shouldClearCache(): boolean {
    try {
      const storedVersion = localStorage.getItem(this.VERSION_KEY);
      const lastClear = localStorage.getItem(this.LAST_CLEAR_KEY);
      const now = Date.now();
      
      // Clear cache if:
      // 1. No version stored (first run)
      // 2. Version changed
      // 3. More than 24 hours since last clear
      if (!storedVersion || storedVersion !== this.APP_VERSION) {
        console.log('🔄 Version change detected, clearing cache');
        return true;
      }
      
      if (!lastClear || now - parseInt(lastClear) > 24 * 60 * 60 * 1000) {
        console.log('⏰ 24 hours passed, clearing cache');
        return true;
      }

      // Always clear cache in development
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('🚧 Development mode, clearing cache');
        return true;
      }

      return false;
    } catch (error) {
      console.error('Error checking cache clear conditions:', error);
      return true; // Default to clearing cache on error
    }
  }

  /**
   * Mark cache as cleared
   */
  private markCacheCleared(): void {
    try {
      localStorage.setItem(this.VERSION_KEY, this.APP_VERSION);
      localStorage.setItem(this.LAST_CLEAR_KEY, Date.now().toString());
    } catch (error) {
      console.error('Error marking cache as cleared:', error);
    }
  }

  /**
   * Force reload the page with cache bypass
   */
  forceReload(): void {
    console.log('🔄 Force reloading page...');
    window.location.reload();
  }

  /**
   * Clear authentication-related cache
   */
  clearAuthCache(): void {
    try {
      // Clear auth-related items but keep the structure
      const authKeys = Object.keys(localStorage).filter(key => 
        key.includes('supabase') || 
        key.includes('auth') || 
        key.includes('session') ||
        key.includes('token')
      );

      authKeys.forEach(key => {
        if (!key.includes('auth.token')) { // Keep the main auth token
          localStorage.removeItem(key);
        }
      });

      console.log('🔐 Auth cache cleared');
    } catch (error) {
      console.error('Error clearing auth cache:', error);
    }
  }
}

// Export singleton instance
export const cacheManager = new CacheManagerImpl();

// Export utility functions
export const clearCache = () => cacheManager.clearAllCache();
export const shouldClearCache = () => cacheManager.shouldClearCache();
export const forceReload = () => cacheManager.forceReload();
export const clearAuthCache = () => cacheManager.clearAuthCache();