import { useEffect, useState } from 'react';
import { cacheManager } from './cacheManager';

interface CacheInitState {
  isClearing: boolean;
  isReady: boolean;
  error: string | null;
}

/**
 * Custom hook to handle cache initialization on app startup
 */
export const useCacheInit = () => {
  const [state, setState] = useState<CacheInitState>({
    isClearing: false,
    isReady: false,
    error: null
  });

  useEffect(() => {
    const initializeCache = async () => {
      try {
        console.log('🏁 Starting cache initialization...');
        setState(prev => ({ ...prev, isClearing: true, error: null }));

        // Check if cache needs to be cleared
        if (cacheManager.shouldClearCache()) {
          console.log('🚀 Cache clearing required, starting process...');
          
          // Clear cache
          await cacheManager.clearAllCache();
          
          // Small delay to ensure clearing is complete
          await new Promise(resolve => setTimeout(resolve, 300));
          
          console.log('✅ Cache clearing completed');
        } else {
          console.log('✅ Cache is up to date, no clearing needed');
          // Still add a small delay for consistency
          await new Promise(resolve => setTimeout(resolve, 100));
        }

        console.log('🎯 Cache initialization complete');
        setState(prev => ({ ...prev, isClearing: false, isReady: true }));
      } catch (error) {
        console.error('❌ Cache initialization failed:', error);
        setState(prev => ({ 
          ...prev, 
          isClearing: false, 
          isReady: true, // Still mark as ready to prevent blocking
          error: error instanceof Error ? error.message : 'Cache initialization failed'
        }));
      }
    };

    initializeCache();
  }, []);

  return state;
};

/**
 * Simple function to manually trigger cache clearing
 */
export const manualCacheClear = async (): Promise<void> => {
  try {
    console.log('🔧 Manual cache clear initiated...');
    await cacheManager.clearAllCache();
    
    // Show success message
    if (typeof window !== 'undefined' && 'toast' in window) {
      // @ts-ignore
      window.toast?.success?.('Cache cleared successfully! Refreshing...');
    }
    
    // Force reload after clearing
    setTimeout(() => {
      cacheManager.forceReload();
    }, 1000);
  } catch (error) {
    console.error('Manual cache clear failed:', error);
    if (typeof window !== 'undefined' && 'toast' in window) {
      // @ts-ignore
      window.toast?.error?.('Failed to clear cache');
    }
  }
};