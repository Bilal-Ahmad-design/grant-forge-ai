import { createClient } from '@supabase/supabase-js@2';
import { projectId, publicAnonKey } from './info';

export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

// API helper for server requests
export const apiRequest = async (endpoint: string, options: RequestInit = {}) => {
  try {
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    // Handle session errors (like invalid refresh tokens)
    if (sessionError) {
      console.warn('Session error in apiRequest:', sessionError);
      
      if (sessionError.message.includes('refresh') || sessionError.message.includes('token')) {
        // Clear the invalid session
        await supabase.auth.signOut({ scope: 'local' });
        throw new Error('Session expired. Please log in again.');
      }
    }
    
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session?.access_token || publicAnonKey}`,
      ...options.headers,
    };

    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-647288d6${endpoint}`,
      {
        ...options,
        headers,
      }
    );

    if (!response.ok) {
      let errorData;
      const contentType = response.headers.get('content-type');
      
      try {
        if (contentType && contentType.includes('application/json')) {
          errorData = await response.json();
        } else {
          const errorText = await response.text();
          errorData = { error: errorText, status: response.status };
        }
      } catch (parseError) {
        errorData = { error: 'Failed to parse error response', status: response.status };
      }
      
      console.error(`API Error on ${endpoint}:`, errorData);
      
      // Handle 401 errors that might indicate auth issues
      if (response.status === 401) {
        // Try to refresh the session or clear it if invalid
        try {
          const { error: refreshError } = await supabase.auth.refreshSession();
          if (refreshError) {
            console.warn('Session refresh failed:', refreshError);
            await supabase.auth.signOut({ scope: 'local' });
            throw new Error('Authentication expired. Please log in again.');
          }
        } catch (refreshErr) {
          console.warn('Error during session refresh:', refreshErr);
          await supabase.auth.signOut({ scope: 'local' });
          throw new Error('Authentication expired. Please log in again.');
        }
      }
      
      // Create a structured error object
      const error = new Error(errorData.error || `API Error: ${response.status}`);
      // Attach additional error properties
      (error as any).code = errorData.code;
      (error as any).status = response.status;
      (error as any).error = errorData.error;
      
      throw error;
    }

    return response.json();
  } catch (error: any) {
    // Handle refresh token errors that might occur during getSession()
    if (error.message?.includes('refresh') || error.message?.includes('Invalid Refresh Token')) {
      console.warn('Refresh token error in apiRequest:', error);
      try {
        await supabase.auth.signOut({ scope: 'local' });
      } catch (signOutError) {
        console.warn('Error signing out after refresh token error:', signOutError);
      }
      throw new Error('Session expired. Please log in again.');
    }
    
    throw error;
  }
};