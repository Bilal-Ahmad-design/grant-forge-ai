# GrantForge.ai - Comprehensive Grant Management Platform

## 🚀 Overview

GrantForge.ai is a complete K-12 grant writing platform with AI-enhanced research, writing assistance, and comprehensive client management. The application is fully integrated with Supabase for authentication, database operations, and serverless functions.

## 📋 System Architecture

```
Frontend (React + TypeScript)
    ↓
Supabase Edge Functions (Hono + Deno)
    ↓  
PostgreSQL Database (KV Store)
    ↓
External APIs (OpenAI ChatGPT)
```

## 🛠️ Supabase Integration

### Database Schema
- **Table**: `kv_store_647288d6`
- **Structure**: Key-value store for flexible data management
- **Location**: [Database Tables](https://supabase.com/dashboard/project/qafcjuqtazduydhisvds/database/tables)

### Edge Functions
- **Path**: `/functions/v1/make-server-647288d6`
- **Framework**: Hono web framework running on Deno
- **Location**: [Edge Functions](https://supabase.com/dashboard/project/qafcjuqtazduydhisvds/functions)

### Authentication
- **Provider**: Supabase Auth
- **Roles**: Super Admin, Admin, Senior Writer, Junior Writer
- **Features**: Role-based permissions, demo accounts, profile management

## 🎯 Features by User Role

### Super Admin
- ✅ Platform-wide access to all organizations
- ✅ User management and role assignment
- ✅ System health monitoring
- ✅ Global analytics and KPI dashboard
- ✅ Full grant pipeline management

### Admin (District Level)
- ✅ District-wide grant management
- ✅ Client management and intake forms
- ✅ Team oversight and approval workflows
- ✅ KPI dashboard for district performance
- ✅ AI research and writing capabilities

### Senior Writer
- ✅ Self-assignment of grants
- ✅ Direct submission capabilities
- ✅ AI-enhanced research and writing
- ✅ Grant pipeline management
- ✅ Client interaction

### Junior Writer
- ✅ Grant research and writing
- ✅ AI assistance for all tasks
- ✅ Requires admin approval for submissions
- ✅ Access to assigned grants only

## 🔧 API Endpoints

### Authentication
- `POST /auth/signup` - Create new user account
- `GET /auth/profile` - Get user profile data

### Grant Pipeline
- `GET /grants/pipeline` - Get grants for Kanban view
- `PATCH /grants/pipeline/:id/move` - Move grant between stages
- `PATCH /grants/pipeline/:id/assign` - Assign grant to team member
- `PATCH /grants/pipeline/:id/approve` - Approve/reject grant submissions

### General Grant Management
- `GET /grants` - Get all grants (role-based filtering)
- `POST /grants` - Create new grant opportunity

### AI Research & Writing
- `POST /ai/research` - Generate AI research analysis
- `POST /ai/write` - Generate AI grant proposal draft

### Client Management
- `GET /clients/managed` - Get managed clients
- `POST /clients/managed` - Add new client
- `POST /clients/send-intake-invitation` - Send intake form
- `GET /clients/intake-invitations` - Get intake responses

### Analytics & KPIs
- `GET /analytics` - Get system analytics
- `GET /kpi-data` - Get KPI dashboard data

### Alerts & Notifications
- `GET /alerts` - Get user alerts
- `POST /alerts` - Create new alert
- `PATCH /alerts/:id/read` - Mark alert as read

### System Health
- `GET /health` - Check system health and OpenAI status

## 🚀 Quick Start

### 1. Environment Setup
The following environment variables are already configured:
- `SUPABASE_URL`: Your Supabase project URL
- `SUPABASE_ANON_KEY`: Public anonymous key for client access
- `SUPABASE_SERVICE_ROLE_KEY`: Service role key for server operations
- `OPENAI_API_KEY`: Optional - for full AI capabilities

### 2. Demo Accounts
Use these demo accounts to test different role permissions:

**Super Admin Demo**
- Full platform access
- User management capabilities
- System health monitoring

**Admin Demo**
- District-level management
- Client and team oversight
- Approval workflows

**Senior Writer Demo**
- Self-assignment capabilities
- Direct submission rights
- AI-enhanced writing

**Junior Writer Demo**
- Basic grant writing access
- Requires approval workflows
- AI assistance available

### 3. Testing All Features

Navigate to **System Health** (Super Admin only) to run comprehensive system tests:
- Backend connectivity
- Database operations
- API endpoint health
- Authentication verification
- Role-based access control

## 📊 Current Features Status

### ✅ Fully Implemented
- **Authentication System**: Complete with role-based access
- **Grant Pipeline**: Kanban board with stage management
- **AI Integration**: Research and writing assistance (demo mode available)
- **Client Management**: Full CRUD operations and intake forms
- **User Management**: Role assignment and permissions
- **Analytics Dashboard**: KPIs and performance tracking
- **Daily Alerts**: Deadline and system notifications
- **Research Hub**: AI-powered grant discovery

### 🔧 Backend Integration
All components are connected to the Supabase backend with:
- Real-time data synchronization
- Fallback to demo mode when API unavailable
- Progressive error handling
- Role-based data filtering

## 🛡️ Security Features

- **Role-Based Access Control**: Four-tier permission system
- **Authentication**: Secure Supabase Auth integration
- **API Security**: Bearer token authentication
- **Data Isolation**: Organization-level data separation
- **Input Validation**: Comprehensive form and API validation

## 📱 Responsive Design

- **Mobile-First**: Optimized for all device sizes
- **Brand Consistency**: GrantForge.ai color palette and typography
- **Accessibility**: WCAG-compliant interface design
- **Performance**: Optimized loading and error states

## 🔍 Monitoring & Debug

### System Health Dashboard
Access via Navigation → System Health (Super Admin only):
- Real-time API endpoint testing
- Database connectivity verification
- Authentication status monitoring
- Component health visualization

### Error Handling
- Graceful degradation to demo mode
- User-friendly error messages
- Comprehensive logging for debugging
- Progressive loading states

## 🎨 Design System

### Brand Colors
- **Navy**: #0E2A47 (Primary)
- **Indigo**: #2B5EA5 (Secondary)
- **Amber**: #F5A524 (Accent)
- **Emerald**: #2BB673 (Success)

### Typography
- **Headlines**: Space Grotesk
- **Body Text**: Inter
- **Code**: Mono fonts for technical content

## 🚀 Production Deployment

The application is production-ready with:
- Supabase Edge Functions deployed and operational
- Database schema configured and optimized
- Authentication flows tested and secure
- Error handling and fallback mechanisms
- Performance optimizations implemented

## 📞 Support

For technical support or questions about the platform:
1. Check the System Health dashboard for status updates
2. Review the browser console for detailed error messages
3. Verify API connectivity using the health check tools
4. Test different user roles using the demo accounts

---

**GrantForge.ai** - Empowering K-12 education through AI-enhanced grant writing and management.