export async function handleDocumentUpload(request: Request): Promise<Response> {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const category = formData.get('category') as string;
    
    if (!file) {
      return new Response(JSON.stringify({ error: 'No file provided' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Validate file type and size
    const maxSize = 50 * 1024 * 1024; // 50MB
    if (file.size > maxSize) {
      return new Response(JSON.stringify({ error: 'File too large' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Create bucket if it doesn't exist
    const bucketName = 'make-647288d6-documents';
    
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    
    if (!bucketExists) {
      const { error: createError } = await supabase.storage.createBucket(bucketName, {
        public: false,
        allowedMimeTypes: [
          'application/pdf',
          'image/*',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'application/vnd.ms-excel',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ],
        fileSizeLimit: maxSize
      });
      
      if (createError) {
        console.error('Error creating bucket:', createError);
        return new Response(JSON.stringify({ error: 'Failed to create storage bucket' }), {
          status: 500,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    }

    // Generate unique filename
    const timestamp = Date.now();
    const randomId = Math.random().toString(36).substring(2, 15);
    const fileExtension = file.name.split('.').pop();
    const fileName = `${category}/${timestamp}-${randomId}.${fileExtension}`;

    // Upload file to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return new Response(JSON.stringify({ error: 'Failed to upload file' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Store file metadata in KV store
    const fileId = `doc_${timestamp}_${randomId}`;
    const fileMetadata = {
      id: fileId,
      name: file.name,
      type: file.type,
      size: file.size,
      category: category,
      storagePath: fileName,
      uploadedAt: new Date().toISOString(),
      bucket: bucketName
    };

    await kv.set(`document:${fileId}`, fileMetadata);

    // Create signed URL for access
    const { data: signedUrlData } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(fileName, 3600); // 1 hour expiry

    return new Response(JSON.stringify({
      success: true,
      file: {
        id: fileId,
        name: file.name,
        type: file.type,
        size: file.size,
        url: signedUrlData?.signedUrl,
        category: category,
        uploadedAt: fileMetadata.uploadedAt
      }
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Document upload error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleDocumentDelete(request: Request, documentId: string): Promise<Response> {
  try {
    // Get document metadata
    const documentData = await kv.get(`document:${documentId}`);
    if (!documentData) {
      return new Response(JSON.stringify({ error: 'Document not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Delete from storage
    const { error: deleteError } = await supabase.storage
      .from(documentData.bucket)
      .remove([documentData.storagePath]);

    if (deleteError) {
      console.error('Storage delete error:', deleteError);
    }

    // Delete metadata from KV store
    await kv.del(`document:${documentId}`);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Document delete error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleDocumentDownload(request: Request, documentId: string): Promise<Response> {
  try {
    // Get document metadata
    const documentData = await kv.get(`document:${documentId}`);
    if (!documentData) {
      return new Response(JSON.stringify({ error: 'Document not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Create signed URL for download
    const { data: signedUrlData, error: urlError } = await supabase.storage
      .from(documentData.bucket)
      .createSignedUrl(documentData.storagePath, 300); // 5 minute expiry for downloads

    if (urlError) {
      console.error('Signed URL error:', urlError);
      return new Response(JSON.stringify({ error: 'Failed to generate download URL' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({
      success: true,
      downloadUrl: signedUrlData.signedUrl,
      fileName: documentData.name
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Document download error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleIntakeSave(request: Request): Promise<Response> {
  try {
    const { clientId, formData, customFields, documents, status } = await request.json();

    const intakeData = {
      clientId: clientId || `client_${Date.now()}`,
      formData,
      customFields,
      documents,
      status, // 'draft' or 'submitted'
      updatedAt: new Date().toISOString(),
      createdAt: clientId ? undefined : new Date().toISOString()
    };

    // Save to KV store
    await kv.set(`intake:${intakeData.clientId}`, intakeData);

    // If this is a submission, also save to submissions list
    if (status === 'submitted') {
      const submissionId = `submission_${Date.now()}`;
      await kv.set(`submission:${submissionId}`, {
        id: submissionId,
        clientId: intakeData.clientId,
        submittedAt: new Date().toISOString(),
        status: 'pending_review'
      });
    }

    return new Response(JSON.stringify({
      success: true,
      clientId: intakeData.clientId,
      message: status === 'submitted' ? 'Form submitted successfully' : 'Form saved successfully'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Intake save error:', error);
    return new Response(JSON.stringify({ error: 'Failed to save intake form' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleIntakeLoad(request: Request, clientId: string): Promise<Response> {
  try {
    const intakeData = await kv.get(`intake:${clientId}`);
    
    if (!intakeData) {
      return new Response(JSON.stringify({ error: 'Intake form not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({
      success: true,
      data: intakeData.formData,
      customFields: intakeData.customFields,
      documents: intakeData.documents,
      status: intakeData.status
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Intake load error:', error);
    return new Response(JSON.stringify({ error: 'Failed to load intake form' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}