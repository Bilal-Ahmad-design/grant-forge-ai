import * as kv from './kv_store.tsx';

export interface Document {
  id: string;
  title: string;
  content: string;
  grantId?: string;
  grantTitle?: string;
  section: string;
  status: 'draft' | 'in-review' | 'approved' | 'needs-revision';
  authorId: string;
  createdAt: string;
  lastModified: string;
  version: number;
  collaborators: Array<{
    userId: string;
    role: 'editor' | 'reviewer' | 'viewer';
    addedAt: string;
    lastActive: string;
  }>;
  comments: Comment[];
  wordCount: number;
  characterCount: number;
  aiSuggestions: number;
  progress: number;
  deadline?: string;
  template?: string;
  tags: string[];
  revisions: DocumentRevision[];
}

export interface Comment {
  id: string;
  documentId: string;
  content: string;
  authorId: string;
  createdAt: string;
  updatedAt?: string;
  resolved: boolean;
  position: {
    from: number;
    to: number;
  };
  parentId?: string;
  mentions: string[];
  attachments?: string[];
}

export interface DocumentRevision {
  id: string;
  documentId: string;
  version: number;
  content: string;
  changes: string;
  authorId: string;
  createdAt: string;
  comment?: string;
}

export interface Template {
  id: string;
  name: string;
  description: string;
  content: string;
  sections: string[];
  category: 'federal' | 'state' | 'foundation' | 'private';
  wordCount: number;
  estimatedTime: string;
  createdBy: string;
  isPublic: boolean;
}

export interface AIWritingRequest {
  prompt: string;
  context: string;
  documentType: string;
  section: string;
  tone?: 'formal' | 'persuasive' | 'technical' | 'conversational';
  length?: 'short' | 'medium' | 'long';
}

// Document Management
export async function handleCreateDocument(request: Request): Promise<Response> {
  try {
    const { title, grantId, section, template, authorId, collaborators } = await request.json();

    if (!title || !authorId) {
      return new Response(JSON.stringify({ error: 'Title and author are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const documentId = `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    let content = '';

    // Load template content if specified
    if (template) {
      const templateData = await kv.get(`template:${template}`);
      if (templateData) {
        content = templateData.content;
      }
    }

    const document: Document = {
      id: documentId,
      title,
      content,
      grantId,
      section,
      status: 'draft',
      authorId,
      createdAt: new Date().toISOString(),
      lastModified: new Date().toISOString(),
      version: 1,
      collaborators: (collaborators || []).map((userId: string) => ({
        userId,
        role: 'editor',
        addedAt: new Date().toISOString(),
        lastActive: new Date().toISOString()
      })),
      comments: [],
      wordCount: content ? content.split(/\s+/).length : 0,
      characterCount: content.length,
      aiSuggestions: 0,
      progress: 0,
      template,
      tags: [],
      revisions: []
    };

    await kv.set(`document:${documentId}`, document);

    // Add to user's documents list
    const userDocs = await kv.get(`user_documents:${authorId}`) || [];
    userDocs.unshift(documentId);
    await kv.set(`user_documents:${authorId}`, userDocs);

    // Add to collaborators' document lists
    for (const collaborator of document.collaborators) {
      const collabDocs = await kv.get(`user_documents:${collaborator.userId}`) || [];
      if (!collabDocs.includes(documentId)) {
        collabDocs.unshift(documentId);
        await kv.set(`user_documents:${collaborator.userId}`, collabDocs);
      }
    }

    return new Response(JSON.stringify({ document }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error creating document:', error);
    return new Response(JSON.stringify({ error: 'Failed to create document' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleGetDocuments(request: Request): Promise<Response> {
  try {
    const url = new URL(request.url);
    const userId = url.searchParams.get('userId');

    if (!userId) {
      return new Response(JSON.stringify({ error: 'User ID required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const userDocIds = await kv.get(`user_documents:${userId}`) || [];
    const documents = [];

    for (const docId of userDocIds) {
      const doc = await kv.get(`document:${docId}`);
      if (doc) {
        // Add author and collaborator details
        const author = await kv.get(`user_profile:${doc.authorId}`);
        const collabDetails = await Promise.all(
          doc.collaborators.map(async (collab: any) => {
            const profile = await kv.get(`user_profile:${collab.userId}`);
            return {
              ...collab,
              name: profile?.name || 'Unknown User',
              avatar: profile?.avatar
            };
          })
        );

        documents.push({
          ...doc,
          author: {
            id: doc.authorId,
            name: author?.name || 'Unknown User',
            avatar: author?.avatar
          },
          collaborators: collabDetails
        });
      }
    }

    return new Response(JSON.stringify({ documents }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error fetching documents:', error);
    return new Response(JSON.stringify({ error: 'Failed to fetch documents' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleUpdateDocument(request: Request, documentId: string): Promise<Response> {
  try {
    const updates = await request.json();
    const document = await kv.get(`document:${documentId}`);

    if (!document) {
      return new Response(JSON.stringify({ error: 'Document not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Create revision if content changed
    if (updates.content && updates.content !== document.content) {
      const revision: DocumentRevision = {
        id: `rev_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        documentId,
        version: document.version,
        content: document.content,
        changes: calculateChanges(document.content, updates.content),
        authorId: updates.authorId || document.authorId,
        createdAt: new Date().toISOString(),
        comment: updates.revisionComment
      };

      document.revisions = document.revisions || [];
      document.revisions.push(revision);
      document.version += 1;
    }

    // Update document
    const updatedDocument = {
      ...document,
      ...updates,
      lastModified: new Date().toISOString(),
      wordCount: updates.content ? updates.content.split(/\s+/).filter(Boolean).length : document.wordCount,
      characterCount: updates.content ? updates.content.length : document.characterCount
    };

    await kv.set(`document:${documentId}`, updatedDocument);

    // Update activity log
    await logActivity({
      type: 'document_updated',
      documentId,
      userId: updates.authorId || document.authorId,
      timestamp: new Date().toISOString(),
      details: { changes: Object.keys(updates) }
    });

    return new Response(JSON.stringify({ document: updatedDocument }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error updating document:', error);
    return new Response(JSON.stringify({ error: 'Failed to update document' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleDeleteDocument(request: Request, documentId: string): Promise<Response> {
  try {
    const document = await kv.get(`document:${documentId}`);

    if (!document) {
      return new Response(JSON.stringify({ error: 'Document not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Remove from all user document lists
    const allUsers = [document.authorId, ...document.collaborators.map((c: any) => c.userId)];
    
    for (const userId of allUsers) {
      const userDocs = await kv.get(`user_documents:${userId}`) || [];
      const updatedDocs = userDocs.filter((id: string) => id !== documentId);
      await kv.set(`user_documents:${userId}`, updatedDocs);
    }

    // Delete document and related data
    await kv.del(`document:${documentId}`);
    
    // Delete comments
    const comments = await kv.getByPrefix(`comment:${documentId}:`);
    for (const comment of comments) {
      await kv.del(`comment:${documentId}:${comment.id}`);
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error deleting document:', error);
    return new Response(JSON.stringify({ error: 'Failed to delete document' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleDuplicateDocument(request: Request, documentId: string): Promise<Response> {
  try {
    const originalDoc = await kv.get(`document:${documentId}`);

    if (!originalDoc) {
      return new Response(JSON.stringify({ error: 'Document not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const newDocumentId = `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const duplicatedDoc: Document = {
      ...originalDoc,
      id: newDocumentId,
      title: `${originalDoc.title} (Copy)`,
      createdAt: new Date().toISOString(),
      lastModified: new Date().toISOString(),
      version: 1,
      comments: [],
      revisions: [],
      status: 'draft'
    };

    await kv.set(`document:${newDocumentId}`, duplicatedDoc);

    // Add to author's documents list
    const userDocs = await kv.get(`user_documents:${originalDoc.authorId}`) || [];
    userDocs.unshift(newDocumentId);
    await kv.set(`user_documents:${originalDoc.authorId}`, userDocs);

    return new Response(JSON.stringify({ document: duplicatedDoc }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error duplicating document:', error);
    return new Response(JSON.stringify({ error: 'Failed to duplicate document' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// Comment Management
export async function handleAddComment(request: Request, documentId: string): Promise<Response> {
  try {
    const { content, authorId, position, parentId, mentions } = await request.json();

    if (!content || !authorId) {
      return new Response(JSON.stringify({ error: 'Content and author are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const commentId = `comment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const comment: Comment = {
      id: commentId,
      documentId,
      content,
      authorId,
      createdAt: new Date().toISOString(),
      resolved: false,
      position,
      parentId,
      mentions: mentions || []
    };

    await kv.set(`comment:${documentId}:${commentId}`, comment);

    // Update document comment count
    const document = await kv.get(`document:${documentId}`);
    if (document) {
      document.comments = document.comments || [];
      document.comments.push(comment);
      await kv.set(`document:${documentId}`, document);
    }

    // Send notifications for mentions
    if (mentions && mentions.length > 0) {
      for (const mentionedUser of mentions) {
        await createNotification({
          userId: mentionedUser,
          type: 'mention',
          title: 'You were mentioned in a comment',
          message: `${authorId} mentioned you in a comment on "${document?.title || 'document'}"`,
          documentId,
          commentId,
          createdAt: new Date().toISOString()
        });
      }
    }

    return new Response(JSON.stringify({ comment }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error adding comment:', error);
    return new Response(JSON.stringify({ error: 'Failed to add comment' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleResolveComment(request: Request, documentId: string, commentId: string): Promise<Response> {
  try {
    const comment = await kv.get(`comment:${documentId}:${commentId}`);

    if (!comment) {
      return new Response(JSON.stringify({ error: 'Comment not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    comment.resolved = true;
    comment.updatedAt = new Date().toISOString();

    await kv.set(`comment:${documentId}:${commentId}`, comment);

    return new Response(JSON.stringify({ comment }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error resolving comment:', error);
    return new Response(JSON.stringify({ error: 'Failed to resolve comment' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// AI Writing Assistant
export async function handleAIWritingAssist(request: Request): Promise<Response> {
  try {
    const { prompt, context, documentType, section, tone, length } = await request.json();

    if (!prompt) {
      return new Response(JSON.stringify({ error: 'Prompt is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Construct enhanced prompt for grant writing
    const enhancedPrompt = buildGrantWritingPrompt(prompt, context, documentType, section, tone, length);

    // Make request to OpenAI API
    const openAIResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4-turbo-preview',
        messages: [
          {
            role: 'system',
            content: 'You are an expert grant writer with extensive experience in federal, state, and foundation grant applications. You write compelling, evidence-based proposals that clearly articulate needs, solutions, and impact.'
          },
          {
            role: 'user',
            content: enhancedPrompt
          }
        ],
        max_tokens: length === 'short' ? 500 : length === 'long' ? 2000 : 1000,
        temperature: 0.7
      })
    });

    if (!openAIResponse.ok) {
      throw new Error('OpenAI API request failed');
    }

    const openAIData = await openAIResponse.json();
    const suggestion = openAIData.choices[0]?.message?.content;

    if (!suggestion) {
      throw new Error('No suggestion received from AI');
    }

    // Log AI usage
    await logActivity({
      type: 'ai_suggestion',
      userId: 'system',
      timestamp: new Date().toISOString(),
      details: { 
        prompt: prompt.substring(0, 100),
        section,
        length: suggestion.length
      }
    });

    return new Response(JSON.stringify({ 
      suggestion,
      usage: openAIData.usage,
      model: 'gpt-4-turbo-preview'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('AI writing assist error:', error);
    return new Response(JSON.stringify({ 
      error: 'AI assistance failed',
      details: error.message 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// Template Management
export async function handleGetTemplates(request: Request): Promise<Response> {
  try {
    const templates = await kv.getByPrefix('template:');
    
    const publicTemplates = templates
      .filter((template: Template) => template.isPublic)
      .sort((a, b) => a.name.localeCompare(b.name));

    return new Response(JSON.stringify({ templates: publicTemplates }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error fetching templates:', error);
    return new Response(JSON.stringify({ error: 'Failed to fetch templates' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// Document Export
export async function handleExportDocument(request: Request, documentId: string): Promise<Response> {
  try {
    const { format } = await request.json();
    const document = await kv.get(`document:${documentId}`);

    if (!document) {
      return new Response(JSON.stringify({ error: 'Document not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Generate export URL (in a real implementation, this would handle actual conversion)
    const exportUrl = await generateExportUrl(document, format);

    return new Response(JSON.stringify({ downloadUrl: exportUrl }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error exporting document:', error);
    return new Response(JSON.stringify({ error: 'Failed to export document' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// Analytics and Stats
export async function handleGetWritingStats(request: Request): Promise<Response> {
  try {
    const url = new URL(request.url);
    const userId = url.searchParams.get('userId');

    // Get all documents for user/team
    const userDocIds = userId ? 
      await kv.get(`user_documents:${userId}`) || [] :
      await kv.getByPrefix('document:');

    const documents = [];
    for (const docId of Array.isArray(userDocIds) ? userDocIds : [userDocIds]) {
      const doc = await kv.get(typeof docId === 'string' ? `document:${docId}` : `document:${docId.id}`);
      if (doc) documents.push(doc);
    }

    // Calculate stats
    const stats = {
      totalDocuments: documents.length,
      inProgress: documents.filter(d => d.status === 'draft' || d.status === 'in-review').length,
      completed: documents.filter(d => d.status === 'approved').length,
      overdue: documents.filter(d => d.deadline && new Date(d.deadline) < new Date()).length,
      activeCollaborators: new Set(documents.flatMap(d => d.collaborators.map((c: any) => c.userId))).size,
      wordsWritten: documents.reduce((total, d) => total + (d.wordCount || 0), 0),
      commentsResolved: documents.reduce((total, d) => 
        total + (d.comments || []).filter((c: any) => c.resolved).length, 0
      ),
      aiSuggestions: documents.reduce((total, d) => total + (d.aiSuggestions || 0), 0)
    };

    return new Response(JSON.stringify({ stats }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error fetching writing stats:', error);
    return new Response(JSON.stringify({ error: 'Failed to fetch stats' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// Utility Functions
function buildGrantWritingPrompt(
  prompt: string, 
  context: string, 
  documentType: string, 
  section: string, 
  tone?: string, 
  length?: string
): string {
  const basePrompt = `Grant Writing Context:
- Document Type: ${documentType}
- Section: ${section}
- Tone: ${tone || 'professional and persuasive'}
- Length: ${length || 'medium'}

Current Content Context:
${context ? context.substring(0, 1000) : 'No existing content'}

User Request:
${prompt}

Please provide a well-structured, compelling response that:
1. Uses evidence-based language appropriate for grant applications
2. Maintains professional tone while being persuasive
3. Includes specific, measurable outcomes where relevant
4. Follows grant writing best practices
5. Is appropriate for the specified section

Response:`;

  return basePrompt;
}

function calculateChanges(oldContent: string, newContent: string): string {
  // Simple change calculation - in a real implementation, you'd use a proper diff algorithm
  const oldWords = oldContent.split(/\s+/).length;
  const newWords = newContent.split(/\s+/).length;
  const wordsDiff = newWords - oldWords;
  
  if (wordsDiff > 0) {
    return `+${wordsDiff} words added`;
  } else if (wordsDiff < 0) {
    return `${Math.abs(wordsDiff)} words removed`;
  } else {
    return 'Content modified';
  }
}

async function generateExportUrl(document: Document, format: string): Promise<string> {
  // In a real implementation, this would:
  // 1. Convert HTML to the requested format (PDF, DOCX, etc.)
  // 2. Upload to cloud storage
  // 3. Return signed URL
  
  // For now, return a mock URL
  return `https://example.com/exports/${document.id}.${format}`;
}

async function logActivity(activity: any): Promise<void> {
  const activityId = `activity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  await kv.set(`activity:${activityId}`, {
    id: activityId,
    ...activity
  });
}

async function createNotification(notification: any): Promise<void> {
  const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  await kv.set(`notification:${notification.userId}:${notificationId}`, {
    id: notificationId,
    ...notification,
    read: false
  });
}

// Initialize default templates
export async function initializeDefaultTemplates(): Promise<void> {
  const defaultTemplates: Template[] = [
    {
      id: 'federal-education-basic',
      name: 'Federal Education Grant (Basic)',
      description: 'Standard template for federal education grants with all required sections',
      content: `<h1>Executive Summary</h1>
<p>Provide a compelling overview of your project...</p>

<h1>Statement of Need</h1>
<p>Describe the specific problem or need your project addresses...</p>

<h1>Project Description</h1>
<p>Detail your proposed solution and approach...</p>

<h1>Goals, Objectives, and Expected Outcomes</h1>
<p>List measurable goals and expected outcomes...</p>

<h1>Evaluation Plan</h1>
<p>Describe how you will measure success...</p>

<h1>Sustainability Plan</h1>
<p>Explain how the project will continue after funding ends...</p>`,
      sections: ['executive-summary', 'needs-statement', 'project-description', 'evaluation', 'sustainability'],
      category: 'federal',
      wordCount: 2500,
      estimatedTime: '2-3 weeks',
      createdBy: 'system',
      isPublic: true
    },
    {
      id: 'foundation-program',
      name: 'Foundation Program Grant',
      description: 'Template for foundation grants focusing on program development',
      content: `<h1>Organization Background</h1>
<p>Describe your organization's mission and experience...</p>

<h1>Program Description</h1>
<p>Detail the program you wish to implement...</p>

<h1>Community Impact</h1>
<p>Explain how your program will benefit the community...</p>

<h1>Budget and Timeline</h1>
<p>Provide detailed budget and implementation timeline...</p>`,
      sections: ['project-description', 'budget'],
      category: 'foundation',
      wordCount: 1500,
      estimatedTime: '1-2 weeks',
      createdBy: 'system',
      isPublic: true
    }
  ];

  for (const template of defaultTemplates) {
    const existing = await kv.get(`template:${template.id}`);
    if (!existing) {
      await kv.set(`template:${template.id}`, template);
    }
  }
}