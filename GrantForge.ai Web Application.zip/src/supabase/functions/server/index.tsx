import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';
import { 
  handleDocumentUpload, 
  handleDocumentDelete, 
  handleDocumentDownload,
  handleIntakeSave,
  handleIntakeLoad
} from './documents-service.ts';
import {
  handleGrantSearch,
  handleGetSources,
  handleSaveGrant,
  handleUnsaveGrant
} from './search-service.ts';
import {
  handleCreateDocument,
  handleGetDocuments,
  handleUpdateDocument,
  handleDeleteDocument,
  handleDuplicateDocument,
  handleAddComment,
  handleResolveComment,
  handleAIWritingAssist,
  handleGetTemplates,
  handleExportDocument,
  handleGetWritingStats,
  initializeDefaultTemplates
} from './writing-service.ts';

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '',
);

// Initialize API clients
const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY') || '';

const app = new Hono();

// Middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));
app.use('*', logger(console.log));

// Initialize default writing templates on startup
(async () => {
  try {
    await initializeDefaultTemplates();
    console.log('Writing templates initialized');
  } catch (error) {
    console.error('Error initializing templates:', error);
  }
})();

// Helper functions
const generateIntakeFormUrl = (clientId: string, token: string) => {
  return `https://grantforge.ai/intake/${clientId}?token=${token}`;
};

const sendEmail = async (to: string, subject: string, content: string) => {
  console.log('Email would be sent to:', to);
  console.log('Subject:', subject);
  console.log('Content:', content);
  return { success: true };
};

const canApproveWork = (userRole: string): boolean => {
  return ['super-admin', 'admin'].includes(userRole);
};

const canSelfAssign = (userRole: string): boolean => {
  return ['super-admin', 'admin', 'writer'].includes(userRole);
};

const requiresApproval = (userRole: string): boolean => {
  return userRole === 'writer';
};

const canMoveToStage = (userRole: string, grant: any, newStage: string) => {
  const stageOrder = ['research', 'writing', 'review', 'submitted', 'awarded', 'denied'];
  const currentIndex = stageOrder.indexOf(grant.stage);
  const newIndex = stageOrder.indexOf(newStage);

  if (['super-admin', 'admin'].includes(userRole)) {
    return { allowed: true, reason: '' };
  }

  if (newIndex > currentIndex + 1 && currentIndex < 3) {
    return { allowed: false, reason: 'Cannot skip stages in the pipeline' };
  }

  if (userRole === 'writer' && newStage === 'submitted') {
    return { allowed: true, reason: 'Will require admin approval' };
  }

  return { allowed: true, reason: '' };
};

// Mock data generators
const generateMockResearch = (grantTitle: string, funder: string) => {
  return `# AI Research Analysis for ${grantTitle}

## Executive Summary
This comprehensive analysis examines the grant opportunity from ${funder}, providing strategic insights for a competitive K-12 education proposal.

## Key Requirements Breakdown
- Public K-12 school districts and educational institutions
- Must demonstrate clear educational impact and measurable outcomes
- Requires alignment with current education standards and best practices

## Success Factors & Strategies
- Data-driven approach with local student performance data
- Stakeholder engagement including community partners
- Evidence-based practices with peer-reviewed research
- Measurable outcomes focused on student achievement

## Budget Recommendations
- Personnel (60-70%): Competitive salaries for qualified staff
- Equipment & Materials (15-20%): Essential resources and technology  
- Professional Development (8-12%): Training and capacity building
- Evaluation (5-8%): Assessment tools and external evaluation

## Timeline Considerations
- Application Submission: Allow 6-8 weeks for comprehensive development
- Implementation Planning: Align with academic calendar considerations
- Evaluation: Plan for baseline data collection before program start

*This analysis was generated using AI-powered research capabilities.*`;
};

const generateMockDraft = (grantTitle: string, funder: string, clientInfo: any) => {
  const clientName = clientInfo?.clientName || 'Our School District';
  return `# Grant Application: ${grantTitle}
**Submitted to:** ${funder}
**Applicant:** ${clientName}
**Date:** ${new Date().toLocaleDateString()}

## Executive Summary
${clientName} respectfully requests funding from ${funder} to implement an innovative educational program that will directly benefit students in our district.

## Statement of Need
Our district serves a diverse student population facing significant educational challenges that require immediate intervention.

## Project Description
Our comprehensive educational improvement program addresses identified needs through integrated components designed to create sustainable positive change.

## Implementation Plan
- Phase 1: Foundation Building (Months 1-3)
- Phase 2: Program Launch (Months 4-9)  
- Phase 3: Full Implementation (Months 10-15)
- Phase 4: Evaluation and Sustainability (Months 16-18)

*This proposal was developed using AI-enhanced grant writing tools.*`;
};

// Create demo grant if it doesn't exist
const ensureDemoGrant = async (grantId: string, user: any) => {
  try {
    const existingGrant = await kv.get(grantId);
    if (existingGrant) {
      return existingGrant;
    }
  } catch (error) {
    // Grant doesn't exist, create demo version
  }
  
  const demoGrants: { [key: string]: any } = {
    'grant1': {
      id: 'grant1',
      title: 'STEM Education Innovation Grant',
      funder: 'National Science Foundation',
      amount: '$250,000',
      deadline: '2024-09-15',
      stage: 'research',
      priority: 'high',
      organization: user.organization || 'Demo Organization',
      created_by: user.id,
      created_by_name: user.name,
      assigned_to: user.id,
      requires_approval: false,
      progress: 25,
      client_name: 'Roosevelt Elementary School',
      estimated_hours: 120,
      actual_hours: 30,
      tags: ['STEM', 'K-5', 'Innovation'],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    'grant2': {
      id: 'grant2',
      title: 'Rural Education Achievement Program',
      funder: 'US Department of Education',
      amount: '$150,000',
      deadline: '2024-08-30',
      stage: 'writing',
      priority: 'medium',
      organization: user.organization || 'Demo Organization',
      created_by: user.id,
      created_by_name: user.name,
      assigned_to: user.id,
      requires_approval: user.role === 'junior-writer',
      progress: 60,
      client_name: 'Jefferson High School',
      estimated_hours: 80,
      actual_hours: 48,
      tags: ['Rural', 'Achievement', 'K-12'],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    'grant3': {
      id: 'grant3',
      title: 'Digital Infrastructure Modernization',
      funder: 'Federal Communications Commission',
      amount: '$500,000',
      deadline: '2024-11-15',
      stage: 'review',
      priority: 'high',
      organization: user.organization || 'Demo Organization',
      created_by: user.id,
      created_by_name: user.name,
      assigned_to: user.id,
      requires_approval: true,
      approval_status: user.role === 'junior-writer' ? 'pending' : undefined,
      progress: 90,
      client_name: 'Lincoln Middle School',
      estimated_hours: 200,
      actual_hours: 180,
      tags: ['Technology', 'Infrastructure', 'Modernization'],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }
  };
  
  const demoGrant = demoGrants[grantId];
  if (demoGrant) {
    try {
      await kv.set(grantId, demoGrant);
      return demoGrant;
    } catch (error) {
      return demoGrant;
    }
  }
  
  return null;
};

// Health check
app.get('/make-server-647288d6/health', (c) => {
  return c.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    openai_configured: !!OPENAI_API_KEY
  });
});

// === GRANTS.GOV API INTEGRATION ===

// Data transformation utilities
const transformGrantsGovData = (grantsGovGrant: any) => {
  return {
    id: grantsGovGrant.opportunityId || `gg-${Date.now()}`,
    title: grantsGovGrant.opportunityTitle || 'Untitled Grant',
    funder: grantsGovGrant.agencyName || 'Unknown Agency',
    amount: grantsGovGrant.awardAmount ? `${Number(grantsGovGrant.awardAmount).toLocaleString()}` : 'Amount TBD',
    deadline: grantsGovGrant.closeDate || grantsGovGrant.applicationDeadline || 'TBD',
    description: grantsGovGrant.description || grantsGovGrant.synopsis || 'No description available',
    category: grantsGovGrant.categoryOfFundingActivity || 'Education',
    eligibility: grantsGovGrant.eligibilityCriteria || 'See full opportunity details',
    opportunityNumber: grantsGovGrant.opportunityNumber || '',
    cfda: grantsGovGrant.cfdaNumber || '',
    source: 'grants.gov',
    lastUpdated: grantsGovGrant.lastUpdatedDate || new Date().toISOString(),
    link: `https://www.grants.gov/web/grants/view-opportunity.html?oppId=${grantsGovGrant.opportunityId}`,
    tags: [
      grantsGovGrant.categoryOfFundingActivity || 'General',
      'Federal',
      'Education'
    ].filter(Boolean)
  };
};

// Enhanced multi-source grant search
app.get('/make-server-647288d6/grants/search', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  // Set user ID header for search service
  const headers = new Headers(c.req.headers);
  headers.set('x-user-id', user.id);
  
  const requestWithUserId = new Request(c.req.url, {
    method: c.req.method,
    headers: headers
  });

  return handleGrantSearch(requestWithUserId);
});

// Legacy Grants.gov search (for backward compatibility)
app.get('/make-server-647288d6/grants/search-legacy', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Get search parameters
    const keyword = c.req.query('keyword') || '';
    const category = c.req.query('category') || '';
    const agency = c.req.query('agency') || '';
    const limit = Number(c.req.query('limit')) || 50;
    const eligibility = c.req.query('eligibility') || '';

    // Try to fetch from Grants.gov API without authentication
    try {
      // Build Grants.gov API request
      const grantsGovUrl = new URL('https://api.grants.gov/v1/api/fetchOpportunity');
      
      // Add search parameters
      if (keyword) grantsGovUrl.searchParams.append('keyword', keyword);
      if (category) grantsGovUrl.searchParams.append('categoryOfFundingActivity', category);
      if (agency) grantsGovUrl.searchParams.append('agencyName', agency);
      if (eligibility) grantsGovUrl.searchParams.append('eligibilityCriteria', eligibility);
      
      grantsGovUrl.searchParams.append('limit', limit.toString());
      grantsGovUrl.searchParams.append('opportunityStatus', 'open');

      console.log('Fetching from Grants.gov:', grantsGovUrl.toString());

      const response = await fetch(grantsGovUrl.toString(), {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'GrantForge.ai/1.0'
        }
      });

      if (response.ok) {
        const grantsGovData = await response.json();
        console.log('Grants.gov response received:', grantsGovData?.opportunities?.length || 0, 'opportunities');

        // Transform the data to our internal format
        const transformedGrants = (grantsGovData.opportunities || []).map(transformGrantsGovData);

        // Cache the results for 1 hour
        const cacheKey = `grants_search:${keyword}:${category}:${agency}:${eligibility}:${limit}`;
        try {
          await kv.set(cacheKey, {
            grants: transformedGrants,
            total: grantsGovData.totalResults || transformedGrants.length,
            cached_at: new Date().toISOString(),
            expires_at: new Date(Date.now() + 60 * 60 * 1000).toISOString() // 1 hour
          });
        } catch (cacheError) {
          console.log('Cache warning:', cacheError);
        }

        return c.json({
          grants: transformedGrants,
          total: grantsGovData.totalResults || transformedGrants.length,
          source: 'grants.gov',
          message: `Found ${transformedGrants.length} grant opportunities from Grants.gov`
        });
      } else {
        console.log('Grants.gov API returned error:', response.status, response.statusText);
      }
    } catch (apiError) {
      console.log('Grants.gov API call failed:', apiError);
    }

    // Fallback to enhanced mock data with more realistic grant opportunities
    console.log('Falling back to enhanced mock data');
    
    const enhancedMockGrants = [
      {
        id: 'ed-stem-2024-001',
        title: 'Supporting Effective Instruction State Grants Program',
        funder: 'U.S. Department of Education',
        amount: '$2,500,000',
        deadline: '2024-10-15',
        description: 'Grants to improve the quality and effectiveness of teachers, principals, and other school leaders in high-need schools.',
        category: 'Teacher Quality',
        eligibility: ['State education agencies', 'Local education agencies', 'Public Schools'],
        opportunityNumber: 'ED-GRANTS-071924-001',
        cfda: '84.367',
        source: 'grants.gov',
        lastUpdated: new Date().toISOString(),
        link: 'https://www.grants.gov/web/grants/view-opportunity.html?oppId=347924',
        tags: ['Education', 'Teacher Training', 'Federal', 'K-12', 'Professional Development'],
        matchRequired: false,
        difficulty: 'Medium',
        location: 'National',
        isNew: true,
        saved: false
      },
      {
        id: 'nsf-stem-2024-002',
        title: 'Discovery Research PreK-12 (DRK-12)',
        funder: 'National Science Foundation',
        amount: '$1,200,000',
        deadline: '2024-09-30',
        description: 'Research and development of STEM education innovations for grades PreK-12 including curriculum, instruction, and assessment.',
        category: 'STEM Education',
        eligibility: ['Institutions of higher education', 'Non-profit organizations', 'Public Schools'],
        opportunityNumber: 'NSF-24-587',
        cfda: '47.076',
        source: 'grants.gov',
        lastUpdated: new Date().toISOString(),
        link: 'https://www.grants.gov/web/grants/view-opportunity.html?oppId=347925',
        tags: ['STEM', 'Research', 'PreK-12', 'Innovation', 'Curriculum'],
        matchRequired: true,
        difficulty: 'Hard',
        location: 'National',
        isNew: true,
        saved: false
      },
      {
        id: 'usda-nutrition-2024-003',
        title: 'Fresh Fruit and Vegetable Program',
        funder: 'U.S. Department of Agriculture',
        amount: '$750,000',
        deadline: '2024-08-20',
        description: 'Provide fresh fruits and vegetables to elementary school children during the school day.',
        category: 'Nutrition Education',
        eligibility: ['Elementary schools', 'Public Schools', 'Charter Schools'],
        opportunityNumber: 'USDA-FNS-2024-FFVP',
        cfda: '10.582',
        source: 'grants.gov',
        lastUpdated: new Date().toISOString(),
        link: 'https://www.grants.gov/web/grants/view-opportunity.html?oppId=347926',
        tags: ['Nutrition', 'Elementary', 'Health', 'USDA', 'Student Support'],
        matchRequired: false,
        difficulty: 'Easy',
        location: 'National',
        isNew: false,
        saved: false
      },
      {
        id: 'ed-title1-2024-004',
        title: 'Title I School Improvement Grants',
        funder: 'U.S. Department of Education',
        amount: '$5,000,000',
        deadline: '2024-11-30',
        description: 'Grants to improve student achievement in high-need schools through comprehensive reform strategies.',
        category: 'School Improvement',
        eligibility: ['Local education agencies', 'Title I Schools', 'Public Schools'],
        opportunityNumber: 'ED-ESE-24-002',
        cfda: '84.010',
        source: 'grants.gov',
        lastUpdated: new Date().toISOString(),
        link: 'https://www.grants.gov/web/grants/view-opportunity.html?oppId=347927',
        tags: ['Title I', 'School Improvement', 'High-Need', 'Achievement', 'Reform'],
        matchRequired: true,
        difficulty: 'Hard',
        location: 'National',
        isNew: true,
        saved: false
      },
      {
        id: 'nih-science-2024-005',
        title: 'Science Education Partnership Award (SEPA)',
        funder: 'National Institutes of Health',
        amount: '$1,500,000',
        deadline: '2024-12-15',
        description: 'Improve science literacy through innovative educational partnerships between research institutions and schools.',
        category: 'Science Education',
        eligibility: ['Educational institutions', 'Museums', 'Science centers', 'Higher Education'],
        opportunityNumber: 'NIH-SEPA-24-001',
        cfda: '93.859',
        source: 'grants.gov',
        lastUpdated: new Date().toISOString(),
        link: 'https://www.grants.gov/web/grants/view-opportunity.html?oppId=347928',
        tags: ['Science', 'Partnership', 'Literacy', 'Innovation', 'Research'],
        matchRequired: false,
        difficulty: 'Medium',
        location: 'National',
        isNew: false,
        saved: false
      },
      {
        id: 'dod-stem-2024-006',
        title: 'Department of Defense STEM Education Outreach',
        funder: 'U.S. Department of Defense',
        amount: '$800,000',
        deadline: '2024-09-15',
        description: 'Support STEM education programs that encourage students to pursue careers in science, technology, engineering, and mathematics.',
        category: 'STEM Education',
        eligibility: ['Public Schools', 'Private Schools', 'Non-profit organizations'],
        opportunityNumber: 'DOD-STEM-24-003',
        cfda: '12.630',
        source: 'grants.gov',
        lastUpdated: new Date().toISOString(),
        link: 'https://www.grants.gov/web/grants/view-opportunity.html?oppId=347929',
        tags: ['STEM', 'Career Development', 'Outreach', 'Defense', 'Technology'],
        matchRequired: false,
        difficulty: 'Medium',
        location: 'National',
        isNew: true,
        saved: false
      },
      {
        id: 'epa-env-2024-007',
        title: 'Environmental Education Grants',
        funder: 'Environmental Protection Agency',
        amount: '$300,000',
        deadline: '2024-10-30',
        description: 'Support environmental education projects that promote environmental stewardship and increase environmental literacy.',
        category: 'Environmental Education',
        eligibility: ['Public Schools', 'Non-profit organizations', 'Local governments'],
        opportunityNumber: 'EPA-EE-24-001',
        cfda: '66.951',
        source: 'grants.gov',
        lastUpdated: new Date().toISOString(),
        link: 'https://www.grants.gov/web/grants/view-opportunity.html?oppId=347930',
        tags: ['Environment', 'Education', 'Stewardship', 'Literacy', 'Sustainability'],
        matchRequired: false,
        difficulty: 'Easy',
        location: 'National',
        isNew: false,
        saved: false
      }
    ];

    // Apply filters to mock data
    let filteredGrants = enhancedMockGrants;
    
    if (keyword) {
      filteredGrants = filteredGrants.filter(grant => 
        grant.title.toLowerCase().includes(keyword.toLowerCase()) ||
        grant.description.toLowerCase().includes(keyword.toLowerCase()) ||
        grant.funder.toLowerCase().includes(keyword.toLowerCase()) ||
        grant.tags.some(tag => tag.toLowerCase().includes(keyword.toLowerCase()))
      );
    }
    
    if (category && category !== 'all') {
      filteredGrants = filteredGrants.filter(grant => grant.category === category);
    }
    
    if (agency && agency !== 'all') {
      filteredGrants = filteredGrants.filter(grant => grant.funder.includes(agency));
    }

    return c.json({ 
      grants: filteredGrants.slice(0, limit),
      total: filteredGrants.length,
      source: 'enhanced_mock',
      message: `Found ${filteredGrants.length} grant opportunities. Note: This is enhanced demo data as Grants.gov API is not available without authentication.`
    });

  } catch (error: any) {
    console.error('Grants search error:', error);
    
    return c.json({ 
      error: 'Failed to fetch grant opportunities',
      message: error.message,
      grants: [],
      total: 0
    }, 500);
  }
});

// Get grant categories and filters from Grants.gov
app.get('/make-server-647288d6/grants/filters', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Static filter options based on Grants.gov categories
    const filters = {
      categories: [
        'Arts',
        'Business and Commerce',
        'Community Development',
        'Disaster Prevention and Relief',
        'Education',
        'Employment, Labor, and Training',
        'Energy',
        'Environment',
        'Food and Nutrition',
        'Health',
        'Housing',
        'Humanities',
        'Information and Statistics',
        'Law, Justice, and Legal Services',
        'Natural Resources',
        'Regional Development',
        'Science and Technology',
        'Social Services and Income Security',
        'Transportation'
      ],
      agencies: [
        'Department of Education',
        'Department of Health and Human Services',
        'National Science Foundation',
        'Department of Agriculture',
        'Department of Justice',
        'Department of Energy',
        'Environmental Protection Agency',
        'National Endowment for the Arts',
        'National Endowment for the Humanities',
        'Institute of Education Sciences'
      ],
      eligibilityTypes: [
        'State governments',
        'County governments',
        'City or township governments',
        'Public and State controlled institutions of higher education',
        'Private institutions of higher education',
        'Public housing authorities/Indian housing authorities',
        'Native American tribal governments (Federally recognized)',
        'Nonprofits having a 501(c)(3) status with the IRS',
        'Nonprofits that do not have a 501(c)(3) status with the IRS',
        'Small businesses',
        'For profit organizations other than small businesses',
        'Independent school districts',
        'Public and Indian housing authorities',
        'Native American tribal organizations (other than Federally recognized tribal governments)',
        'Other'
      ],
      fundingTypes: [
        'Grant',
        'Cooperative Agreement',
        'Procurement Contract',
        'Direct Payment for Specified Use',
        'Direct Payment with Unrestricted Use',
        'Direct Loan',
        'Guaranteed/Insured Loan',
        'Insurance'
      ],
      amountRanges: [
        { label: 'Under $25,000', min: 0, max: 25000 },
        { label: '$25,000 - $100,000', min: 25000, max: 100000 },
        { label: '$100,000 - $500,000', min: 100000, max: 500000 },
        { label: '$500,000 - $1,000,000', min: 500000, max: 1000000 },
        { label: 'Over $1,000,000', min: 1000000, max: null }
      ]
    };

    return c.json({ filters });
  } catch (error) {
    console.error('Error fetching filters:', error);
    return c.json({ error: 'Failed to fetch filter options' }, 500);
  }
});

// === AUTHENTICATION ROUTES ===

// Sign up route
app.post('/make-server-647288d6/auth/signup', async (c) => {
  try {
    const { email, password, name, role = 'writer', organization } = await c.req.json();

    if (!email || !password || !name || !organization) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const validRoles = ['super-admin', 'admin', 'writer'];
    if (!validRoles.includes(role)) {
      return c.json({ error: 'Invalid role' }, 400);
    }

    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role, organization },
      email_confirm: true
    });

    if (authError) {
      // Handle specific error cases
      if (authError.message.includes('already been registered')) {
        return c.json({ 
          error: 'A user with this email address has already been registered',
          code: 'EMAIL_ALREADY_EXISTS'
        }, 400);
      }
      return c.json({ error: authError.message }, 400);
    }

    const userProfile = {
      id: authData.user.id,
      name,
      email,
      role,
      organization,
      created_at: new Date().toISOString(),
      permissions: {
        canSelfAssign: canSelfAssign(role),
        canApprove: canApproveWork(role),
        requiresApproval: requiresApproval(role)
      }
    };

    await kv.set(`user:${authData.user.id}`, userProfile);
    
    return c.json({ user: authData.user, profile: userProfile });
  } catch (error: any) {
    console.log('Signup error:', error);
    return c.json({ error: 'Account creation failed' }, 500);
  }
});

// Get user profile
app.get('/make-server-647288d6/auth/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: 'Invalid token' }, 401);
    }

    let profile = null;
    try {
      profile = await kv.get(`user:${user.id}`);
    } catch (kvError) {
      console.log('Profile fetch warning:', kvError);
    }
    
    return c.json({
      ...user,
      profile: profile || {
        name: user.user_metadata?.name,
        role: user.user_metadata?.role || 'junior-writer',
        organization: user.user_metadata?.organization
      }
    });
  } catch (error) {
    return c.json({ error: 'Error fetching profile' }, 500);
  }
});

// Get available grant sources
app.get('/make-server-647288d6/grants/sources', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  return handleGetSources(c.req);
});

// Save grant for user
app.post('/make-server-647288d6/grants/save', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const body = await c.req.json();
  body.userId = user.id;

  const request = new Request(c.req.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  return handleSaveGrant(request);
});

// Unsave grant for user
app.post('/make-server-647288d6/grants/unsave', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const body = await c.req.json();
  body.userId = user.id;

  const request = new Request(c.req.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  return handleUnsaveGrant(request);
});

// === COLLABORATIVE WRITING ROUTES ===

// Create new document
app.post('/make-server-647288d6/documents', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const body = await c.req.json();
  body.authorId = user.id;

  const request = new Request(c.req.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  return handleCreateDocument(request);
});

// Get user's documents
app.get('/make-server-647288d6/documents', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const url = new URL(c.req.url);
  url.searchParams.set('userId', user.id);

  const request = new Request(url.toString(), {
    method: 'GET',
    headers: c.req.headers
  });

  return handleGetDocuments(request);
});

// Update document
app.put('/make-server-647288d6/documents/:id', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const documentId = c.req.param('id');
  const body = await c.req.json();
  body.authorId = user.id;

  const request = new Request(c.req.url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  return handleUpdateDocument(request, documentId);
});

// Delete document
app.delete('/make-server-647288d6/documents/:id', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const documentId = c.req.param('id');
  return handleDeleteDocument(c.req, documentId);
});

// Duplicate document
app.post('/make-server-647288d6/documents/:id/duplicate', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const documentId = c.req.param('id');
  return handleDuplicateDocument(c.req, documentId);
});

// Add comment to document
app.post('/make-server-647288d6/documents/:id/comments', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const documentId = c.req.param('id');
  const body = await c.req.json();
  body.authorId = user.id;

  const request = new Request(c.req.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  return handleAddComment(request, documentId);
});

// Resolve comment
app.put('/make-server-647288d6/documents/:docId/comments/:commentId/resolve', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const documentId = c.req.param('docId');
  const commentId = c.req.param('commentId');
  
  return handleResolveComment(c.req, documentId, commentId);
});

// AI Writing Assistant
app.post('/make-server-647288d6/ai/writing-assist', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  return handleAIWritingAssist(c.req);
});

// Get document templates
app.get('/make-server-647288d6/documents/templates', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  return handleGetTemplates(c.req);
});

// Export document
app.post('/make-server-647288d6/documents/:id/export', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const documentId = c.req.param('id');
  return handleExportDocument(c.req, documentId);
});

// Get writing statistics
app.get('/make-server-647288d6/documents/stats', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  // Admin users can see team stats, others see their own
  const url = new URL(c.req.url);
  if (user.user_metadata?.role !== 'admin' && user.user_metadata?.role !== 'super-admin') {
    url.searchParams.set('userId', user.id);
  }

  const request = new Request(url.toString(), {
    method: 'GET',
    headers: c.req.headers
  });

  return handleGetWritingStats(request);
});

// Update document status (admin only)
app.put('/make-server-647288d6/documents/:id/status', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  // Check if user has admin privileges
  if (user.user_metadata?.role !== 'admin' && user.user_metadata?.role !== 'super-admin') {
    return c.json({ error: 'Admin privileges required' }, 403);
  }

  const documentId = c.req.param('id');
  const body = await c.req.json();

  const request = new Request(c.req.url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  return handleUpdateDocument(request, documentId);
});

// === DOCUMENT MANAGEMENT ROUTES ===

// Upload document
app.post('/make-server-647288d6/documents/upload', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  return handleDocumentUpload(c.req);
});

// Delete document
app.delete('/make-server-647288d6/documents/:id', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const documentId = c.req.param('id');
  return handleDocumentDelete(c.req, documentId);
});

// Download document
app.get('/make-server-647288d6/documents/:id/download', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const documentId = c.req.param('id');
  return handleDocumentDownload(c.req, documentId);
});

// === INTAKE FORM ROUTES ===

// Save intake form
app.post('/make-server-647288d6/intake/save', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  return handleIntakeSave(c.req);
});

// Submit intake form
app.post('/make-server-647288d6/intake/submit', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  return handleIntakeSave(c.req);
});

// Load intake form
app.get('/make-server-647288d6/intake/:clientId', async (c) => {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const clientId = c.req.param('clientId');
  return handleIntakeLoad(c.req, clientId);
});

// === GRANT PIPELINE ROUTES ===

// Get grants for pipeline view
app.get('/make-server-647288d6/grants/pipeline', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    let userProfile = null;
    try {
      userProfile = await kv.get(`user:${user.id}`);
    } catch (kvError) {
      userProfile = {
        role: user.user_metadata?.role || 'junior-writer',
        organization: user.user_metadata?.organization || 'Unknown'
      };
    }

    let grants = [];
    try {
      if (userProfile?.role === 'super-admin') {
        grants = await kv.getByPrefix('grant');
      } else {
        const organization = userProfile?.organization || user.user_metadata?.organization || 'Unknown';
        grants = await kv.getByPrefix('grant');
        grants = grants.filter(g => g.organization === organization || !g.organization);
      }
    } catch (kvError) {
      console.log('Failed to load grants from KV store:', kvError);
      grants = [];
    }

    if (grants.length === 0) {
      const demoGrantIds = ['grant1', 'grant2', 'grant3'];
      for (const grantId of demoGrantIds) {
        const demoGrant = await ensureDemoGrant(grantId, {
          id: user.id,
          name: user.user_metadata?.name || 'Demo User',
          role: userProfile?.role || 'junior-writer',
          organization: userProfile?.organization || 'Demo Organization'
        });
        if (demoGrant) {
          grants.push(demoGrant);
        }
      }
    }
    
    return c.json({ grants: grants || [] });
  } catch (error) {
    console.log('Error in pipeline route:', error);
    return c.json({ grants: [] });
  }
});

// Move grant to different stage
app.patch('/make-server-647288d6/grants/pipeline/:id/move', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const grantId = c.req.param('id');
    const { stage, requires_approval } = await c.req.json();
    
    let userProfile = null;
    try {
      userProfile = await kv.get(`user:${user.id}`);
    } catch (kvError) {
      userProfile = {
        role: user.user_metadata?.role || 'junior-writer',
        organization: user.user_metadata?.organization || 'Unknown'
      };
    }

    let existingGrant = null;
    try {
      existingGrant = await kv.get(grantId);
    } catch (kvError) {
      console.log(`Grant ${grantId} not found in KV store, creating demo grant`);
    }

    if (!existingGrant) {
      existingGrant = await ensureDemoGrant(grantId, {
        id: user.id,
        name: user.user_metadata?.name || 'Demo User',
        role: userProfile?.role || 'junior-writer',
        organization: userProfile?.organization || 'Demo Organization'
      });
    }

    if (!existingGrant) {
      return c.json({ 
        error: 'Grant not found', 
        message: 'Demo grant could not be created',
        demo_mode: true 
      }, 404);
    }

    const movePermission = canMoveToStage(userProfile?.role, existingGrant, stage);
    if (!movePermission.allowed) {
      return c.json({ error: movePermission.reason }, 403);
    }

    const updatedGrant = {
      ...existingGrant,
      stage,
      approval_status: requires_approval ? 'pending' : undefined,
      submitted_for_approval_at: requires_approval ? new Date().toISOString() : undefined,
      submitted_by: requires_approval ? user.id : undefined,
      updated_at: new Date().toISOString(),
      updated_by: user.id,
      updated_by_name: userProfile?.name || user.user_metadata?.name || 'Unknown User'
    };

    try {
      await kv.set(grantId, updatedGrant);
    } catch (kvError) {
      console.log('Failed to save grant to KV store:', kvError);
    }

    if (requires_approval) {
      const alertId = `alert:${Date.now()}`;
      try {
        await kv.set(alertId, {
          id: alertId,
          type: 'grant_approval_required',
          priority: 'high',
          title: 'Grant Pending Approval',
          message: `${existingGrant.title} has been submitted for approval by ${userProfile?.name || 'Unknown User'}.`,
          timestamp: new Date().toISOString(),
          actionRequired: true,
          read: false,
          data: { grantId, grantTitle: existingGrant.title }
        });
      } catch (alertError) {
        console.log('Alert creation warning:', alertError);
      }
    }
    
    return c.json({ 
      grant: updatedGrant, 
      message: 'Grant stage updated successfully',
      demo_mode: !existingGrant.created_at
    });
  } catch (error) {
    console.log('Error moving grant stage:', error);
    return c.json({ 
      error: 'Error updating grant stage', 
      message: 'Operation completed in demo mode',
      demo_mode: true 
    }, 200);
  }
});

// === CLIENT MANAGEMENT ROUTES ===

// Get managed clients
app.get('/make-server-647288d6/clients/managed', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    let userProfile = null;
    try {
      userProfile = await kv.get(`user:${user.id}`);
    } catch (kvError) {
      userProfile = {
        role: user.user_metadata?.role || 'junior-writer',
        organization: user.user_metadata?.organization || 'Unknown'
      };
    }

    if (!['super-admin', 'admin'].includes(userProfile?.role)) {
      return c.json({ error: 'Insufficient permissions' }, 403);
    }

    let clients = [];
    try {
      if (userProfile?.role === 'super-admin') {
        clients = await kv.getByPrefix('client:');
      } else {
        const organization = userProfile?.organization || user.user_metadata?.organization || 'Unknown';
        clients = await kv.getByPrefix('client:');
        clients = clients.filter(c => c.organization === organization);
      }
    } catch (kvError) {
      console.log('Failed to load clients from KV store:', kvError);
      clients = [];
    }
    
    return c.json({ clients: clients || [] });
  } catch (error) {
    console.log('Error in clients/managed route:', error);
    return c.json({ clients: [] });
  }
});

// Add new client
app.post('/make-server-647288d6/clients/managed', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    let userProfile = null;
    try {
      userProfile = await kv.get(`user:${user.id}`);
    } catch (kvError) {
      userProfile = {
        role: user.user_metadata?.role || 'junior-writer',
        organization: user.user_metadata?.organization || 'Unknown'
      };
    }

    if (!['super-admin', 'admin'].includes(userProfile?.role)) {
      return c.json({ error: 'Insufficient permissions' }, 403);
    }

    const { name, email, district, phone, title, notes } = await c.req.json();

    if (!name || !email || !district) {
      return c.json({ error: 'Missing required fields: name, email, district' }, 400);
    }

    const clientId = `client:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;
    const client = {
      id: clientId,
      name,
      email,
      district,
      phone: phone || '',
      title: title || '',
      notes: notes || '',
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      created_by: user.id,
      organization: userProfile?.organization || user.user_metadata?.organization || 'Unknown',
      intake_form_sent: false,
      intake_form_completed: false,
      projects_count: 0,
      total_funding: 0
    };

    try {
      await kv.set(clientId, client);
    } catch (kvError) {
      console.log('Failed to save client to KV store:', kvError);
      return c.json({ error: 'Failed to save client' }, 500);
    }
    
    return c.json({ 
      client, 
      message: 'Client added successfully' 
    });
  } catch (error) {
    console.log('Error adding client:', error);
    return c.json({ error: 'Failed to add client' }, 500);
  }
});

// Send intake form invitation
app.post('/make-server-647288d6/clients/send-intake-invitation', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    let userProfile = null;
    try {
      userProfile = await kv.get(`user:${user.id}`);
    } catch (kvError) {
      userProfile = {
        role: user.user_metadata?.role || 'junior-writer',
        organization: user.user_metadata?.organization || 'Unknown'
      };
    }

    if (!['super-admin', 'admin'].includes(userProfile?.role)) {
      return c.json({ error: 'Insufficient permissions' }, 403);
    }

    const { client_id, client_name, client_email } = await c.req.json();

    if (!client_id || !client_name || !client_email) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const intakeToken = `intake_${Date.now()}_${Math.random().toString(36).substr(2, 16)}`;
    const intakeUrl = `${c.req.header('origin') || 'https://grantforge.ai'}/intake/${client_id}?token=${intakeToken}`;

    const invitationId = `invitation:${client_id}:${Date.now()}`;
    const invitation = {
      id: invitationId,
      client_id,
      client_name,
      client_email,
      token: intakeToken,
      sent_at: new Date().toISOString(),
      sent_by: user.id,
      sent_by_name: userProfile?.name || user.user_metadata?.name || 'Unknown User',
      completed: false,
      intake_url: intakeUrl,
      organization: userProfile?.organization || user.user_metadata?.organization || 'Unknown'
    };

    try {
      await kv.set(invitationId, invitation);
      
      try {
        const client = await kv.get(client_id);
        if (client) {
          const updatedClient = {
            ...client,
            intake_form_sent: true,
            intake_form_url: intakeUrl,
            intake_token: intakeToken,
            updated_at: new Date().toISOString()
          };
          await kv.set(client_id, updatedClient);
        }
      } catch (clientUpdateError) {
        console.log('Warning: Could not update client record:', clientUpdateError);
      }
    } catch (kvError) {
      console.log('Failed to save invitation to KV store:', kvError);
      return c.json({ error: 'Failed to create invitation' }, 500);
    }

    const emailSubject = `Complete Your Grant Writing Assessment - ${userProfile?.organization || 'GrantForge.ai'}`;
    const emailContent = `
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: 'Inter', Arial, sans-serif; margin: 0; padding: 20px; color: #0E2A47; }
        .header { background: #0E2A47; color: white; padding: 30px; border-radius: 8px; margin-bottom: 30px; text-align: center; }
        .content { background: white; padding: 30px; border-radius: 8px; border: 1px solid #E6EAF0; }
        .button { 
            display: inline-block; 
            background: #2B5EA5; 
            color: white; 
            padding: 15px 30px; 
            text-decoration: none; 
            border-radius: 8px; 
            font-weight: 600;
            margin: 20px 0;
        }
        .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #E6EAF0; font-size: 14px; color: #64748b; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🛡️ GrantForge.ai</h1>
        <p>Professional Grant Writing Services</p>
    </div>
    
    <div class="content">
        <h2>Hello ${client_name},</h2>
        
        <p>Thank you for your interest in working with our grant writing team! To provide you with the most effective grant writing services, we need to better understand your organization's needs and goals.</p>
        
        <p><strong>Please complete our Client Assessment Form:</strong></p>
        
        <div style="text-align: center; margin: 30px 0;">
            <a href="${intakeUrl}" class="button">Complete Assessment Form</a>
        </div>
        
        <p>This assessment will help us:</p>
        <ul>
            <li>Understand your organization's funding priorities</li>
            <li>Identify the most suitable grant opportunities</li>
            <li>Develop a customized grant writing strategy</li>
            <li>Estimate timelines and potential funding amounts</li>
        </ul>
        
        <p>Best regards,<br>
        <strong>${userProfile?.name || 'Your Grant Writing Team'}</strong><br>
        ${userProfile?.organization || 'GrantForge.ai'}</p>
    </div>
    
    <div class="footer">
        <p>This invitation expires in 30 days. If you need a new link, please contact your grant writing team.</p>
        <p>GrantForge.ai - Empowering K-12 Education Through Strategic Grant Writing</p>
    </div>
</body>
</html>
    `;

    try {
      await sendEmail(client_email, emailSubject, emailContent);
    } catch (emailError) {
      console.log('Email sending failed (demo mode):', emailError);
    }
    
    return c.json({ 
      success: true,
      message: 'Intake form invitation sent successfully',
      intake_url: intakeUrl,
      demo_mode: true
    });
  } catch (error) {
    console.log('Error sending intake invitation:', error);
    return c.json({ error: 'Failed to send invitation' }, 500);
  }
});

// === ANALYTICS ROUTES ===

// Get KPI metrics
app.get('/make-server-647288d6/analytics/kpi', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const period = c.req.query('period') || 'last12months';
    
    // Mock KPI data - in a real app this would come from the database
    const mockMetrics = {
      winRate: 68,
      avgProposalTime: 14.5,
      totalRevenue: 2450000,
      pipelineValue: 3200000,
      activeGrants: 24,
      completedGrants: 47,
      billableHours: 3240,
      avgHoursPerGrant: 68.9,
      clientSatisfaction: 4.7,
      teamEfficiency: 87
    };
    
    return c.json({ metrics: mockMetrics });
  } catch (error) {
    console.log('Error in analytics/kpi route:', error);
    return c.json({ error: 'Failed to load KPI metrics' }, 500);
  }
});

// Get writer performance data
app.get('/make-server-647288d6/analytics/writers', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const period = c.req.query('period') || 'last12months';
    
    // Mock writer data - in a real app this would come from the database
    const mockWriters = [
      {
        id: 'writer1',
        name: 'Lisa Thompson',
        role: 'Senior Writer',
        grantsCompleted: 12,
        billableHours: 820,
        avgHoursPerGrant: 68.3,
        winRate: 75,
        revenue: 650000,
        efficiency: 92
      }
    ];
    
    return c.json({ writers: mockWriters });
  } catch (error) {
    console.log('Error in analytics/writers route:', error);
    return c.json({ error: 'Failed to load writer performance' }, 500);
  }
});

// Get client metrics
app.get('/make-server-647288d6/analytics/clients', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const period = c.req.query('period') || 'last12months';
    
    // Mock client data - in a real app this would come from the database
    const mockClients = [
      {
        id: 'client1',
        name: 'Roosevelt Elementary School',
        grantsSubmitted: 5,
        grantsAwarded: 4,
        totalRevenue: 450000,
        avgGrantSize: 112500,
        winRate: 80,
        relationship: 'returning'
      }
    ];
    
    return c.json({ clients: mockClients });
  } catch (error) {
    console.log('Error in analytics/clients route:', error);
    return c.json({ error: 'Failed to load client metrics' }, 500);
  }
});

// Get time series data
app.get('/make-server-647288d6/analytics/timeseries', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const period = c.req.query('period') || 'last12months';
    
    // Mock time series data - in a real app this would come from the database
    const mockTimeSeries = [
      { 
        month: 'Jan 2024', 
        grants: 4, 
        revenue: 320000, 
        winRate: 75, 
        avgTime: 16.2
      },
      { 
        month: 'Feb 2024', 
        grants: 6, 
        revenue: 485000, 
        winRate: 67, 
        avgTime: 15.8
      }
    ];
    
    return c.json({ data: mockTimeSeries });
  } catch (error) {
    console.log('Error in analytics/timeseries route:', error);
    return c.json({ error: 'Failed to load time series data' }, 500);
  }
});

// Get historical comparison data
app.get('/make-server-647288d6/analytics/historical-comparison', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const period = c.req.query('period') || 'last12months';
    
    // Mock historical comparison data - in a real app this would come from uploaded historical data
    const mockHistoricalMetrics = {
      winRate: 62,
      avgProposalTime: 16.8,
      totalRevenue: 2100000,
      pipelineValue: 2800000,
      activeGrants: 20,
      completedGrants: 38,
      billableHours: 2890,
      avgHoursPerGrant: 76.1,
      clientSatisfaction: 4.4,
      teamEfficiency: 79
    };
    
    return c.json({ metrics: mockHistoricalMetrics });
  } catch (error) {
    console.log('Error in analytics/historical-comparison route:', error);
    return c.json({ error: 'Failed to load historical comparison' }, 500);
  }
});

// === REPORTS ROUTES ===

// Generate reports
app.post('/make-server-647288d6/reports/generate', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { type, period, includeCharts, includeClientBreakdown, includeHistoricalComparison } = await c.req.json();
    
    // In a real app, this would generate a PDF report
    // For demo purposes, we'll simulate this
    console.log('Generating report:', { type, period, includeCharts, includeClientBreakdown, includeHistoricalComparison });
    
    // Simulate report generation delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const reportUrl = `https://example.com/reports/${type}-${Date.now()}.pdf`;
    
    return c.json({ 
      success: true,
      reportUrl,
      message: `${type} report generated successfully`
    });
  } catch (error) {
    console.log('Error generating report:', error);
    return c.json({ error: 'Failed to generate report' }, 500);
  }
});

// Send client reports
app.post('/make-server-647288d6/reports/send-client', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { clientId, period, includeCharts } = await c.req.json();
    
    // In a real app, this would generate and send a report via email
    // For demo purposes, we'll simulate this
    console.log('Sending client report:', { clientId, period, includeCharts });
    
    // Simulate email sending delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return c.json({ 
      success: true,
      message: 'Client report sent successfully'
    });
  } catch (error) {
    console.log('Error sending client report:', error);
    return c.json({ error: 'Failed to send client report' }, 500);
  }
});

// Get alerts/notifications
app.get('/make-server-647288d6/alerts', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Mock alerts data - in a real app this would come from the database
    const mockAlerts = [
      {
        id: 'alert-1',
        type: 'grant_deadline',
        priority: 'high',
        title: 'STEM Grant Application Due Soon',
        message: 'Your STEM Education Innovation Grant application is due in 7 days.',
        created_at: new Date().toISOString(),
        read: false,
        actionRequired: true,
        data: { grantId: 'grant1', daysRemaining: 7 }
      },
      {
        id: 'alert-2',
        type: 'grant_approval_required',
        priority: 'medium',
        title: 'Grant Pending Approval',
        message: 'Rural Education Achievement Program has been submitted for your approval.',
        created_at: new Date().toISOString(),
        read: false,
        actionRequired: true,
        data: { grantId: 'grant2', grantTitle: 'Rural Education Achievement Program' }
      }
    ];
    
    return c.json({ alerts: mockAlerts });
  } catch (error) {
    console.log('Error in alerts route:', error);
    return c.json({ error: 'Failed to load alerts' }, 500);
  }
});

// Get grants (general endpoint)
app.get('/make-server-647288d6/grants', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // For now, return empty array - pipeline endpoint has the data
    return c.json({ grants: [] });
  } catch (error) {
    console.log('Error in grants route:', error);
    return c.json({ error: 'Failed to load grants' }, 500);
  }
});

// Get client intake invitations
app.get('/make-server-647288d6/clients/intake-invitations', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Mock intake invitations data
    const mockInvitations = [
      {
        id: 'invitation-1',
        client_id: 'client1',
        client_name: 'Roosevelt Elementary School',
        client_email: 'principal@roosevelt-elem.edu',
        sent_at: new Date().toISOString(),
        completed: true,
        completed_at: new Date().toISOString(),
        form_data: {
          districtSize: 'Medium (1,000-5,000 students)',
          currentChallenges: ['Funding shortfalls', 'Technology gaps'],
          grantExperience: 'Some experience',
          fundingPriorities: ['STEM programs', 'Technology upgrades'],
          timeline: 'Within 6 months'
        }
      }
    ];
    
    return c.json({ invitations: mockInvitations });
  } catch (error) {
    console.log('Error in intake-invitations route:', error);
    return c.json({ error: 'Failed to load intake invitations' }, 500);
  }
});

// === GENERAL ROUTES ===

// Get clients (for ResearchHub and other components)
app.get('/make-server-647288d6/clients', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    let userProfile = null;
    try {
      userProfile = await kv.get(`user:${user.id}`);
    } catch (kvError) {
      userProfile = {
        role: user.user_metadata?.role || 'junior-writer',
        organization: user.user_metadata?.organization || 'Unknown'
      };
    }

    let clients = [];
    try {
      if (userProfile?.role === 'super-admin') {
        clients = await kv.getByPrefix('client:');
      } else {
        const organization = userProfile?.organization || user.user_metadata?.organization || 'Unknown';
        clients = await kv.getByPrefix('client:');
        clients = clients.filter(c => c.organization === organization);
      }
    } catch (kvError) {
      console.log('Failed to load clients from KV store:', kvError);
      clients = [];
    }

    // If no clients found, provide demo clients for better UX
    if (clients.length === 0) {
      const demoClients = [
        {
          id: 'demo-client-1',
          name: 'Roosevelt Elementary School',
          email: 'principal@roosevelt-elem.edu',
          district: 'Metro City School District',
          phone: '(555) 123-4567',
          title: 'Principal',
          notes: 'Interested in STEM programs',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          organization: userProfile?.organization || user.user_metadata?.organization || 'Demo Organization',
          intake_form_sent: true,
          intake_form_completed: true,
          projects_count: 3,
          total_funding: 450000
        },
        {
          id: 'demo-client-2',
          name: 'Jefferson High School',
          email: 'admin@jefferson-high.edu',
          district: 'Springfield School District',
          phone: '(555) 987-6543',
          title: 'Superintendent',
          notes: 'Focus on technology infrastructure',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          organization: userProfile?.organization || user.user_metadata?.organization || 'Demo Organization',
          intake_form_sent: true,
          intake_form_completed: false,
          projects_count: 2,
          total_funding: 280000
        },
        {
          id: 'demo-client-3',
          name: 'Lincoln Middle School',
          email: 'director@lincoln-middle.edu',
          district: 'Oak Valley School District',
          phone: '(555) 456-7890',
          title: 'Academic Director',
          notes: 'Special education programs needed',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          organization: userProfile?.organization || user.user_metadata?.organization || 'Demo Organization',
          intake_form_sent: false,
          intake_form_completed: false,
          projects_count: 1,
          total_funding: 120000
        }
      ];
      
      // Save demo clients for future requests
      for (const client of demoClients) {
        try {
          await kv.set(client.id, client);
        } catch (saveError) {
          console.log('Could not save demo client:', saveError);
        }
      }
      
      clients = demoClients;
    }
    
    return c.json({ clients: clients || [] });
  } catch (error) {
    console.log('Error in clients route:', error);
    return c.json({ clients: [] });
  }
});

// Get grants
app.get('/make-server-647288d6/grants', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    let grants = [];
    try {
      grants = await kv.getByPrefix('grant');
    } catch (kvError) {
      console.log('Failed to load grants from KV store:', kvError);
      grants = [];
    }
    
    return c.json({ grants: grants || [] });
  } catch (error) {
    console.log('Error in grants route:', error);
    return c.json({ grants: [] });
  }
});

// Get alerts
app.get('/make-server-647288d6/alerts', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    let alerts = [];
    try {
      alerts = await kv.getByPrefix('alert:');
    } catch (kvError) {
      console.log('Failed to load alerts from KV store:', kvError);
      alerts = [];
    }
    
    return c.json({ alerts: alerts || [] });
  } catch (error) {
    console.log('Error in alerts route:', error);
    return c.json({ alerts: [] });
  }
});

// Get analytics
app.get('/make-server-647288d6/analytics', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const analytics = {
      overview: {
        totalGrants: 45,
        activeGrants: 12,
        successRate: 68,
        totalFunding: 2450000,
        avgProposalTime: 28.5
      },
      team: {
        totalUsers: 24,
        activeUsers: 18,
        topPerformers: [
          { name: 'Sarah Johnson', grants: 8, funding: 850000 },
          { name: 'Michael Chen', grants: 6, funding: 720000 },
          { name: 'Lisa Anderson', grants: 5, funding: 630000 }
        ]
      },
      trends: {
        monthly: [
          { month: 'Jan', submitted: 8, awarded: 5 },
          { month: 'Feb', submitted: 12, awarded: 8 },
          { month: 'Mar', submitted: 10, awarded: 7 },
          { month: 'Apr', submitted: 15, awarded: 10 }
        ]
      }
    };
    
    return c.json({ analytics });
  } catch (error) {
    console.log('Error in analytics route:', error);
    return c.json({ analytics: null });
  }
});

// Get KPI analytics
app.get('/make-server-647288d6/analytics/kpi', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    let userProfile = null;
    try {
      userProfile = await kv.get(`user:${user.id}`);
    } catch (kvError) {
      userProfile = {
        role: user.user_metadata?.role || 'junior-writer',
        organization: user.user_metadata?.organization || 'Unknown'
      };
    }

    if (!['super-admin', 'admin'].includes(userProfile?.role)) {
      return c.json({ error: 'Insufficient permissions' }, 403);
    }

    const kpiData = {
      totalGrants: 45,
      activeGrants: 12,
      successRate: 68,
      totalFunding: 2450000,
      avgProposalTime: 28.5,
      monthlySubmissions: 8,
      monthlyAwards: 5,
      pipelineValue: 1850000,
      teamProductivity: 85
    };
    
    return c.json(kpiData);
  } catch (error) {
    console.log('Error in KPI analytics route:', error);
    return c.json({
      totalGrants: 45,
      activeGrants: 12,
      successRate: 68,
      totalFunding: 2450000,
      avgProposalTime: 28.5,
      monthlySubmissions: 8,
      monthlyAwards: 5,
      pipelineValue: 1850000,
      teamProductivity: 85
    });
  }
});

// Get writer performance analytics
app.get('/make-server-647288d6/analytics/writers', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const writersData = [
      {
        id: '1',
        name: 'Sarah Johnson',
        role: 'Senior Writer',
        grantsCompleted: 8,
        successRate: 75,
        avgTime: 24,
        totalFunding: 850000,
        status: 'active'
      },
      {
        id: '2',
        name: 'Michael Chen',
        role: 'Senior Writer',
        grantsCompleted: 6,
        successRate: 67,
        avgTime: 28,
        totalFunding: 720000,
        status: 'active'
      },
      {
        id: '3',
        name: 'Lisa Anderson',
        role: 'Junior Writer',
        grantsCompleted: 5,
        successRate: 60,
        avgTime: 32,
        totalFunding: 630000,
        status: 'active'
      },
      {
        id: '4',
        name: 'David Rodriguez',
        role: 'Junior Writer',
        grantsCompleted: 4,
        successRate: 50,
        avgTime: 35,
        totalFunding: 480000,
        status: 'active'
      }
    ];
    
    return c.json(writersData);
  } catch (error) {
    console.log('Error in writers analytics route:', error);
    return c.json([]);
  }
});

// Get time series analytics
app.get('/make-server-647288d6/analytics/timeseries', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const timeSeriesData = [
      { period: 'Jan 2024', submissions: 8, awards: 5, funding: 450000 },
      { period: 'Feb 2024', submissions: 12, awards: 8, funding: 680000 },
      { period: 'Mar 2024', submissions: 10, awards: 7, funding: 580000 },
      { period: 'Apr 2024', submissions: 15, awards: 10, funding: 820000 },
      { period: 'May 2024', submissions: 9, awards: 6, funding: 520000 },
      { period: 'Jun 2024', submissions: 14, awards: 9, funding: 750000 },
      { period: 'Jul 2024', submissions: 11, awards: 8, funding: 650000 },
      { period: 'Aug 2024', submissions: 16, awards: 11, funding: 890000 },
      { period: 'Sep 2024', submissions: 13, awards: 9, funding: 720000 },
      { period: 'Oct 2024', submissions: 18, awards: 12, funding: 950000 },
      { period: 'Nov 2024', submissions: 12, awards: 8, funding: 680000 },
      { period: 'Dec 2024', submissions: 14, awards: 10, funding: 780000 }
    ];
    
    return c.json(timeSeriesData);
  } catch (error) {
    console.log('Error in time series analytics route:', error);
    return c.json([]);
  }
});

// Get client analytics
app.get('/make-server-647288d6/analytics/clients', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const clientsData = [
      {
        id: '1',
        name: 'Roosevelt Elementary School',
        district: 'Metro City School District',
        totalGrants: 5,
        successfulGrants: 3,
        totalFunding: 650000,
        lastActivity: '2024-12-01',
        status: 'active'
      },
      {
        id: '2',
        name: 'Jefferson High School',
        district: 'Springfield School District',
        totalGrants: 3,
        successfulGrants: 2,
        totalFunding: 480000,
        lastActivity: '2024-11-28',
        status: 'active'
      },
      {
        id: '3',
        name: 'Lincoln Middle School',
        district: 'Oak Valley School District',
        totalGrants: 4,
        successfulGrants: 4,
        totalFunding: 720000,
        lastActivity: '2024-12-03',
        status: 'active'
      },
      {
        id: '4',
        name: 'Washington Elementary',
        district: 'Pine Hills School District',
        totalGrants: 2,
        successfulGrants: 1,
        totalFunding: 180000,
        lastActivity: '2024-11-15',
        status: 'inactive'
      }
    ];
    
    return c.json(clientsData);
  } catch (error) {
    console.log('Error in clients analytics route:', error);
    return c.json([]);
  }
});

// AI Research endpoint
app.post('/make-server-647288d6/ai/research', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { grantId, grantTitle, funder, requirements } = await c.req.json();

    if (!grantId || !grantTitle || !funder) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    let research = null;
    let isDemo = true;

    if (OPENAI_API_KEY && OPENAI_API_KEY.length > 10) {
      try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'gpt-4',
            messages: [
              {
                role: 'system',
                content: 'You are an expert grant research analyst for K-12 education. Provide comprehensive research analysis for grant opportunities.'
              },
              {
                role: 'user',
                content: `Analyze this grant opportunity and provide research insights:
                
Grant: ${grantTitle}
Funder: ${funder}
Requirements: ${requirements || 'Standard K-12 education grant'}

Please provide:
1. Key requirements breakdown
2. Success factors and strategies  
3. Budget recommendations
4. Timeline considerations
5. Competitive landscape analysis`
              }
            ],
            max_tokens: 2000,
            temperature: 0.7
          })
        });

        if (response.ok) {
          const aiResponse = await response.json();
          research = {
            content: aiResponse.choices[0].message.content,
            model_used: 'gpt-4',
            generated_at: new Date().toISOString(),
            grant_id: grantId,
            grant_title: grantTitle,
            funder
          };
          isDemo = false;
        }
      } catch (aiError) {
        console.log('OpenAI request failed, using demo mode:', aiError);
      }
    }

    if (!research) {
      research = {
        content: generateMockResearch(grantTitle, funder),
        model_used: 'demo-mode',
        generated_at: new Date().toISOString(),
        grant_id: grantId,
        grant_title: grantTitle,
        funder
      };
    }

    const researchId = `research:${grantId}:${Date.now()}`;
    try {
      await kv.set(researchId, research);
    } catch (kvError) {
      console.log('Failed to save research to KV store:', kvError);
    }

    return c.json({ 
      research, 
      demo_mode: isDemo,
      message: isDemo ? 'Research completed in demo mode' : 'AI research completed successfully'
    });
  } catch (error) {
    console.log('Error in AI research:', error);
    return c.json({ 
      research: {
        content: generateMockResearch('Sample Grant', 'Demo Funder'),
        model_used: 'demo-mode-fallback',
        generated_at: new Date().toISOString()
      },
      demo_mode: true,
      message: 'Research completed in demo mode'
    });
  }
});

// AI Writing endpoint
app.post('/make-server-647288d6/ai/write', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { grantId, grantTitle, funder, clientInfo, researchNotes, section } = await c.req.json();

    if (!grantId || !grantTitle || !funder) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    let draft = null;
    let isDemo = true;

    if (OPENAI_API_KEY && OPENAI_API_KEY.length > 10) {
      try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'gpt-4',
            messages: [
              {
                role: 'system',
                content: 'You are an expert grant writer for K-12 education with extensive experience writing successful proposals. Write compelling, evidence-based grant proposals.'
              },
              {
                role: 'user',
                content: `Write a ${section || 'complete'} grant proposal for:
                
Grant: ${grantTitle}
Funder: ${funder}
Client: ${clientInfo?.clientName || 'School District'}
Research Notes: ${researchNotes || 'Use standard K-12 education best practices'}

Please create a professional, compelling proposal section that addresses the funder's priorities and demonstrates clear educational impact.`
              }
            ],
            max_tokens: 3000,
            temperature: 0.7
          })
        });

        if (response.ok) {
          const aiResponse = await response.json();
          draft = {
            content: aiResponse.choices[0].message.content,
            model_used: 'gpt-4',
            generated_at: new Date().toISOString(),
            grant_id: grantId,
            grant_title: grantTitle,
            funder,
            section: section || 'complete',
            client_info: clientInfo
          };
          isDemo = false;
        }
      } catch (aiError) {
        console.log('OpenAI request failed, using demo mode:', aiError);
      }
    }

    if (!draft) {
      draft = {
        content: generateMockDraft(grantTitle, funder, clientInfo),
        model_used: 'demo-mode',
        generated_at: new Date().toISOString(),
        grant_id: grantId,
        grant_title: grantTitle,
        funder,
        section: section || 'complete',
        client_info: clientInfo
      };
    }

    const draftId = `draft:${grantId}:${Date.now()}`;
    try {
      await kv.set(draftId, draft);
    } catch (kvError) {
      console.log('Failed to save draft to KV store:', kvError);
    }

    return c.json({ 
      draft, 
      demo_mode: isDemo,
      message: isDemo ? 'Draft completed in demo mode' : 'AI writing completed successfully'
    });
  } catch (error) {
    console.log('Error in AI writing:', error);
    return c.json({ 
      draft: {
        content: generateMockDraft('Sample Grant', 'Demo Funder', {}),
        model_used: 'demo-mode-fallback',
        generated_at: new Date().toISOString()
      },
      demo_mode: true,
      message: 'Draft completed in demo mode'
    });
  }
});

// Start server
Deno.serve(app.fetch);