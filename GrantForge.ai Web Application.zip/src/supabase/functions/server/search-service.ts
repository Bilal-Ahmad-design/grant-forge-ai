import * as kv from './kv_store.tsx';

export interface SearchRequest {
  keyword?: string;
  category?: string;
  agency?: string;
  eligibility?: string[];
  location?: string;
  amountMin?: number;
  amountMax?: number;
  deadline?: {
    min?: string;
    max?: string;
  };
  sources?: string[];
  difficulty?: string[];
  status?: string[];
  tags?: string[];
  includeExpired?: boolean;
  sortBy?: 'relevance' | 'deadline' | 'amount' | 'updated';
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
  userId?: string;
}

export interface SearchResponse {
  grants: any[];
  total: number;
  sources: {
    [sourceId: string]: {
      count: number;
      status: 'success' | 'error' | 'timeout';
      error?: string;
      fetchTime: number;
    };
  };
  searchTime: number;
  cached: boolean;
  filters: SearchRequest;
  suggestions?: string[];
}

export async function handleGrantSearch(request: Request): Promise<Response> {
  try {
    const searchParams = new URL(request.url).searchParams;
    const userId = request.headers.get('x-user-id');

    const searchRequest: SearchRequest = {
      keyword: searchParams.get('keyword') || undefined,
      category: searchParams.get('category') || undefined,
      agency: searchParams.get('agency') || undefined,
      eligibility: searchParams.get('eligibility')?.split(',') || undefined,
      location: searchParams.get('location') || undefined,
      amountMin: searchParams.get('amountMin') ? parseInt(searchParams.get('amountMin')!) : undefined,
      amountMax: searchParams.get('amountMax') ? parseInt(searchParams.get('amountMax')!) : undefined,
      deadline: {
        min: searchParams.get('deadlineMin') || undefined,
        max: searchParams.get('deadlineMax') || undefined
      },
      sources: searchParams.get('sources')?.split(',') || undefined,
      difficulty: searchParams.get('difficulty')?.split(',') || undefined,
      status: searchParams.get('status')?.split(',') || undefined,
      tags: searchParams.get('tags')?.split(',') || undefined,
      includeExpired: searchParams.get('includeExpired') === 'true',
      sortBy: (searchParams.get('sortBy') as any) || 'relevance',
      sortOrder: (searchParams.get('sortOrder') as any) || 'desc',
      limit: searchParams.get('limit') ? parseInt(searchParams.get('limit')!) : 50,
      offset: searchParams.get('offset') ? parseInt(searchParams.get('offset')!) : 0,
      userId
    };

    // Check cache first
    const cacheKey = `grant_search:${JSON.stringify(searchRequest)}`;
    const cached = await kv.get(cacheKey);
    
    if (cached && cached.expires > Date.now()) {
      return new Response(JSON.stringify({
        ...cached.result,
        cached: true
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const startTime = Date.now();

    // Execute multi-source search
    const searchResults = await executeMultiSourceSearch(searchRequest);

    // Apply user preferences and saved grants
    if (userId) {
      await applyUserPreferences(searchResults, userId);
    }

    // Cache the results
    await kv.set(cacheKey, {
      result: searchResults,
      expires: Date.now() + 300000 // 5 minutes
    });

    return new Response(JSON.stringify(searchResults), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Grant search error:', error);
    return new Response(JSON.stringify({
      error: 'Failed to search grants',
      message: error.message,
      grants: [],
      total: 0,
      sources: {},
      searchTime: 0,
      cached: false
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function executeMultiSourceSearch(searchRequest: SearchRequest): Promise<SearchResponse> {
  const searchTime = Date.now();
  
  // Define available sources with their configurations
  const sources = [
    {
      id: 'grants-gov',
      name: 'Grants.gov',
      priority: 10,
      enabled: true,
      fetch: fetchGrantsGovData
    },
    {
      id: 'sam-gov',
      name: 'SAM.gov',
      priority: 9,
      enabled: true,
      fetch: fetchSamGovData
    },
    {
      id: 'schoolsafety-gov',
      name: 'SchoolSafety.gov',
      priority: 7,
      enabled: true,
      fetch: fetchSchoolSafetyData
    },
    {
      id: 'candid',
      name: 'Candid',
      priority: 8,
      enabled: true,
      fetch: fetchCandidData
    },
    {
      id: 'grantwatch',
      name: 'GrantWatch',
      priority: 6,
      enabled: true,
      fetch: fetchGrantWatchData
    },
    {
      id: 'state-doe',
      name: 'State DOE',
      priority: 5,
      enabled: true,
      fetch: fetchStateDOEData
    }
  ];

  // Filter sources based on request
  const activeSources = sources.filter(source => {
    if (searchRequest.sources && searchRequest.sources.length > 0) {
      return searchRequest.sources.includes(source.id);
    }
    return source.enabled;
  });

  // Execute searches in parallel with timeout
  const searchPromises = activeSources.map(async (source) => {
    const sourceStartTime = Date.now();
    try {
      const result = await Promise.race([
        source.fetch(searchRequest),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout')), 10000)
        )
      ]) as any[];

      return {
        sourceId: source.id,
        grants: result,
        status: 'success' as const,
        fetchTime: Date.now() - sourceStartTime
      };
    } catch (error: any) {
      return {
        sourceId: source.id,
        grants: [],
        status: error.message === 'Timeout' ? 'timeout' as const : 'error' as const,
        error: error.message,
        fetchTime: Date.now() - sourceStartTime
      };
    }
  });

  const results = await Promise.all(searchPromises);

  // Collect all grants and source statistics
  const allGrants: any[] = [];
  const sourceStats: SearchResponse['sources'] = {};

  results.forEach(result => {
    allGrants.push(...result.grants);
    sourceStats[result.sourceId] = {
      count: result.grants.length,
      status: result.status,
      error: (result as any).error,
      fetchTime: result.fetchTime
    };
  });

  // Normalize and deduplicate grants
  const normalizedGrants = normalizeGrants(allGrants);
  const deduplicatedGrants = deduplicateGrants(normalizedGrants);

  // Apply filtering and sorting
  const filteredGrants = applyAdvancedFilters(deduplicatedGrants, searchRequest);
  const sortedGrants = sortGrants(filteredGrants, searchRequest);

  // Paginate results
  const startIndex = searchRequest.offset || 0;
  const endIndex = startIndex + (searchRequest.limit || 50);
  const paginatedGrants = sortedGrants.slice(startIndex, endIndex);

  // Generate search suggestions
  const suggestions = generateSearchSuggestions(searchRequest, sortedGrants);

  return {
    grants: paginatedGrants,
    total: sortedGrants.length,
    sources: sourceStats,
    searchTime: Date.now() - searchTime,
    cached: false,
    filters: searchRequest,
    suggestions
  };
}

// Source-specific fetch functions
async function fetchGrantsGovData(searchRequest: SearchRequest): Promise<any[]> {
  // Enhanced Grants.gov implementation
  const mockGrants = [
    {
      id: 'grants-gov-001',
      title: 'Supporting Effective Instruction State Grants Program',
      description: 'Grants to improve the quality and effectiveness of teachers, principals, and other school leaders.',
      funder: 'U.S. Department of Education',
      amount: '$2,500,000',
      deadline: '2024-10-15',
      category: 'Teacher Quality',
      eligibility: ['State education agencies', 'Local education agencies'],
      location: 'National',
      tags: ['Education', 'Teacher Training', 'Federal'],
      difficulty: 'Medium',
      status: 'Open',
      source: 'grants-gov',
      opportunityNumber: 'ED-GRANTS-071924-001',
      cfda: '84.367',
      isNew: true,
      matchRequired: false,
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'grants-gov-002',
      title: 'Discovery Research PreK-12 (DRK-12)',
      description: 'Research and development of STEM education innovations for grades PreK-12.',
      funder: 'National Science Foundation',
      amount: '$1,200,000',
      deadline: '2024-09-30',
      category: 'STEM Education',
      eligibility: ['Institutions of higher education', 'Non-profit organizations'],
      location: 'National',
      tags: ['STEM', 'Research', 'PreK-12'],
      difficulty: 'Hard',
      status: 'Open',
      source: 'grants-gov',
      opportunityNumber: 'NSF-24-587',
      cfda: '47.076',
      isNew: true,
      matchRequired: true,
      lastUpdated: new Date().toISOString()
    }
  ];

  return applyBasicFilters(mockGrants, searchRequest);
}

async function fetchSamGovData(searchRequest: SearchRequest): Promise<any[]> {
  const mockGrants = [
    {
      id: 'sam-gov-001',
      title: 'Infrastructure Investment and Jobs Act Education Grants',
      description: 'Funding for educational infrastructure improvements including technology upgrades.',
      funder: 'Department of Transportation',
      amount: '$10,000,000',
      deadline: '2024-11-30',
      category: 'Infrastructure',
      eligibility: ['State governments', 'Local governments'],
      location: 'National',
      tags: ['Infrastructure', 'Technology', 'Federal'],
      difficulty: 'Hard',
      status: 'Open',
      source: 'sam-gov',
      opportunityNumber: 'DOT-IIJA-2024-001',
      isNew: false,
      matchRequired: true,
      matchPercentage: 25,
      lastUpdated: new Date().toISOString()
    }
  ];

  return applyBasicFilters(mockGrants, searchRequest);
}

async function fetchSchoolSafetyData(searchRequest: SearchRequest): Promise<any[]> {
  const mockGrants = [
    {
      id: 'schoolsafety-001',
      title: 'School Safety Infrastructure Grants',
      description: 'Funding for physical security improvements and emergency communications.',
      funder: 'Department of Homeland Security',
      amount: '$500,000',
      deadline: '2024-12-15',
      category: 'School Safety',
      eligibility: ['Public K-12 schools', 'School districts'],
      location: 'National',
      tags: ['Safety', 'Security', 'Infrastructure'],
      difficulty: 'Medium',
      status: 'Open',
      source: 'schoolsafety-gov',
      opportunityNumber: 'DHS-SS-2024-001',
      isNew: true,
      matchRequired: false,
      lastUpdated: new Date().toISOString()
    }
  ];

  return applyBasicFilters(mockGrants, searchRequest);
}

async function fetchCandidData(searchRequest: SearchRequest): Promise<any[]> {
  const mockGrants = [
    {
      id: 'candid-001',
      title: 'Gates Foundation Education Innovation Grant',
      description: 'Supporting innovative approaches to improve educational outcomes.',
      funder: 'Bill & Melinda Gates Foundation',
      amount: '$1,000,000',
      deadline: '2024-12-31',
      category: 'Education Innovation',
      eligibility: ['Nonprofit organizations', 'Educational institutions'],
      location: 'National',
      tags: ['Innovation', 'Foundation', 'Private Funding'],
      difficulty: 'Medium',
      status: 'Open',
      source: 'candid',
      opportunityNumber: 'GATES-EDU-2024-001',
      isNew: false,
      matchRequired: false,
      lastUpdated: new Date().toISOString()
    }
  ];

  return applyBasicFilters(mockGrants, searchRequest);
}

async function fetchGrantWatchData(searchRequest: SearchRequest): Promise<any[]> {
  const mockGrants = [
    {
      id: 'grantwatch-001',
      title: 'Texas Education Agency STEM Innovation Grant',
      description: 'State funding for innovative STEM programs in Texas public schools.',
      funder: 'Texas Education Agency',
      amount: '$150,000',
      deadline: '2024-09-30',
      category: 'STEM Education',
      eligibility: ['Public schools', 'School districts'],
      location: 'Texas',
      tags: ['STEM', 'State Funding', 'Texas'],
      difficulty: 'Easy',
      status: 'Open',
      source: 'grantwatch',
      opportunityNumber: 'TEA-STEM-2024-001',
      isNew: true,
      matchRequired: true,
      matchPercentage: 10,
      lastUpdated: new Date().toISOString()
    }
  ];

  return applyBasicFilters(mockGrants, searchRequest);
}

async function fetchStateDOEData(searchRequest: SearchRequest): Promise<any[]> {
  const mockGrants = [
    {
      id: 'state-doe-001',
      title: 'New York Every Student Succeeds Act Implementation',
      description: 'State funding to support ESSA compliance and improvement initiatives.',
      funder: 'New York Department of Education',
      amount: '$400,000',
      deadline: '2024-10-30',
      category: 'ESSA Implementation',
      eligibility: ['Public school districts', 'Charter schools'],
      location: 'New York',
      tags: ['ESSA', 'State DOE', 'New York'],
      difficulty: 'Medium',
      status: 'Open',
      source: 'state-doe',
      opportunityNumber: 'NYDOE-ESSA-2024-001',
      isNew: false,
      matchRequired: false,
      lastUpdated: new Date().toISOString()
    }
  ];

  return applyBasicFilters(mockGrants, searchRequest);
}

function applyBasicFilters(grants: any[], searchRequest: SearchRequest): any[] {
  let filtered = grants;

  if (searchRequest.keyword) {
    const keyword = searchRequest.keyword.toLowerCase();
    filtered = filtered.filter(grant =>
      grant.title.toLowerCase().includes(keyword) ||
      grant.description.toLowerCase().includes(keyword) ||
      grant.funder.toLowerCase().includes(keyword) ||
      grant.tags.some((tag: string) => tag.toLowerCase().includes(keyword))
    );
  }

  if (searchRequest.category && searchRequest.category !== 'all') {
    filtered = filtered.filter(grant => grant.category === searchRequest.category);
  }

  if (searchRequest.agency && searchRequest.agency !== 'all') {
    filtered = filtered.filter(grant => grant.funder.includes(searchRequest.agency));
  }

  if (searchRequest.location && searchRequest.location !== 'all') {
    filtered = filtered.filter(grant => 
      grant.location === 'National' || grant.location === searchRequest.location
    );
  }

  return filtered;
}

function normalizeGrants(grants: any[]): any[] {
  return grants.map(grant => ({
    ...grant,
    // Ensure consistent field names and formats
    title: grant.title?.trim() || 'Untitled Grant',
    description: grant.description?.trim() || '',
    amount: normalizeAmount(grant.amount),
    deadline: normalizeDate(grant.deadline),
    category: normalizeCategory(grant.category),
    eligibility: Array.isArray(grant.eligibility) ? grant.eligibility : [grant.eligibility || 'See details'],
    tags: Array.isArray(grant.tags) ? grant.tags : [],
    daysUntilDeadline: calculateDaysUntilDeadline(grant.deadline),
    normalizedTitle: grant.title?.toLowerCase().replace(/[^\w\s]/g, '').trim(),
    normalizedFunder: grant.funder?.toLowerCase().trim()
  }));
}

function deduplicateGrants(grants: any[]): any[] {
  const seen = new Map();
  const deduplicated: any[] = [];

  grants.forEach(grant => {
    // Create a key for deduplication based on title similarity and funder
    const key = `${grant.normalizedTitle}-${grant.normalizedFunder}`;
    
    if (!seen.has(key)) {
      seen.set(key, grant);
      deduplicated.push(grant);
    } else {
      // Merge sources if we find a duplicate
      const existing = seen.get(key);
      existing.sources = existing.sources || [existing.source];
      if (!existing.sources.includes(grant.source)) {
        existing.sources.push(grant.source);
      }
      // Keep the most recent data
      if (new Date(grant.lastUpdated) > new Date(existing.lastUpdated)) {
        existing.lastUpdated = grant.lastUpdated;
      }
    }
  });

  return deduplicated;
}

function applyAdvancedFilters(grants: any[], searchRequest: SearchRequest): any[] {
  let filtered = grants;

  if (searchRequest.amountMin || searchRequest.amountMax) {
    filtered = filtered.filter(grant => {
      const amount = parseInt(grant.amount.replace(/[^\d]/g, '') || '0');
      const min = searchRequest.amountMin || 0;
      const max = searchRequest.amountMax || Infinity;
      return amount >= min && amount <= max;
    });
  }

  if (searchRequest.deadline?.min || searchRequest.deadline?.max) {
    filtered = filtered.filter(grant => {
      const deadline = new Date(grant.deadline);
      const min = searchRequest.deadline?.min ? new Date(searchRequest.deadline.min) : new Date(0);
      const max = searchRequest.deadline?.max ? new Date(searchRequest.deadline.max) : new Date('2099-12-31');
      return deadline >= min && deadline <= max;
    });
  }

  if (searchRequest.difficulty && searchRequest.difficulty.length > 0) {
    filtered = filtered.filter(grant => searchRequest.difficulty!.includes(grant.difficulty));
  }

  if (searchRequest.status && searchRequest.status.length > 0) {
    filtered = filtered.filter(grant => searchRequest.status!.includes(grant.status));
  }

  if (searchRequest.tags && searchRequest.tags.length > 0) {
    filtered = filtered.filter(grant => 
      searchRequest.tags!.some(tag => grant.tags.includes(tag))
    );
  }

  if (!searchRequest.includeExpired) {
    filtered = filtered.filter(grant => grant.daysUntilDeadline >= 0);
  }

  return filtered;
}

function sortGrants(grants: any[], searchRequest: SearchRequest): any[] {
  const sortBy = searchRequest.sortBy || 'relevance';
  const sortOrder = searchRequest.sortOrder || 'desc';

  return grants.sort((a, b) => {
    let comparison = 0;

    switch (sortBy) {
      case 'deadline':
        comparison = new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
        break;
      case 'amount':
        const amountA = parseInt(a.amount.replace(/[^\d]/g, '') || '0');
        const amountB = parseInt(b.amount.replace(/[^\d]/g, '') || '0');
        comparison = amountA - amountB;
        break;
      case 'updated':
        comparison = new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
        break;
      case 'relevance':
      default:
        // Sort by multiple factors: sources count, newness, deadline proximity
        const sourcesA = Array.isArray(a.sources) ? a.sources.length : 1;
        const sourcesB = Array.isArray(b.sources) ? b.sources.length : 1;
        comparison = (sourcesB - sourcesA) || 
                    (Number(b.isNew) - Number(a.isNew)) ||
                    (a.daysUntilDeadline - b.daysUntilDeadline);
        break;
    }

    return sortOrder === 'asc' ? comparison : -comparison;
  });
}

async function applyUserPreferences(searchResults: SearchResponse, userId: string): Promise<void> {
  try {
    // Get user's saved grants
    const savedGrants = await kv.get(`user_saved_grants:${userId}`) || [];
    const viewedGrants = await kv.get(`user_viewed_grants:${userId}`) || [];

    // Mark grants as saved or viewed
    searchResults.grants.forEach(grant => {
      grant.saved = savedGrants.includes(grant.id);
      grant.viewed = viewedGrants.includes(grant.id);
    });

    // Get user preferences for relevance scoring
    const userPrefs = await kv.get(`user_preferences:${userId}`);
    if (userPrefs) {
      // Apply relevance scoring based on user preferences
      searchResults.grants.forEach(grant => {
        grant.relevanceScore = calculateRelevanceScore(grant, userPrefs);
      });
    }
  } catch (error) {
    console.error('Error applying user preferences:', error);
  }
}

function calculateRelevanceScore(grant: any, userPrefs: any): number {
  let score = 50; // Base score

  // Preferred categories
  if (userPrefs.preferredCategories?.includes(grant.category)) {
    score += 20;
  }

  // Preferred funders
  if (userPrefs.preferredFunders?.includes(grant.funder)) {
    score += 15;
  }

  // Amount range preference
  const amount = parseInt(grant.amount.replace(/[^\d]/g, '') || '0');
  if (amount >= (userPrefs.minAmount || 0) && amount <= (userPrefs.maxAmount || Infinity)) {
    score += 10;
  }

  // Geographic preference
  if (userPrefs.preferredLocations?.includes(grant.location)) {
    score += 10;
  }

  // Difficulty preference
  if (userPrefs.preferredDifficulty === grant.difficulty) {
    score += 5;
  }

  return Math.min(100, Math.max(0, score));
}

function generateSearchSuggestions(searchRequest: SearchRequest, results: any[]): string[] {
  const suggestions: string[] = [];

  // Popular categories from results
  const categories = results.map(g => g.category);
  const categoryCount = categories.reduce((acc, cat) => {
    acc[cat] = (acc[cat] || 0) + 1;
    return acc;
  }, {} as { [key: string]: number });

  const topCategories = Object.entries(categoryCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([cat]) => cat);

  suggestions.push(...topCategories);

  // Related terms based on current search
  if (searchRequest.keyword) {
    const relatedTerms = generateRelatedTerms(searchRequest.keyword);
    suggestions.push(...relatedTerms);
  }

  return [...new Set(suggestions)].slice(0, 5);
}

function generateRelatedTerms(keyword: string): string[] {
  const termMap: { [key: string]: string[] } = {
    'stem': ['science', 'technology', 'engineering', 'mathematics'],
    'education': ['learning', 'instruction', 'curriculum', 'teaching'],
    'safety': ['security', 'emergency', 'crisis', 'prevention'],
    'technology': ['digital', 'computer', 'innovation', 'tech'],
    'arts': ['creative', 'music', 'visual', 'performance']
  };

  const lowerKeyword = keyword.toLowerCase();
  for (const [key, terms] of Object.entries(termMap)) {
    if (lowerKeyword.includes(key)) {
      return terms;
    }
  }

  return [];
}

// Utility functions
function normalizeAmount(amount: string): string {
  if (!amount) return 'Amount TBD';
  const numbers = amount.match(/[\d,]+/g);
  if (numbers) {
    const num = parseInt(numbers[0].replace(/,/g, ''));
    return `$${num.toLocaleString()}`;
  }
  return amount;
}

function normalizeDate(date: string): string {
  try {
    return new Date(date).toISOString().split('T')[0];
  } catch {
    return date;
  }
}

function normalizeCategory(category: string): string {
  const categoryMap: { [key: string]: string } = {
    'stem education': 'STEM Education',
    'stem': 'STEM Education',
    'teacher training': 'Teacher Quality',
    'professional development': 'Teacher Quality',
    'school safety': 'School Safety',
    'infrastructure': 'Infrastructure',
    'arts': 'Arts Education'
  };

  const normalized = category?.toLowerCase() || '';
  return categoryMap[normalized] || category || 'General';
}

function calculateDaysUntilDeadline(deadline: string): number {
  try {
    const deadlineDate = new Date(deadline);
    const today = new Date();
    const diffTime = deadlineDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  } catch {
    return -1;
  }
}

// Additional API endpoints for source management
export async function handleGetSources(request: Request): Promise<Response> {
  const sources = [
    {
      id: 'grants-gov',
      name: 'Grants.gov',
      description: 'Federal grant opportunities from all agencies',
      enabled: true,
      priority: 10,
      categories: ['Federal', 'Education', 'STEM', 'Infrastructure'],
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'sam-gov',
      name: 'SAM.gov',
      description: 'Federal procurement and grant opportunities',
      enabled: true,
      priority: 9,
      categories: ['Federal', 'Infrastructure', 'Technology'],
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'schoolsafety-gov',
      name: 'SchoolSafety.gov',
      description: 'School safety and security grants',
      enabled: true,
      priority: 7,
      categories: ['Safety', 'Security', 'K-12'],
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'candid',
      name: 'Candid (Foundation Center)',
      description: 'Foundation and private funding opportunities',
      enabled: true,
      priority: 8,
      categories: ['Foundation', 'Private', 'Nonprofit'],
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'grantwatch',
      name: 'GrantWatch',
      description: 'State and local grant opportunities',
      enabled: true,
      priority: 6,
      categories: ['State', 'Local', 'Regional'],
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'state-doe',
      name: 'State DOE Aggregator',
      description: 'State department of education grants',
      enabled: true,
      priority: 5,
      categories: ['State', 'Education', 'K-12'],
      lastUpdated: new Date().toISOString()
    }
  ];

  return new Response(JSON.stringify({ sources }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}

export async function handleSaveGrant(request: Request): Promise<Response> {
  try {
    const { userId, grantId } = await request.json();

    if (!userId || !grantId) {
      return new Response(JSON.stringify({ error: 'Missing userId or grantId' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const savedGrants = await kv.get(`user_saved_grants:${userId}`) || [];
    
    if (!savedGrants.includes(grantId)) {
      savedGrants.push(grantId);
      await kv.set(`user_saved_grants:${userId}`, savedGrants);
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error saving grant:', error);
    return new Response(JSON.stringify({ error: 'Failed to save grant' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function handleUnsaveGrant(request: Request): Promise<Response> {
  try {
    const { userId, grantId } = await request.json();

    if (!userId || !grantId) {
      return new Response(JSON.stringify({ error: 'Missing userId or grantId' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const savedGrants = await kv.get(`user_saved_grants:${userId}`) || [];
    const updatedSavedGrants = savedGrants.filter((id: string) => id !== grantId);
    
    await kv.set(`user_saved_grants:${userId}`, updatedSavedGrants);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Error unsaving grant:', error);
    return new Response(JSON.stringify({ error: 'Failed to unsave grant' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}