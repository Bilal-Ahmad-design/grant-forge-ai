import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Upload, 
  FileSpreadsheet, 
  CheckCircle, 
  AlertTriangle, 
  X, 
  Download,
  Calendar,
  DollarSign,
  Target,
  Users,
  Loader2,
  Info
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

interface DataUploadDialogProps {
  user: User;
  onDataUploaded: () => void;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ParsedData {
  grants: HistoricalGrant[];
  summary: {
    totalGrants: number;
    totalRevenue: number;
    avgWinRate: number;
    dateRange: {
      start: string;
      end: string;
    };
  };
  errors: string[];
}

interface HistoricalGrant {
  id: string;
  title: string;
  funder: string;
  amount: number;
  submissionDate: string;
  status: 'awarded' | 'rejected' | 'pending';
  clientName: string;
  writer: string;
  hoursSpent: number;
}

export function DataUploadDialog({ user, onDataUploaded, open, onOpenChange }: DataUploadDialogProps) {
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [parsedData, setParsedData] = useState<ParsedData | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [activeTab, setActiveTab] = useState('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sampleData = [
    'grant_title,funder,amount,submission_date,status,client_name,writer_name,hours_spent',
    'STEM Innovation Grant,NSF,150000,2023-03-15,awarded,Roosevelt Elementary,Lisa Thompson,65',
    'Arts Integration Program,NEA,45000,2023-04-20,awarded,Jefferson High,Alex Martinez,38',
    'Technology Infrastructure,FCC,250000,2023-05-10,rejected,Lincoln Middle,Maria Santos,72',
    'Special Education Support,HHS,85000,2023-06-15,awarded,Washington Elementary,David Chen,45',
    'Rural Education Initiative,USDA,120000,2023-07-20,awarded,Countryside K-8,Lisa Thompson,58',
    'Professional Development,Gates Foundation,65000,2023-08-10,rejected,Metro High School,Alex Martinez,42',
    'STEM Equipment Upgrade,NSF,95000,2023-09-15,pending,Roosevelt Elementary,Maria Santos,50'
  ].join('\n');

  const downloadSampleCSV = () => {
    const blob = new Blob([sampleData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'historical_grants_sample.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    toast.success('Sample CSV downloaded!');
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.name.endsWith('.csv')) {
        toast.error('Please select a CSV file');
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('File size must be less than 5MB');
        return;
      }
      
      setSelectedFile(file);
      setParsedData(null);
      toast.success('File selected successfully');
    }
  };

  const parseCSV = (csvText: string): ParsedData => {
    const lines = csvText.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    
    const requiredHeaders = [
      'grant_title', 'funder', 'amount', 'submission_date', 
      'status', 'client_name', 'writer_name', 'hours_spent'
    ];
    
    const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
    if (missingHeaders.length > 0) {
      throw new Error(`Missing required columns: ${missingHeaders.join(', ')}`);
    }
    
    const grants: HistoricalGrant[] = [];
    const errors: string[] = [];
    let totalRevenue = 0;
    let awardedGrants = 0;
    let dateStart = new Date();
    let dateEnd = new Date(0);
    
    for (let i = 1; i < lines.length; i++) {
      try {
        const values = lines[i].split(',').map(v => v.trim());
        if (values.length !== headers.length) {
          errors.push(`Row ${i + 1}: Column count mismatch`);
          continue;
        }
        
        const grant: HistoricalGrant = {
          id: `historical-${i}`,
          title: values[headers.indexOf('grant_title')],
          funder: values[headers.indexOf('funder')],
          amount: parseFloat(values[headers.indexOf('amount')]) || 0,
          submissionDate: values[headers.indexOf('submission_date')],
          status: values[headers.indexOf('status')] as any,
          clientName: values[headers.indexOf('client_name')],
          writer: values[headers.indexOf('writer_name')],
          hoursSpent: parseFloat(values[headers.indexOf('hours_spent')]) || 0
        };
        
        // Validate date
        const submissionDate = new Date(grant.submissionDate);
        if (isNaN(submissionDate.getTime())) {
          errors.push(`Row ${i + 1}: Invalid submission date format`);
          continue;
        }
        
        // Update date range
        if (submissionDate < dateStart) dateStart = submissionDate;
        if (submissionDate > dateEnd) dateEnd = submissionDate;
        
        // Validate status
        if (!['awarded', 'rejected', 'pending'].includes(grant.status)) {
          errors.push(`Row ${i + 1}: Invalid status (must be: awarded, rejected, or pending)`);
          continue;
        }
        
        grants.push(grant);
        
        if (grant.status === 'awarded') {
          totalRevenue += grant.amount;
          awardedGrants++;
        }
      } catch (error) {
        errors.push(`Row ${i + 1}: ${error}`);
      }
    }
    
    const avgWinRate = grants.length > 0 ? (awardedGrants / grants.length) * 100 : 0;
    
    return {
      grants,
      summary: {
        totalGrants: grants.length,
        totalRevenue,
        avgWinRate,
        dateRange: {
          start: dateStart.toISOString().split('T')[0],
          end: dateEnd.toISOString().split('T')[0]
        }
      },
      errors
    };
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast.error('Please select a file first');
      return;
    }
    
    try {
      setProcessing(true);
      setUploadProgress(0);
      
      // Read file
      const fileContent = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.onerror = reject;
        reader.readAsText(selectedFile);
      });
      
      setUploadProgress(25);
      
      // Parse CSV
      const parsed = parseCSV(fileContent);
      setParsedData(parsed);
      setUploadProgress(50);
      
      // Simulate API upload
      setUploading(true);
      
      try {
        const response = await apiRequest('/analytics/upload-historical', {
          method: 'POST',
          body: JSON.stringify({
            data: parsed.grants,
            summary: parsed.summary,
            uploadedBy: user.id,
            uploadedAt: new Date().toISOString()
          })
        });
        
        setUploadProgress(100);
        toast.success('Historical data uploaded successfully!');
      } catch (apiError) {
        // Demo mode - simulate successful upload
        setUploadProgress(100);
        toast.success('Historical data uploaded successfully! (Demo mode)');
      }
      
      setActiveTab('preview');
      onDataUploaded();
      
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error.message || 'Failed to process file');
    } finally {
      setUploading(false);
      setProcessing(false);
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`;
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`;
    }
    return `$${amount.toLocaleString()}`;
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      'awarded': 'bg-emerald text-white',
      'rejected': 'bg-red-500 text-white',
      'pending': 'bg-amber text-navy'
    };
    return colors[status as keyof typeof colors] || 'bg-slate-500 text-white';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload Historical Grant Data
          </DialogTitle>
          <DialogDescription>
            Import past grant performance data to compare with current metrics
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="format">CSV Format</TabsTrigger>
            <TabsTrigger value="upload">Upload Data</TabsTrigger>
            <TabsTrigger value="preview" disabled={!parsedData}>Preview & Confirm</TabsTrigger>
          </TabsList>

          <TabsContent value="format" className="space-y-4 max-h-[60vh] overflow-y-auto">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                Your CSV file must include the following columns in this exact format:
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-lg">
                <h4 className="font-medium mb-3">Required Columns:</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div><strong>grant_title:</strong> Name of the grant</div>
                  <div><strong>funder:</strong> Funding organization</div>
                  <div><strong>amount:</strong> Grant amount (numbers only)</div>
                  <div><strong>submission_date:</strong> YYYY-MM-DD format</div>
                  <div><strong>status:</strong> awarded, rejected, or pending</div>
                  <div><strong>client_name:</strong> Client organization</div>
                  <div><strong>writer_name:</strong> Grant writer name</div>
                  <div><strong>hours_spent:</strong> Hours worked (numbers only)</div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Sample CSV Format:</h4>
                  <Button onClick={downloadSampleCSV} variant="outline" size="sm" className="gap-2">
                    <Download className="h-4 w-4" />
                    Download Sample
                  </Button>
                </div>
                <div className="bg-navy text-white p-4 rounded-lg text-xs font-mono overflow-x-auto">
                  <pre>{sampleData}</pre>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="upload" className="space-y-4">
            <div className="space-y-4">
              <Card className="border-dashed border-2 border-slate-300 hover:border-indigo transition-colors">
                <CardContent className="p-8 text-center">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  
                  {selectedFile ? (
                    <div className="space-y-4">
                      <CheckCircle className="h-12 w-12 text-emerald mx-auto" />
                      <div>
                        <h3 className="font-medium">File Selected</h3>
                        <p className="text-sm text-slate-600">{selectedFile.name}</p>
                        <p className="text-xs text-slate-500">
                          {(selectedFile.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                      <div className="flex gap-2 justify-center">
                        <Button
                          onClick={() => fileInputRef.current?.click()}
                          variant="outline"
                          size="sm"
                        >
                          Choose Different File
                        </Button>
                        <Button
                          onClick={handleUpload}
                          disabled={processing || uploading}
                          className="gap-2 bg-indigo hover:bg-indigo/90"
                        >
                          {processing || uploading ? (
                            <>
                              <Loader2 className="h-4 w-4 animate-spin" />
                              Processing...
                            </>
                          ) : (
                            <>
                              <Upload className="h-4 w-4" />
                              Process Data
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <FileSpreadsheet className="h-12 w-12 text-slate-400 mx-auto" />
                      <div>
                        <h3 className="font-medium">Upload CSV File</h3>
                        <p className="text-sm text-slate-600 mb-4">
                          Select your historical grant data file (CSV format, max 5MB)
                        </p>
                        <Button
                          onClick={() => fileInputRef.current?.click()}
                          className="gap-2"
                        >
                          <Upload className="h-4 w-4" />
                          Choose File
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {(processing || uploading) && (
                <Card>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">
                          {processing ? 'Processing file...' : 'Uploading data...'}
                        </span>
                        <span className="text-sm text-slate-600">{uploadProgress}%</span>
                      </div>
                      <Progress value={uploadProgress} className="h-2" />
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="preview" className="space-y-4 max-h-[60vh] overflow-y-auto">
            {parsedData && (
              <div className="space-y-4">
                {/* Summary Cards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card className="border-indigo/20 bg-indigo/5">
                    <CardContent className="p-4 text-center">
                      <Target className="h-6 w-6 text-indigo mx-auto mb-2" />
                      <p className="text-sm text-slate-600">Total Grants</p>
                      <p className="text-xl font-bold text-indigo">{parsedData.summary.totalGrants}</p>
                    </CardContent>
                  </Card>

                  <Card className="border-emerald/20 bg-emerald/5">
                    <CardContent className="p-4 text-center">
                      <DollarSign className="h-6 w-6 text-emerald mx-auto mb-2" />
                      <p className="text-sm text-slate-600">Total Revenue</p>
                      <p className="text-xl font-bold text-emerald">
                        {formatCurrency(parsedData.summary.totalRevenue)}
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="border-amber/20 bg-amber/5">
                    <CardContent className="p-4 text-center">
                      <Calendar className="h-6 w-6 text-amber mx-auto mb-2" />
                      <p className="text-sm text-slate-600">Win Rate</p>
                      <p className="text-xl font-bold text-amber">
                        {parsedData.summary.avgWinRate.toFixed(1)}%
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="border-slate-200">
                    <CardContent className="p-4 text-center">
                      <Users className="h-6 w-6 text-slate-600 mx-auto mb-2" />
                      <p className="text-sm text-slate-600">Date Range</p>
                      <p className="text-xs font-medium text-slate-700">
                        {parsedData.summary.dateRange.start} to {parsedData.summary.dateRange.end}
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Errors */}
                {parsedData.errors.length > 0 && (
                  <Alert className="border-amber bg-amber/10">
                    <AlertTriangle className="h-4 w-4 text-amber" />
                    <AlertDescription>
                      <div className="space-y-2">
                        <p className="font-medium text-amber-800">
                          {parsedData.errors.length} rows had errors and were skipped:
                        </p>
                        <div className="text-sm text-amber-700 max-h-20 overflow-y-auto">
                          {parsedData.errors.slice(0, 5).map((error, index) => (
                            <div key={index}>• {error}</div>
                          ))}
                          {parsedData.errors.length > 5 && (
                            <div>• ... and {parsedData.errors.length - 5} more</div>
                          )}
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                {/* Sample Data Preview */}
                <Card>
                  <CardHeader>
                    <CardTitle>Data Preview</CardTitle>
                    <CardDescription>
                      Showing first 5 grants from your upload
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {parsedData.grants.slice(0, 5).map((grant, index) => (
                        <div key={index} className="border border-slate-200 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-sm">{grant.title}</h4>
                            <Badge className={getStatusBadge(grant.status)}>
                              {grant.status}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-slate-600">
                            <div>
                              <span className="font-medium">Funder:</span> {grant.funder}
                            </div>
                            <div>
                              <span className="font-medium">Amount:</span> {formatCurrency(grant.amount)}
                            </div>
                            <div>
                              <span className="font-medium">Client:</span> {grant.clientName}
                            </div>
                            <div>
                              <span className="font-medium">Writer:</span> {grant.writer}
                            </div>
                          </div>
                        </div>
                      ))}
                      {parsedData.grants.length > 5 && (
                        <p className="text-sm text-slate-600 text-center">
                          ... and {parsedData.grants.length - 5} more grants
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-end gap-3 pt-4">
                  <Button variant="outline" onClick={() => onOpenChange(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={() => {
                      toast.success('Historical data integrated successfully!');
                      onOpenChange(false);
                    }}
                    className="bg-emerald hover:bg-emerald/90"
                  >
                    Confirm Upload
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}