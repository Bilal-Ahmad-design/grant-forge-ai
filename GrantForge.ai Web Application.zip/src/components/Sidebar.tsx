import React from 'react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { 
  Home, 
  UserPlus, 
  Search, 
  Trello, 
  BarChart3, 
  Bell, 
  LogOut,
  Shield,
  Users
} from 'lucide-react';
import logoImage from 'figma:asset/89da73488fa2622d2699f14186ad33b0bed43663.png';

type Page = 'dashboard' | 'intake' | 'research' | 'kanban' | 'analytics' | 'alerts' | 'users' | 'public-intake';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'manager' | 'writer';
  organization: string;
}

interface SidebarProps {
  currentPage: Page;
  onPageChange: (page: Page) => void;
  user: User;
  onLogout: () => void;
}

export function Sidebar({ currentPage, onPageChange, user, onLogout }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard' as Page, label: 'Dashboard', icon: Home },
    { id: 'intake' as Page, label: 'Client Intake', icon: UserPlus },
    { id: 'research' as Page, label: 'Research Hub', icon: Search },
    { id: 'kanban' as Page, label: 'Track Opportunities', icon: Trello },
    { id: 'alerts' as Page, label: 'Daily Alerts', icon: Bell, badge: '3' },
  ];

  if (user.role === 'admin') {
    menuItems.push(
      { id: 'analytics' as Page, label: 'Analytics', icon: BarChart3 },
      { id: 'users' as Page, label: 'User Management', icon: Users }
    );
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-emerald text-white';
      case 'manager': return 'bg-indigo text-white';
      case 'writer': return 'bg-amber text-navy';
      default: return 'bg-slate-200 text-slate-700';
    }
  };

  return (
    <div className="w-64 bg-sky-50 border-r border-slate-200 flex flex-col">
      {/* Logo Header */}
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <img src={logoImage} alt="GrantForge.ai" className="h-8 w-auto" />
          <div className="font-space-grotesk">
            <div className="font-semibold text-navy">GrantForge<span className="text-amber">.ai</span></div>
          </div>
        </div>
      </div>

      {/* User Profile */}
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-start gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={`https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face`} />
            <AvatarFallback className="bg-navy text-white">{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="font-medium text-navy truncate">{user.name}</p>
            <p className="text-xs text-slate-600 truncate">{user.organization}</p>
            <Badge className={`mt-1 text-xs ${getRoleColor(user.role)}`}>
              {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
            </Badge>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <Button
              key={item.id}
              variant={isActive ? 'default' : 'ghost'}
              className={`w-full justify-start gap-3 h-11 ${
                isActive 
                  ? 'bg-navy text-white hover:bg-indigo' 
                  : 'text-slate-700 hover:bg-white hover:text-navy'
              }`}
              onClick={() => onPageChange(item.id)}
            >
              <Icon className="h-4 w-4" />
              <span className="flex-1 text-left">{item.label}</span>
              {item.badge && (
                <Badge className="bg-amber text-navy text-xs ml-auto">
                  {item.badge}
                </Badge>
              )}
            </Button>
          );
        })}
      </nav>

      {/* Security Notice & Logout */}
      <div className="p-4 border-t border-slate-200 space-y-3">
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <Shield className="h-3 w-3" />
          <span>Secure connection</span>
        </div>
        
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 text-slate-700 hover:bg-white hover:text-navy"
          onClick={onLogout}
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </Button>
      </div>
    </div>
  );
}