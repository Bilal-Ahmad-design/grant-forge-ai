import React, { useState, useEffect } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { Alert, AlertDescription } from '../ui/alert';
import { 
  Building, 
  User, 
  FileText, 
  Upload, 
  Save, 
  Send, 
  Edit,
  CheckCircle,
  AlertCircle,
  Calendar,
  DollarSign,
  MapPin,
  Phone,
  Mail,
  Globe
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { DynamicFormField, FormField } from './DynamicFormField';
import { DocumentUpload, DocumentFile } from '../documents/DocumentUpload';
import { apiRequest } from '../../utils/supabase/client';

interface IntakeFormData {
  // Organization Information
  organizationName: string;
  organizationType: string;
  taxId: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
  website: string;
  
  // Contact Information
  primaryContact: {
    name: string;
    title: string;
    email: string;
    phone: string;
  };
  secondaryContact?: {
    name: string;
    title: string;
    email: string;
    phone: string;
  };
  
  // Grant Information
  projectTitle: string;
  projectDescription: string;
  fundingAmount: string;
  projectDuration: string;
  startDate: string;
  
  // Custom Fields
  customFields: Record<string, any>;
}

interface EnhancedIntakeFormProps {
  clientId?: string;
  onSubmit?: (data: IntakeFormData, documents: Record<string, DocumentFile[]>) => void;
  onSave?: (data: IntakeFormData, documents: Record<string, DocumentFile[]>) => void;
  initialData?: Partial<IntakeFormData>;
  editable?: boolean;
  user: any;
}

export function EnhancedIntakeForm({
  clientId,
  onSubmit,
  onSave,
  initialData,
  editable = true,
  user
}: EnhancedIntakeFormProps) {
  const [formData, setFormData] = useState<IntakeFormData>({
    organizationName: '',
    organizationType: '',
    taxId: '',
    address: {
      street: '',
      city: '',
      state: '',
      zipCode: ''
    },
    website: '',
    primaryContact: {
      name: '',
      title: '',
      email: '',
      phone: ''
    },
    projectTitle: '',
    projectDescription: '',
    fundingAmount: '',
    projectDuration: '',
    startDate: '',
    customFields: {},
    ...initialData
  });

  const [customFields, setCustomFields] = useState<FormField[]>([]);
  const [documents, setDocuments] = useState<Record<string, DocumentFile[]>>({
    organizational: [],
    project: [],
    financial: [],
    compliance: []
  });
  
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [activeTab, setActiveTab] = useState('organization');

  // Document categories with their specific requirements
  const documentCategories = {
    organizational: {
      title: 'Organizational Documents',
      description: 'Required documents for your organization',
      acceptedTypes: ['application/pdf', 'image/*', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
      maxFileSize: 10,
      maxFiles: 5,
      required: true,
      examples: ['W-9 Form', 'IRS Determination Letter', 'Articles of Incorporation', 'Board Resolution']
    },
    financial: {
      title: 'Financial Documents',
      description: 'Budget and financial planning documents',
      acceptedTypes: ['application/pdf', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
      maxFileSize: 15,
      maxFiles: 10,
      required: true,
      examples: ['Project Budget', 'Organizational Budget', 'Financial Statements', 'Audit Reports']
    },
    project: {
      title: 'Project-Specific Documents',
      description: 'Documents specific to this grant project',
      acceptedTypes: ['application/pdf', 'image/*', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
      maxFileSize: 20,
      maxFiles: 15,
      required: false,
      examples: ['Feasibility Studies', 'Quotes', 'Letters of Support', 'Project Images']
    },
    compliance: {
      title: 'Compliance Documents',
      description: 'Regulatory and compliance documentation',
      acceptedTypes: ['application/pdf', 'image/*'],
      maxFileSize: 5,
      maxFiles: 8,
      required: false,
      examples: ['Insurance Certificates', 'Licenses', 'Permits', 'Environmental Reports']
    }
  };

  // Load existing data
  useEffect(() => {
    const loadData = async () => {
      if (clientId) {
        try {
          const response = await apiRequest(`/intake/${clientId}`);
          if (response.success) {
            setFormData({ ...formData, ...response.data });
            setCustomFields(response.customFields || []);
            setDocuments(response.documents || {
              organizational: [],
              project: [],
              financial: [],
              compliance: []
            });
          }
        } catch (error) {
          console.error('Error loading intake data:', error);
          toast.error('Failed to load existing data');
        }
      }
    };

    loadData();
  }, [clientId]);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    // Required field validation
    if (!formData.organizationName.trim()) {
      newErrors.organizationName = 'Organization name is required';
    }
    if (!formData.organizationType) {
      newErrors.organizationType = 'Organization type is required';
    }
    if (!formData.primaryContact.name.trim()) {
      newErrors.primaryContactName = 'Primary contact name is required';
    }
    if (!formData.primaryContact.email.trim()) {
      newErrors.primaryContactEmail = 'Primary contact email is required';
    }
    if (!formData.projectTitle.trim()) {
      newErrors.projectTitle = 'Project title is required';
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (formData.primaryContact.email && !emailRegex.test(formData.primaryContact.email)) {
      newErrors.primaryContactEmail = 'Invalid email format';
    }
    if (formData.secondaryContact?.email && !emailRegex.test(formData.secondaryContact.email)) {
      newErrors.secondaryContactEmail = 'Invalid email format';
    }

    // Document validation
    if (documents.organizational.length === 0) {
      newErrors.organizationalDocs = 'At least one organizational document is required';
    }
    if (documents.financial.length === 0) {
      newErrors.financialDocs = 'At least one financial document is required';
    }

    // Custom field validation
    customFields.forEach(field => {
      if (field.required && !formData.customFields[field.id]) {
        newErrors[`custom_${field.id}`] = `${field.label} is required`;
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const response = await apiRequest('/intake/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientId,
          formData,
          customFields,
          documents,
          status: 'draft'
        })
      });

      if (response.success) {
        toast.success('Form saved successfully');
        onSave?.(formData, documents);
      }
    } catch (error: any) {
      console.error('Error saving form:', error);
      toast.error('Failed to save form');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      toast.error('Please fix the errors before submitting');
      return;
    }

    setLoading(true);
    try {
      const response = await apiRequest('/intake/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientId,
          formData,
          customFields,
          documents,
          status: 'submitted'
        })
      });

      if (response.success) {
        toast.success('Intake form submitted successfully');
        onSubmit?.(formData, documents);
      }
    } catch (error: any) {
      console.error('Error submitting form:', error);
      toast.error('Failed to submit form');
    } finally {
      setLoading(false);
    }
  };

  const updateFormData = (field: string, value: any) => {
    setFormData(prev => {
      const newData = { ...prev };
      const keys = field.split('.');
      let current = newData as any;
      
      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) current[keys[i]] = {};
        current = current[keys[i]];
      }
      
      current[keys[keys.length - 1]] = value;
      return newData;
    });

    // Clear related errors
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const organizationTypes = [
    'Public School District',
    'Charter School',
    'Private School',
    'Nonprofit Organization',
    'Municipal Government',
    'County Government',
    'State Agency',
    'Higher Education Institution',
    'Healthcare Organization',
    'Other'
  ];

  const projectDurations = [
    '6 months',
    '1 year',
    '2 years',
    '3 years',
    '4 years',
    '5 years',
    'Other'
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-space-grotesk font-semibold text-navy">
          Client Intake Form
        </h1>
        <p className="text-slate-600">
          Complete this form to begin the grant writing process
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="organization" className="gap-2">
            <Building className="h-4 w-4" />
            Organization
          </TabsTrigger>
          <TabsTrigger value="project" className="gap-2">
            <FileText className="h-4 w-4" />
            Project
          </TabsTrigger>
          <TabsTrigger value="documents" className="gap-2">
            <Upload className="h-4 w-4" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="custom" className="gap-2">
            <Edit className="h-4 w-4" />
            Custom Fields
          </TabsTrigger>
        </TabsList>

        {/* Organization Information Tab */}
        <TabsContent value="organization" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Organization Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="organizationName">
                    Organization Name <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="organizationName"
                    value={formData.organizationName}
                    onChange={(e) => updateFormData('organizationName', e.target.value)}
                    className="bg-sky-50 border-slate-200"
                    disabled={!editable}
                  />
                  {errors.organizationName && (
                    <p className="text-sm text-red-600">{errors.organizationName}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="organizationType">
                    Organization Type <span className="text-red-500">*</span>
                  </Label>
                  <Select 
                    value={formData.organizationType} 
                    onValueChange={(value) => updateFormData('organizationType', value)}
                    disabled={!editable}
                  >
                    <SelectTrigger className="bg-sky-50 border-slate-200">
                      <SelectValue placeholder="Select organization type" />
                    </SelectTrigger>
                    <SelectContent>
                      {organizationTypes.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.organizationType && (
                    <p className="text-sm text-red-600">{errors.organizationType}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="taxId">Tax ID / EIN</Label>
                <Input
                  id="taxId"
                  value={formData.taxId}
                  onChange={(e) => updateFormData('taxId', e.target.value)}
                  placeholder="XX-XXXXXXX"
                  className="bg-sky-50 border-slate-200"
                  disabled={!editable}
                />
              </div>

              <div className="space-y-2">
                <Label>Address</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    value={formData.address.street}
                    onChange={(e) => updateFormData('address.street', e.target.value)}
                    placeholder="Street Address"
                    className="bg-sky-50 border-slate-200"
                    disabled={!editable}
                  />
                  <Input
                    value={formData.address.city}
                    onChange={(e) => updateFormData('address.city', e.target.value)}
                    placeholder="City"
                    className="bg-sky-50 border-slate-200"
                    disabled={!editable}
                  />
                  <Input
                    value={formData.address.state}
                    onChange={(e) => updateFormData('address.state', e.target.value)}
                    placeholder="State"
                    className="bg-sky-50 border-slate-200"
                    disabled={!editable}
                  />
                  <Input
                    value={formData.address.zipCode}
                    onChange={(e) => updateFormData('address.zipCode', e.target.value)}
                    placeholder="ZIP Code"
                    className="bg-sky-50 border-slate-200"
                    disabled={!editable}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  type="url"
                  value={formData.website}
                  onChange={(e) => updateFormData('website', e.target.value)}
                  placeholder="https://example.com"
                  className="bg-sky-50 border-slate-200"
                  disabled={!editable}
                />
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium text-navy">Primary Contact</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="primaryContactName">
                      Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="primaryContactName"
                      value={formData.primaryContact.name}
                      onChange={(e) => updateFormData('primaryContact.name', e.target.value)}
                      className="bg-sky-50 border-slate-200"
                      disabled={!editable}
                    />
                    {errors.primaryContactName && (
                      <p className="text-sm text-red-600">{errors.primaryContactName}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="primaryContactTitle">Title</Label>
                    <Input
                      id="primaryContactTitle"
                      value={formData.primaryContact.title}
                      onChange={(e) => updateFormData('primaryContact.title', e.target.value)}
                      className="bg-sky-50 border-slate-200"
                      disabled={!editable}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="primaryContactEmail">
                      Email <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="primaryContactEmail"
                      type="email"
                      value={formData.primaryContact.email}
                      onChange={(e) => updateFormData('primaryContact.email', e.target.value)}
                      className="bg-sky-50 border-slate-200"
                      disabled={!editable}
                    />
                    {errors.primaryContactEmail && (
                      <p className="text-sm text-red-600">{errors.primaryContactEmail}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="primaryContactPhone">Phone</Label>
                    <Input
                      id="primaryContactPhone"
                      type="tel"
                      value={formData.primaryContact.phone}
                      onChange={(e) => updateFormData('primaryContact.phone', e.target.value)}
                      className="bg-sky-50 border-slate-200"
                      disabled={!editable}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium text-navy">Secondary Contact (Optional)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input
                      value={formData.secondaryContact?.name || ''}
                      onChange={(e) => updateFormData('secondaryContact.name', e.target.value)}
                      className="bg-sky-50 border-slate-200"
                      disabled={!editable}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Title</Label>
                    <Input
                      value={formData.secondaryContact?.title || ''}
                      onChange={(e) => updateFormData('secondaryContact.title', e.target.value)}
                      className="bg-sky-50 border-slate-200"
                      disabled={!editable}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input
                      type="email"
                      value={formData.secondaryContact?.email || ''}
                      onChange={(e) => updateFormData('secondaryContact.email', e.target.value)}
                      className="bg-sky-50 border-slate-200"
                      disabled={!editable}
                    />
                    {errors.secondaryContactEmail && (
                      <p className="text-sm text-red-600">{errors.secondaryContactEmail}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label>Phone</Label>
                    <Input
                      type="tel"
                      value={formData.secondaryContact?.phone || ''}
                      onChange={(e) => updateFormData('secondaryContact.phone', e.target.value)}
                      className="bg-sky-50 border-slate-200"
                      disabled={!editable}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Project Information Tab */}
        <TabsContent value="project" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Project Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="projectTitle">
                  Project Title <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="projectTitle"
                  value={formData.projectTitle}
                  onChange={(e) => updateFormData('projectTitle', e.target.value)}
                  className="bg-sky-50 border-slate-200"
                  disabled={!editable}
                />
                {errors.projectTitle && (
                  <p className="text-sm text-red-600">{errors.projectTitle}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="projectDescription">Project Description</Label>
                <Textarea
                  id="projectDescription"
                  value={formData.projectDescription}
                  onChange={(e) => updateFormData('projectDescription', e.target.value)}
                  rows={4}
                  className="bg-sky-50 border-slate-200"
                  placeholder="Describe your project, its goals, and intended impact..."
                  disabled={!editable}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fundingAmount">Requested Amount</Label>
                  <Input
                    id="fundingAmount"
                    value={formData.fundingAmount}
                    onChange={(e) => updateFormData('fundingAmount', e.target.value)}
                    placeholder="$000,000"
                    className="bg-sky-50 border-slate-200"
                    disabled={!editable}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="projectDuration">Project Duration</Label>
                  <Select 
                    value={formData.projectDuration} 
                    onValueChange={(value) => updateFormData('projectDuration', value)}
                    disabled={!editable}
                  >
                    <SelectTrigger className="bg-sky-50 border-slate-200">
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      {projectDurations.map(duration => (
                        <SelectItem key={duration} value={duration}>{duration}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="startDate">Proposed Start Date</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => updateFormData('startDate', e.target.value)}
                    className="bg-sky-50 border-slate-200"
                    disabled={!editable}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-6">
          <div className="space-y-6">
            {Object.entries(documentCategories).map(([category, config]) => (
              <DocumentUpload
                key={category}
                category={category}
                title={config.title}
                description={config.description}
                acceptedTypes={config.acceptedTypes}
                maxFileSize={config.maxFileSize}
                maxFiles={config.maxFiles}
                existingFiles={documents[category] || []}
                onFilesChange={(files) => setDocuments(prev => ({ ...prev, [category]: files }))}
                disabled={!editable}
                required={config.required}
              />
            ))}

            {/* Show validation errors for documents */}
            {(errors.organizationalDocs || errors.financialDocs) && (
              <Alert className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-700">
                  {errors.organizationalDocs && <div>{errors.organizationalDocs}</div>}
                  {errors.financialDocs && <div>{errors.financialDocs}</div>}
                </AlertDescription>
              </Alert>
            )}
          </div>
        </TabsContent>

        {/* Custom Fields Tab */}
        <TabsContent value="custom" className="space-y-6">
          <DynamicFormField
            fields={customFields}
            values={formData.customFields}
            onFieldsChange={setCustomFields}
            onValuesChange={(values) => updateFormData('customFields', values)}
            editable={editable && user.role === 'admin'}
            title="Custom Fields"
          />

          {/* Show custom field validation errors */}
          {Object.entries(errors).filter(([key]) => key.startsWith('custom_')).length > 0 && (
            <Alert className="border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-700">
                {Object.entries(errors)
                  .filter(([key]) => key.startsWith('custom_'))
                  .map(([key, error]) => (
                    <div key={key}>{error}</div>
                  ))
                }
              </AlertDescription>
            </Alert>
          )}
        </TabsContent>
      </Tabs>

      {/* Action Buttons */}
      {editable && (
        <div className="flex justify-between items-center pt-6 border-t border-slate-200">
          <div className="text-sm text-slate-600">
            All required fields must be completed before submission
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleSave}
              disabled={loading}
              className="gap-2"
            >
              <Save className="h-4 w-4" />
              Save Draft
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={loading}
              className="gap-2 bg-navy hover:bg-navy/90"
            >
              <Send className="h-4 w-4" />
              Submit Form
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}