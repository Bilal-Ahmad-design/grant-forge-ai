import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { 
  Plus, 
  X, 
  Edit, 
  Settings, 
  Type, 
  Hash, 
  Calendar, 
  Mail, 
  Phone, 
  CheckSquare,
  List,
  FileText,
  Grip
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export interface FormField {
  id: string;
  label: string;
  type: 'text' | 'email' | 'phone' | 'number' | 'textarea' | 'select' | 'checkbox' | 'radio' | 'date';
  required: boolean;
  placeholder?: string;
  options?: string[]; // For select, radio, checkbox
  value?: any;
  description?: string;
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
  };
}

interface DynamicFormFieldProps {
  fields: FormField[];
  values: Record<string, any>;
  onFieldsChange: (fields: FormField[]) => void;
  onValuesChange: (values: Record<string, any>) => void;
  editable?: boolean;
  title?: string;
}

export function DynamicFormField({
  fields,
  values,
  onFieldsChange,
  onValuesChange,
  editable = false,
  title = "Form Fields"
}: DynamicFormFieldProps) {
  const [editingField, setEditingField] = useState<FormField | null>(null);
  const [showAddField, setShowAddField] = useState(false);

  const fieldTypeIcons = {
    text: Type,
    email: Mail,
    phone: Phone,
    number: Hash,
    textarea: FileText,
    select: List,
    checkbox: CheckSquare,
    radio: CheckSquare,
    date: Calendar
  };

  const defaultField: Omit<FormField, 'id'> = {
    label: '',
    type: 'text',
    required: false,
    placeholder: '',
    options: [],
    description: ''
  };

  const [newField, setNewField] = useState<Omit<FormField, 'id'>>(defaultField);

  const addField = () => {
    if (!newField.label.trim()) {
      toast.error('Field label is required');
      return;
    }

    const field: FormField = {
      ...newField,
      id: `field_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    onFieldsChange([...fields, field]);
    setNewField(defaultField);
    setShowAddField(false);
    toast.success('Field added successfully');
  };

  const updateField = (updatedField: FormField) => {
    const updatedFields = fields.map(field => 
      field.id === updatedField.id ? updatedField : field
    );
    onFieldsChange(updatedFields);
    setEditingField(null);
    toast.success('Field updated successfully');
  };

  const removeField = (fieldId: string) => {
    const updatedFields = fields.filter(field => field.id !== fieldId);
    onFieldsChange(updatedFields);
    
    // Remove value as well
    const updatedValues = { ...values };
    delete updatedValues[fieldId];
    onValuesChange(updatedValues);
    
    toast.success('Field removed successfully');
  };

  const moveField = (fieldId: string, direction: 'up' | 'down') => {
    const currentIndex = fields.findIndex(f => f.id === fieldId);
    if (currentIndex === -1) return;

    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (newIndex < 0 || newIndex >= fields.length) return;

    const newFields = [...fields];
    [newFields[currentIndex], newFields[newIndex]] = [newFields[newIndex], newFields[currentIndex]];
    
    onFieldsChange(newFields);
  };

  const updateValue = (fieldId: string, value: any) => {
    onValuesChange({
      ...values,
      [fieldId]: value
    });
  };

  const renderFieldInput = (field: FormField) => {
    const value = values[field.id] || '';

    switch (field.type) {
      case 'textarea':
        return (
          <Textarea
            placeholder={field.placeholder}
            value={value}
            onChange={(e) => updateValue(field.id, e.target.value)}
            className="bg-sky-50 border-slate-200"
            rows={3}
          />
        );

      case 'select':
        return (
          <Select value={value} onValueChange={(val) => updateValue(field.id, val)}>
            <SelectTrigger className="bg-sky-50 border-slate-200">
              <SelectValue placeholder={field.placeholder || `Select ${field.label}`} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option, index) => (
                <SelectItem key={index} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'checkbox':
        return (
          <div className="space-y-2">
            {field.options?.map((option, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Checkbox
                  id={`${field.id}_${index}`}
                  checked={Array.isArray(value) && value.includes(option)}
                  onCheckedChange={(checked) => {
                    const currentValues = Array.isArray(value) ? value : [];
                    if (checked) {
                      updateValue(field.id, [...currentValues, option]);
                    } else {
                      updateValue(field.id, currentValues.filter(v => v !== option));
                    }
                  }}
                />
                <Label htmlFor={`${field.id}_${index}`} className="text-sm">
                  {option}
                </Label>
              </div>
            ))}
          </div>
        );

      case 'radio':
        return (
          <RadioGroup value={value} onValueChange={(val) => updateValue(field.id, val)}>
            {field.options?.map((option, index) => (
              <div key={index} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={`${field.id}_${index}`} />
                <Label htmlFor={`${field.id}_${index}`} className="text-sm">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        );

      default:
        return (
          <Input
            type={field.type}
            placeholder={field.placeholder}
            value={value}
            onChange={(e) => updateValue(field.id, e.target.value)}
            className="bg-sky-50 border-slate-200"
            required={field.required}
            min={field.validation?.min}
            max={field.validation?.max}
            pattern={field.validation?.pattern}
          />
        );
    }
  };

  const FieldEditor = ({ field, onSave, onCancel }: {
    field: Omit<FormField, 'id'> | FormField;
    onSave: (field: FormField) => void;
    onCancel: () => void;
  }) => {
    const [editField, setEditField] = useState<Omit<FormField, 'id'> | FormField>(field);

    const handleSave = () => {
      if (!editField.label.trim()) {
        toast.error('Field label is required');
        return;
      }

      if ('id' in editField) {
        onSave(editField as FormField);
      } else {
        const newFieldWithId: FormField = {
          ...editField,
          id: `field_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
        };
        onSave(newFieldWithId);
      }
    };

    return (
      <div className="space-y-4 p-4">
        <div className="space-y-2">
          <Label>Field Label</Label>
          <Input
            value={editField.label}
            onChange={(e) => setEditField({ ...editField, label: e.target.value })}
            placeholder="Enter field label"
          />
        </div>

        <div className="space-y-2">
          <Label>Field Type</Label>
          <Select 
            value={editField.type} 
            onValueChange={(value: FormField['type']) => setEditField({ ...editField, type: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="text">Text</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="phone">Phone</SelectItem>
              <SelectItem value="number">Number</SelectItem>
              <SelectItem value="date">Date</SelectItem>
              <SelectItem value="textarea">Text Area</SelectItem>
              <SelectItem value="select">Dropdown</SelectItem>
              <SelectItem value="checkbox">Checkbox Group</SelectItem>
              <SelectItem value="radio">Radio Group</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Placeholder Text</Label>
          <Input
            value={editField.placeholder || ''}
            onChange={(e) => setEditField({ ...editField, placeholder: e.target.value })}
            placeholder="Enter placeholder text"
          />
        </div>

        <div className="space-y-2">
          <Label>Description (Optional)</Label>
          <Textarea
            value={editField.description || ''}
            onChange={(e) => setEditField({ ...editField, description: e.target.value })}
            placeholder="Add help text for this field"
            rows={2}
          />
        </div>

        {(editField.type === 'select' || editField.type === 'checkbox' || editField.type === 'radio') && (
          <div className="space-y-2">
            <Label>Options (one per line)</Label>
            <Textarea
              value={editField.options?.join('\n') || ''}
              onChange={(e) => setEditField({ 
                ...editField, 
                options: e.target.value.split('\n').filter(opt => opt.trim()) 
              })}
              placeholder="Option 1&#10;Option 2&#10;Option 3"
              rows={4}
            />
          </div>
        )}

        <div className="flex items-center space-x-2">
          <Checkbox
            id="required"
            checked={editField.required}
            onCheckedChange={(checked) => setEditField({ ...editField, required: !!checked })}
          />
          <Label htmlFor="required" className="text-sm">
            Required field
          </Label>
        </div>

        <div className="flex gap-2 pt-4 border-t">
          <Button onClick={handleSave} className="bg-navy hover:bg-navy/90">
            Save Field
          </Button>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </div>
    );
  };

  return (
    <Card className="border-slate-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-space-grotesk text-navy">
            {title}
          </CardTitle>
          {editable && (
            <Dialog open={showAddField} onOpenChange={setShowAddField}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Field
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Field</DialogTitle>
                </DialogHeader>
                <FieldEditor
                  field={newField}
                  onSave={(field) => {
                    onFieldsChange([...fields, field]);
                    setNewField(defaultField);
                    setShowAddField(false);
                    toast.success('Field added successfully');
                  }}
                  onCancel={() => {
                    setNewField(defaultField);
                    setShowAddField(false);
                  }}
                />
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {fields.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <Type className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No custom fields added yet</p>
            {editable && (
              <p className="text-sm">Click "Add Field" to create custom form fields</p>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {fields.map((field, index) => {
              const FieldIcon = fieldTypeIcons[field.type] || Type;
              
              return (
                <div key={field.id} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2 flex-1">
                      <FieldIcon className="h-4 w-4 text-slate-500" />
                      <Label htmlFor={field.id} className="flex-1">
                        {field.label}
                        {field.required && <span className="text-red-500 ml-1">*</span>}
                      </Label>
                      {field.type === 'select' || field.type === 'checkbox' || field.type === 'radio' ? (
                        <Badge variant="outline" className="text-xs">
                          {field.options?.length || 0} options
                        </Badge>
                      ) : null}
                    </div>
                    
                    {editable && (
                      <div className="flex items-center gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => moveField(field.id, 'up')}
                          disabled={index === 0}
                          className="h-8 w-8 p-0"
                        >
                          ↑
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => moveField(field.id, 'down')}
                          disabled={index === fields.length - 1}
                          className="h-8 w-8 p-0"
                        >
                          ↓
                        </Button>
                        <Dialog 
                          open={editingField?.id === field.id} 
                          onOpenChange={(open) => !open && setEditingField(null)}
                        >
                          <DialogTrigger asChild>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setEditingField(field)}
                              className="h-8 w-8 p-0"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle>Edit Field</DialogTitle>
                            </DialogHeader>
                            <FieldEditor
                              field={field}
                              onSave={updateField}
                              onCancel={() => setEditingField(null)}
                            />
                          </DialogContent>
                        </Dialog>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeField(field.id)}
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  {field.description && (
                    <p className="text-xs text-slate-500 pl-6">{field.description}</p>
                  )}
                  
                  <div className="pl-6">
                    {renderFieldInput(field)}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}