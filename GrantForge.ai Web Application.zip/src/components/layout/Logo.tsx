import React from 'react';

// Import the GrantForge.ai logo
import logoImage from 'figma:asset/8d40fc3a6b7c45ad53b1bdb97c6805d09be7e6d4.png';

// Brand text component for consistent "GrantForge.ai" branding
export function BrandText({ 
  className = '', 
  size = 'base' 
}: { 
  className?: string; 
  size?: 'sm' | 'base' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl';
}) {
  const sizeClass = {
    'sm': 'text-sm',
    'base': 'text-base', 
    'lg': 'text-lg',
    'xl': 'text-xl',
    '2xl': 'text-2xl',
    '3xl': 'text-3xl',
    '4xl': 'text-4xl'
  }[size] || 'text-base';

  return (
    <span className={`font-space-grotesk font-bold ${sizeClass} ${className}`}>
      <span className="text-navy">GrantForge</span>
      <span className="text-amber">.ai</span>
    </span>
  );
}

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
  onClick?: () => void;
}

export function Logo({ 
  size = 'md', 
  showText = true, 
  className = '', 
  onClick 
}: LogoProps) {
  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'h-8 w-8';
      case 'md':
        return 'h-10 w-10';
      case 'lg':
        return 'h-16 w-16';
      case 'xl':
        return 'h-24 w-24';
      default:
        return 'h-10 w-10';
    }
  };

  const getTextSize = () => {
    switch (size) {
      case 'sm':
        return 'text-lg';
      case 'md':
        return 'text-xl';
      case 'lg':
        return 'text-3xl';
      case 'xl':
        return 'text-4xl';
      default:
        return 'text-xl';
    }
  };

  const logoElement = (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className={`${getSizeClasses()} flex-shrink-0`}>
        <img
          src={logoImage}
          alt="GrantForge.ai Logo"
          className="h-full w-full object-contain"
        />
      </div>
      {showText && (
        <BrandText 
          size={size === 'xl' ? '4xl' : size === 'lg' ? '3xl' : size === 'md' ? 'xl' : 'lg'} 
        />
      )}
    </div>
  );

  if (onClick) {
    return (
      <button 
        onClick={onClick}
        className="transition-opacity hover:opacity-80 focus:outline-none focus:ring-2 focus:ring-indigo focus:ring-offset-2 rounded-lg"
        type="button"
      >
        {logoElement}
      </button>
    );
  }

  return logoElement;
}