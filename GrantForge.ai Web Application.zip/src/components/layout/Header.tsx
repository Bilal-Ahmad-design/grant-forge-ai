import React from 'react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { UserAvatar } from '../ui/user-avatar';
import { 
  User, 
  LogOut, 
  Settings, 
  UserX, 
  Shield,
  ChevronDown
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import { Logo } from './Logo';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
  avatar?: string;
}

interface NavigationItem {
  id: string;
  label: string;
  roles: string[];
}

interface HeaderProps {
  user: User;
  currentPage: string;
  navigation: NavigationItem[];
  onNavigate: (page: string) => void;
  onLogout: () => void;
  isImpersonating?: boolean;
  originalUser?: User | null;
  onStopImpersonating?: () => void;
}

const getRoleColor = (role: string) => {
  switch (role) {
    case 'super-admin':
      return 'bg-red-100 text-red-700 border-red-200';
    case 'admin':
      return 'bg-indigo text-white';
    case 'senior-writer':
      return 'bg-amber text-navy';
    case 'junior-writer':
      return 'bg-sky-50 text-indigo border-indigo/20';
    default:
      return 'bg-slate-100 text-slate-600';
  }
};

const getRoleDisplayText = (role: string) => {
  switch (role) {
    case 'super-admin':
      return 'Super Admin';
    case 'admin':
      return 'Admin';
    case 'senior-writer':
      return 'Senior Writer';
    case 'junior-writer':
      return 'Junior Writer';
    default:
      return role;
  }
};

// Mock avatar URLs for demo users based on the demo accounts
const getAvatarForUser = (user: User) => {
  // Use the avatar if provided, otherwise use demo avatars based on name/role
  if (user.avatar) return user.avatar;
  
  // Default avatars for demo users
  const avatarMap: Record<string, string> = {
    'Sarah Johnson': 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=400&q=80',
    'Michael Rodriguez': 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80',
    'Dr. Lisa Chen': 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80',
    'James Wilson': 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80',
    'Lisa Thompson': 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80',
    'Alex Martinez': 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80',
    'Maria Santos': 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80',
    'David Chen': 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
  };
  
  return avatarMap[user.name] || undefined;
};

export function Header({ 
  user, 
  currentPage, 
  navigation, 
  onNavigate, 
  onLogout,
  isImpersonating = false,
  originalUser = null,
  onStopImpersonating
}: HeaderProps) {
  const userAvatar = getAvatarForUser(user);
  
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Brand */}
          <Logo 
            size="md" 
            showText={true}
            onClick={() => onNavigate('dashboard')}
            className="cursor-pointer"
          />

          {/* Navigation */}
          <nav className="flex items-center space-x-1">
            {navigation.map((item) => (
              <Button
                key={item.id}
                variant={currentPage === item.id ? "default" : "ghost"}
                onClick={() => onNavigate(item.id)}
                className={
                  currentPage === item.id 
                    ? "bg-navy text-white hover:bg-navy/90" 
                    : "text-slate-700 hover:text-navy hover:bg-slate-100"
                }
              >
                {item.label}
              </Button>
            ))}
          </nav>

          {/* User Menu */}
          <div className="flex items-center gap-4">
            {/* Impersonation Banner */}
            {isImpersonating && originalUser && (
              <div className="flex items-center gap-2">
                <Badge className="bg-amber text-navy border border-amber/30">
                  <Shield className="h-3 w-3 mr-1" />
                  Viewing as {user.name}
                </Badge>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={onStopImpersonating}
                  className="gap-2 border-amber/30 text-amber-700 hover:bg-amber/10"
                >
                  <UserX className="h-4 w-4" />
                  Stop Impersonating
                </Button>
                <Separator orientation="vertical" className="h-6" />
              </div>
            )}

            {/* User Profile */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="flex items-center gap-3 hover:bg-slate-100 px-3 py-2"
                >
                  <div className="flex items-center gap-2">
                    <UserAvatar
                      src={userAvatar}
                      name={user.name}
                      size="sm"
                    />
                    <div className="text-left">
                      <p className="text-sm font-medium text-slate-900">{user.name}</p>
                      <p className="text-xs text-slate-500">{user.organization}</p>
                    </div>
                    <Badge className={getRoleColor(user.role)}>
                      {getRoleDisplayText(user.role)}
                    </Badge>
                  </div>
                  <ChevronDown className="h-4 w-4 text-slate-400" />
                </Button>
              </DropdownMenuTrigger>
              
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                
                <DropdownMenuItem 
                  onClick={() => onNavigate('profile')}
                  className="cursor-pointer"
                >
                  <User className="mr-2 h-4 w-4" />
                  Profile Settings
                </DropdownMenuItem>
                
                {user.role === 'super-admin' && !isImpersonating && (
                  <DropdownMenuItem 
                    onClick={() => onNavigate('settings')}
                    className="cursor-pointer"
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Platform Settings
                  </DropdownMenuItem>
                )}
                
                <DropdownMenuSeparator />
                
                <DropdownMenuItem 
                  onClick={onLogout}
                  className="cursor-pointer text-red-600 focus:text-red-600"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}