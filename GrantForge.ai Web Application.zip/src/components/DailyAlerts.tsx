import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  Bell, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  Calendar, 
  DollarSign,
  Users,
  Target,
  Settings,
  Filter,
  Search,
  X,
  Loader2,
  RefreshCw,
  Archive
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

interface DailyAlertsProps {
  user: User;
  onNavigate?: (page: string) => void;
}

interface Alert {
  id: string;
  type: 'deadline' | 'opportunity' | 'milestone' | 'system' | 'grant_approval_required' | 'client_intake';
  priority: 'high' | 'medium' | 'low';
  title: string;
  message: string;
  timestamp: string;
  actionRequired: boolean;
  read: boolean;
  relatedProject?: string;
  value?: string;
  data?: any;
  created_by?: string;
  organization?: string;
}

// Utility function to format large numbers
const formatAmount = (amount: string): string => {
  const match = amount.match(/\$?([\d,]+(?:,\d{3})*)/);
  if (!match) return amount;
  
  const num = parseInt(match[1].replace(/,/g, ''));
  if (num >= 1000000) {
    return `$${(num / 1000000).toFixed(num % 1000000 === 0 ? 0 : 1)}M`;
  } else if (num >= 1000) {
    return `$${(num / 1000).toFixed(num % 1000 === 0 ? 0 : 0)}K`;
  }
  return amount;
};

export function DailyAlerts({ user, onNavigate }: DailyAlertsProps) {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    loadAlerts();
  }, [user]);

  const loadAlerts = async () => {
    try {
      setLoading(true);
      
      // Try to load from API first
      let apiAlerts = [];
      try {
        const response = await apiRequest('/alerts');
        apiAlerts = response.alerts || [];
      } catch (apiError) {
        console.log('Using demo alert data');
      }

      // Generate comprehensive mock alerts for demo
      const mockAlerts: Alert[] = [
        {
          id: '1',
          type: 'deadline',
          priority: 'high',
          title: 'NSF STEM Grant Deadline Critical',
          message: 'Application due in 2 days. AI draft completed with 98% compliance score, needs final review and client approval.',
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          actionRequired: true,
          read: false,
          relatedProject: 'NSF STEM Education Grant',
          value: formatAmount('$185,000'),
          data: { grantId: 'grant1', daysLeft: 2 }
        },
        {
          id: '2',
          type: 'opportunity',
          priority: 'high',
          title: 'High-Value Grant Match Found',
          message: 'AI discovered new $4.8M federal infrastructure grant - 97% match for Metro School District. Deadline: 45 days.',
          timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
          actionRequired: true,
          read: false,
          value: formatAmount('$4,800,000'),
          data: { matchConfidence: 97 }
        },
        {
          id: '3',
          type: 'grant_approval_required',
          priority: 'high',
          title: 'Grant Pending Admin Approval',
          message: 'Digital Infrastructure Modernization grant has been submitted for approval by Alex Martinez.',
          timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
          actionRequired: user.role === 'admin' || user.role === 'super-admin',
          read: false,
          relatedProject: 'Digital Infrastructure Modernization',
          value: formatAmount('$650,000'),
          data: { grantId: 'grant3', submittedBy: 'Alex Martinez' }
        },
        {
          id: '4',
          type: 'client_intake',
          priority: 'medium',
          title: 'New Client Intake Submitted',
          message: 'Washington Elementary has submitted an intake form and is requesting grant writing services.',
          timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
          actionRequired: ['admin', 'super-admin'].includes(user.role),
          read: false,
          data: { clientName: 'Washington Elementary' }
        },
        {
          id: '5',
          type: 'milestone',
          priority: 'low',
          title: 'Grant Application Submitted Successfully',
          message: 'Technology Integration Fund application submitted via AI writing assistant. Confirmation #TIF-2024-8834.',
          timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          actionRequired: false,
          read: true,
          relatedProject: 'Technology Integration Fund',
          value: formatAmount('$2,350,000')
        },
        {
          id: '6',
          type: 'system',
          priority: 'medium',
          title: 'Weekly Time Tracking Summary',
          message: 'Automatic tracking recorded 42.5 hours this week across 6 active projects. +31% productivity vs last week.',
          timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
          actionRequired: false,
          read: false
        },
        {
          id: '7',
          type: 'deadline',
          priority: 'medium',
          title: 'Client Review Pending',
          message: 'Arts Integration Grant AI-generated draft awaiting Springfield Elementary approval. Due by August 8th.',
          timestamp: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString(),
          actionRequired: true,
          read: false,
          relatedProject: 'Arts Integration Grant',
          value: formatAmount('$75,000')
        },
        {
          id: '8',
          type: 'milestone',
          priority: 'high',
          title: 'Grant Awarded - Celebration Time!',
          message: 'Innovation in Learning Grant has been awarded to Innovation Academy. Total secured: $1.65M - 32% above projected value!',
          timestamp: new Date(Date.now() - 96 * 60 * 60 * 1000).toISOString(),
          actionRequired: false,
          read: true,
          relatedProject: 'Innovation in Learning Grant',
          value: formatAmount('$1,650,000')
        }
      ];

      // Use API data if available, otherwise mock data
      const combinedAlerts = apiAlerts.length > 0 ? apiAlerts : mockAlerts;
      
      // Filter by organization for non-super-admin users
      const filteredAlerts = user.role === 'super-admin' 
        ? combinedAlerts 
        : combinedAlerts.filter(alert => 
            !alert.organization || alert.organization === user.organization
          );

      setAlerts(filteredAlerts);
      
      if (apiAlerts.length === 0) {
        toast.success('Loaded demo alerts for exploration');
      }

    } catch (error) {
      console.error('Error loading alerts:', error);
      toast.error('Failed to load alerts');
    } finally {
      setLoading(false);
    }
  };

  const refreshAlerts = async () => {
    setRefreshing(true);
    await loadAlerts();
    setRefreshing(false);
    toast.success('Alerts refreshed');
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'deadline': return <Clock className="h-4 w-4" />;
      case 'opportunity': return <Target className="h-4 w-4" />;
      case 'milestone': return <CheckCircle className="h-4 w-4" />;
      case 'system': return <Bell className="h-4 w-4" />;
      case 'grant_approval_required': return <AlertTriangle className="h-4 w-4" />;
      case 'client_intake': return <Users className="h-4 w-4" />;
      default: return <Bell className="h-4 w-4" />;
    }
  };

  const getAlertColor = (type: string, priority: string) => {
    if (priority === 'high') return 'text-red-500';
    if (priority === 'medium') return 'text-amber';
    if (type === 'milestone') return 'text-emerald';
    if (type === 'opportunity') return 'text-indigo';
    if (type === 'grant_approval_required') return 'text-red-500';
    if (type === 'client_intake') return 'text-indigo';
    return 'text-slate-600';
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <Badge className="bg-red-100 text-red-700">High Priority</Badge>;
      case 'medium':
        return <Badge className="bg-amber/20 text-amber border-amber/30">Medium</Badge>;
      case 'low':
        return <Badge className="bg-emerald/20 text-emerald border-emerald/30">Low</Badge>;
      default:
        return null;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    if (diffInHours < 48) return 'Yesterday';
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)} days ago`;
    return date.toLocaleDateString();
  };

  const markAsRead = async (alertId: string) => {
    try {
      await apiRequest(`/alerts/${alertId}/read`, {
        method: 'PATCH'
      });
    } catch (error) {
      console.log('Failed to mark as read on server, updating locally');
    }
    
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, read: true } : alert
    ));
  };

  const dismissAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
    toast.success('Alert dismissed');
  };

  const markAllAsRead = async () => {
    // Update all alerts locally
    setAlerts(prev => prev.map(alert => ({ ...alert, read: true })));
    toast.success('All alerts marked as read');
  };

  const handleTakeAction = (alert: Alert) => {
    if (alert.type === 'grant_approval_required' && onNavigate) {
      // Navigate to pipeline with the specific grant
      if (alert.data?.grantId) {
        sessionStorage.setItem('selectedGrantId', alert.data.grantId);
      }
      onNavigate('kanban');
    } else if (alert.type === 'client_intake' && onNavigate) {
      onNavigate('clients');
    } else if (alert.type === 'opportunity' && onNavigate) {
      onNavigate('research');
    } else if (alert.type === 'deadline' && onNavigate) {
      if (alert.data?.grantId) {
        sessionStorage.setItem('selectedGrantId', alert.data.grantId);
      }
      onNavigate('kanban');
    }
    
    // Mark as read when action is taken
    markAsRead(alert.id);
  };

  const filteredAlerts = alerts.filter(alert => {
    const matchesFilter = filter === 'all' || 
                         (filter === 'unread' && !alert.read) ||
                         (filter === 'action-required' && alert.actionRequired) ||
                         alert.type === filter;
    
    const matchesSearch = alert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         alert.message.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesFilter && matchesSearch;
  });

  const unreadCount = alerts.filter(alert => !alert.read).length;
  const actionRequiredCount = alerts.filter(alert => alert.actionRequired && !alert.read).length;
  const totalValue = alerts
    .filter(alert => alert.value)
    .reduce((sum, alert) => {
      const match = alert.value!.match(/\$?([\d,.]+)([KM])?/);
      if (!match) return sum;
      let num = parseFloat(match[1].replace(/,/g, ''));
      if (match[2] === 'K') num *= 1000;
      if (match[2] === 'M') num *= 1000000;
      return sum + num;
    }, 0);

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center min-h-96">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-indigo mx-auto mb-4" />
            <p className="text-slate-600">Loading your alerts...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">Daily Alerts</h1>
          <p className="text-slate-600">AI-powered notifications for deadlines, opportunities, and milestones</p>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={refreshAlerts}
            disabled={refreshing}
          >
            {refreshing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
            Refresh
          </Button>
          <Button 
            variant="outline" 
            onClick={markAllAsRead}
            disabled={unreadCount === 0}
            className="gap-2"
          >
            <CheckCircle className="h-4 w-4" />
            Mark All Read
          </Button>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Alerts</p>
                <p className="text-2xl font-bold text-navy">{alerts.length}</p>
              </div>
              <Bell className="h-8 w-8 text-indigo" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Unread</p>
                <p className="text-2xl font-bold text-amber">{unreadCount}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-amber" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Action Required</p>
                <p className="text-2xl font-bold text-red-500">{actionRequiredCount}</p>
              </div>
              <Target className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Alert Value</p>
                <p className="text-2xl font-bold text-emerald">{formatAmount(`$${totalValue}`)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-emerald" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="border-slate-200">
        <CardContent className="pt-6">
          <div className="flex gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-600" />
              <Input
                placeholder="Search alerts by title or content..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-sky-50 border-slate-200"
              />
            </div>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-48 bg-sky-50 border-slate-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Alerts</SelectItem>
                <SelectItem value="unread">Unread Only</SelectItem>
                <SelectItem value="action-required">Action Required</SelectItem>
                <SelectItem value="deadline">Deadlines</SelectItem>
                <SelectItem value="opportunity">Opportunities</SelectItem>
                <SelectItem value="milestone">Milestones</SelectItem>
                <SelectItem value="grant_approval_required">Approvals Needed</SelectItem>
                <SelectItem value="client_intake">Client Intakes</SelectItem>
                <SelectItem value="system">System</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Alerts List */}
      <div className="space-y-3">
        {filteredAlerts.map((alert) => (
          <Card 
            key={alert.id} 
            className={`border-slate-200 transition-all hover:shadow-md ${
              !alert.read ? 'bg-sky-50 border-l-4 border-l-indigo' : ''
            }`}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex gap-3 flex-1">
                  <div className={`mt-1 ${getAlertColor(alert.type, alert.priority)}`}>
                    {getAlertIcon(alert.type)}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <h3 className={`font-medium ${!alert.read ? 'text-navy' : 'text-slate-700'}`}>
                        {alert.title}
                      </h3>
                      {getPriorityBadge(alert.priority)}
                      {alert.value && (
                        <Badge className="bg-emerald text-white text-xs">
                          {alert.value}
                        </Badge>
                      )}
                      {alert.actionRequired && (
                        <Badge className="bg-red-100 text-red-700 text-xs">Action Required</Badge>
                      )}
                      {!alert.read && (
                        <div className="w-2 h-2 rounded-full bg-indigo" />
                      )}
                    </div>
                    
                    <p className="text-slate-600 mb-3 leading-relaxed">{alert.message}</p>
                    
                    <div className="flex items-center gap-4 text-sm text-slate-500">
                      <span>{formatTimestamp(alert.timestamp)}</span>
                      {alert.relatedProject && (
                        <span className="flex items-center gap-1">
                          <Target className="h-3 w-3" />
                          {alert.relatedProject}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 ml-4">
                  {!alert.read && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => markAsRead(alert.id)}
                      className="h-8 px-3 text-xs hover:bg-indigo/10"
                    >
                      Mark Read
                    </Button>
                  )}
                  {alert.actionRequired && (
                    <Button
                      size="sm"
                      onClick={() => handleTakeAction(alert)}
                      className="h-8 px-3 text-xs bg-indigo hover:bg-navy"
                    >
                      Take Action
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => dismissAlert(alert.id)}
                    className="h-8 w-8 p-0 text-slate-600 hover:text-red-500"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredAlerts.length === 0 && (
          <Card className="border-slate-200">
            <CardContent className="py-12 text-center">
              <Bell className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="font-space-grotesk text-lg mb-2">No alerts found</h3>
              <p className="text-slate-600">
                {filter === 'all' 
                  ? "You're all caught up! No alerts to display."
                  : "No alerts match your current filters."
                }
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}