import React from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Alert, AlertDescription } from '../ui/alert';
import { Loader2, Eye, EyeOff } from 'lucide-react';

interface AuthForm {
  email: string;
  password: string;
  name?: string;
  role?: string;
  organization?: string;
}

interface AuthFormProps {
  mode: 'login' | 'signup';
  form: AuthForm;
  setForm: React.Dispatch<React.SetStateAction<AuthForm>>;
  onSubmit: (e: React.FormEvent) => Promise<void>;
  loading: boolean;
  error: string;
  onToggleMode: () => void;
}

export function AuthForm({
  mode,
  form,
  setForm,
  onSubmit,
  loading,
  error,
  onToggleMode
}: AuthFormProps) {
  const [showPassword, setShowPassword] = React.useState(false);

  const handleInputChange = (field: keyof AuthForm, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const isSignup = mode === 'signup';

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {error && (
        <Alert className="border-red-200 bg-red-50">
          <AlertDescription className="text-red-700">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Email */}
      <div className="space-y-2">
        <Label htmlFor="email">Email Address</Label>
        <Input
          id="email"
          type="email"
          placeholder="your.email@school.edu"
          value={form.email}
          onChange={(e) => handleInputChange('email', e.target.value)}
          className="bg-sky-50 border-slate-200"
          required
          disabled={loading}
        />
      </div>

      {/* Password */}
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <div className="relative">
          <Input
            id="password"
            type={showPassword ? 'text' : 'password'}
            placeholder={isSignup ? 'Create a secure password (min. 6 characters)' : 'Enter your password'}
            value={form.password}
            onChange={(e) => handleInputChange('password', e.target.value)}
            className="bg-sky-50 border-slate-200 pr-10"
            required
            disabled={loading}
            minLength={isSignup ? 6 : undefined}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-500 hover:text-slate-700"
            disabled={loading}
          >
            {showPassword ? (
              <EyeOff className="h-4 w-4" />
            ) : (
              <Eye className="h-4 w-4" />
            )}
          </button>
        </div>
      </div>

      {/* Signup-only fields */}
      {isSignup && (
        <>
          {/* Full Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Full Name</Label>
            <Input
              id="name"
              type="text"
              placeholder="Your full name"
              value={form.name || ''}
              onChange={(e) => handleInputChange('name', e.target.value)}
              className="bg-sky-50 border-slate-200"
              required
              disabled={loading}
            />
          </div>

          {/* Organization */}
          <div className="space-y-2">
            <Label htmlFor="organization">School/Organization</Label>
            <Input
              id="organization"
              type="text"
              placeholder="Your school or organization name"
              value={form.organization || ''}
              onChange={(e) => handleInputChange('organization', e.target.value)}
              className="bg-sky-50 border-slate-200"
              required
              disabled={loading}
            />
          </div>

          {/* Role */}
          <div className="space-y-2">
            <Label htmlFor="role">Initial Role</Label>
            <Select 
              value={form.role || 'writer'} 
              onValueChange={(value) => handleInputChange('role', value)}
              disabled={loading}
            >
              <SelectTrigger className="bg-sky-50 border-slate-200">
                <SelectValue placeholder="Select your role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="writer">Grant Writer</SelectItem>
                <SelectItem value="admin">Administrator</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-600">
              Note: Admin roles require approval. You can request role changes after account creation.
            </p>
          </div>
        </>
      )}

      {/* Submit Button */}
      <Button
        type="submit"
        className="w-full bg-navy hover:bg-navy/90 text-white"
        disabled={loading}
      >
        {loading ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            {isSignup ? 'Creating Account...' : 'Signing In...'}
          </>
        ) : (
          <>
            {isSignup ? 'Create Account' : 'Sign In'}
          </>
        )}
      </Button>

      {/* Toggle Mode */}
      <div className="text-center pt-4 border-t border-slate-200">
        <p className="text-sm text-slate-600">
          {isSignup ? 'Already have an account?' : "Don't have an account?"}
          {' '}
          <button
            type="button"
            onClick={onToggleMode}
            className="text-indigo hover:text-indigo/80 font-medium"
            disabled={loading}
          >
            {isSignup ? 'Sign In' : 'Sign Up'}
          </button>
        </p>
      </div>

      {/* Additional Help Text */}
      {!isSignup && (
        <div className="text-center">
          <p className="text-xs text-slate-500">
            New to GrantForge.ai? Try one of the demo accounts above to explore the platform.
          </p>
        </div>
      )}
    </form>
  );
}