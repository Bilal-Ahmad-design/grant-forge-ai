import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { AuthForm } from './AuthForm';
import { DemoAccounts } from './DemoAccounts';
import { Separator } from '../ui/separator';
import { Logo, BrandText } from '../layout/Logo';
import { DemoAccountType } from '../../utils/auth/demoAccounts';

interface AuthForm {
  email: string;
  password: string;
  name?: string;
  role?: string;
  organization?: string;
}

interface AuthScreenProps {
  authMode: 'login' | 'signup';
  authForm: AuthForm;
  setAuthForm: React.Dispatch<React.SetStateAction<AuthForm>>;
  onAuth: (e: React.FormEvent) => Promise<void>;
  onDemoLogin: (demoType: DemoAccountType) => Promise<void>;
  authLoading: boolean;
  authError: string;
  onToggleMode: () => void;
}

export function AuthScreen({
  authMode,
  authForm,
  setAuthForm,
  onAuth,
  onDemoLogin,
  authLoading,
  authError,
  onToggleMode
}: AuthScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Logo and Brand Header */}
        <div className="text-center mb-8">
          <Logo 
            size="xl" 
            showText={true}
            className="justify-center mb-4"
          />
          <h1 className="font-space-grotesk text-2xl text-slate-700 mb-2">
            K-12 Grant Discovery & Management Platform
          </h1>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Streamline your grant-writing process with AI-powered research, collaborative workflows, 
            and comprehensive tracking from discovery to award.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Authentication Form */}
          <Card className="border-slate-200 shadow-lg">
            <CardHeader className="space-y-2">
              <CardTitle className="text-2xl text-center font-space-grotesk text-navy">
                {authMode === 'login' ? 'Welcome Back' : 'Get Started'}
              </CardTitle>
              <p className="text-sm text-slate-600 text-center">
                {authMode === 'login' 
                  ? 'Sign in to continue your grant-writing journey'
                  : 'Create your account to start discovering grants'
                }
              </p>
            </CardHeader>
            <CardContent>
              <AuthForm
                mode={authMode}
                form={authForm}
                setForm={setAuthForm}
                onSubmit={onAuth}
                loading={authLoading}
                error={authError}
                onToggleMode={onToggleMode}
              />
            </CardContent>
          </Card>

          {/* Demo Accounts */}
          <Card className="border-slate-200 shadow-lg">
            <CardHeader className="space-y-2">
              <CardTitle className="text-2xl text-center font-space-grotesk text-navy">
                Try a Demo Account
              </CardTitle>
              <p className="text-sm text-slate-600 text-center">
                Experience <BrandText size="sm" className="font-medium" /> with different user roles and permissions
              </p>
            </CardHeader>
            <CardContent>
              <DemoAccounts 
                onDemoLogin={onDemoLogin}
                loading={authLoading}
              />
            </CardContent>
          </Card>
        </div>

        {/* Features Preview */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-6 bg-white/60 backdrop-blur-sm rounded-lg border border-slate-200">
            <div className="h-12 w-12 bg-indigo text-white rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h3 className="font-space-grotesk font-semibold text-navy mb-2">AI-Powered Discovery</h3>
            <p className="text-sm text-slate-600">
              Find relevant grants faster with intelligent matching and automated research
            </p>
          </div>

          <div className="text-center p-6 bg-white/60 backdrop-blur-sm rounded-lg border border-slate-200">
            <div className="h-12 w-12 bg-amber text-navy rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h3 className="font-space-grotesk font-semibold text-navy mb-2">Team Collaboration</h3>
            <p className="text-sm text-slate-600">
              Coordinate writers with role-based permissions and approval workflows
            </p>
          </div>

          <div className="text-center p-6 bg-white/60 backdrop-blur-sm rounded-lg border border-slate-200">
            <div className="h-12 w-12 bg-emerald text-white rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v4a2 2 0 01-2 2h-2a2 2 0 00-2 2z" />
              </svg>
            </div>
            <h3 className="font-space-grotesk font-semibold text-navy mb-2">Progress Tracking</h3>
            <p className="text-sm text-slate-600">
              Monitor applications through every stage with detailed analytics
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-slate-500">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Logo size="sm" showText={false} />
            <span>
              <BrandText size="sm" className="font-medium" />
              <span className="text-slate-500"> - Empowering K-12 Education</span>
            </span>
          </div>
          <p>Built with Clarity, Momentum, and Trust</p>
        </div>
      </div>
    </div>
  );
}