import React from 'react';
import { Loader2 } from 'lucide-react';
import { Logo } from '../layout/Logo';

interface LoadingScreenProps {
  message?: string;
}

export function LoadingScreen({ message = "Loading..." }: LoadingScreenProps = {}) {
  const isOptimizing = message.includes('Optimizing');
  const isInitializing = message.includes('Initializing');
  
  const getSubtitle = () => {
    if (isOptimizing) {
      return 'Refreshing cache for optimal performance';
    }
    if (isInitializing) {
      return 'Setting up your workspace';
    }
    return 'Preparing your grant management platform';
  };

  const getExtraInfo = () => {
    if (isOptimizing) {
      return 'This ensures you have the latest features and fastest loading times';
    }
    if (isInitializing) {
      return 'This will only take a moment';
    }
    return null;
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-slate-100 flex items-center justify-center">
      <div className="text-center">
        <div className="mb-8">
          <Logo 
            size="xl" 
            showText={true}
            className="justify-center mb-4"
          />
        </div>
        
        <div className="flex items-center justify-center gap-3 mb-4">
          <Loader2 className="h-8 w-8 animate-spin text-indigo" />
          <span className="text-xl font-space-grotesk text-navy">{message}</span>
        </div>
        
        <p className="text-slate-600 max-w-md mx-auto">
          {getSubtitle()}
        </p>
        
        {getExtraInfo() && (
          <div className="mt-4 text-sm text-slate-500">
            <p>{getExtraInfo()}</p>
          </div>
        )}
      </div>
    </div>
  );
}