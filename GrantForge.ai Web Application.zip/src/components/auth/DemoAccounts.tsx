import React from 'react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { UserAvatar } from '../ui/user-avatar';
import { Shield, User, PenTool, GraduationCap, Loader2 } from 'lucide-react';
import { DemoAccountType } from '../../utils/auth/demoAccounts';

interface DemoAccountsProps {
  onDemoLogin: (demoType: DemoAccountType) => Promise<void>;
  loading: boolean;
}

export function DemoAccounts({ onDemoLogin, loading }: DemoAccountsProps) {
  const demoAccounts = [
    {
      type: 'super-admin' as DemoAccountType,
      name: 'Sarah Johnson',
      title: 'Platform Super Administrator',
      email: 'sarah.johnson@grantforge.ai',
      description: 'Full platform access, user management, and system oversight',
      icon: Shield,
      badge: { text: 'Super Admin', color: 'bg-red-100 text-red-700' },
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
    },
    {
      type: 'admin' as DemoAccountType,
      name: 'Michael Rodriguez',
      title: 'Grant Writing Administrator',
      email: 'michael.rodriguez@propelgrants.com',
      description: 'Manages team workflows, client relationships, and approvals. Can approve opportunities and submissions.',
      icon: User,
      badge: { text: 'Admin', color: 'bg-indigo text-white' },
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
    },
    {
      type: 'writer' as DemoAccountType,
      name: 'Dr. Lisa Chen',
      title: 'Grant Writer',
      email: 'lisa.chen@propelgrants.com',
      description: 'Grant writing professional who researches and writes grants. Requires admin approval for submissions.',
      icon: PenTool,
      badge: { text: 'Writer', color: 'bg-emerald text-white' },
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
    }
  ];

  return (
    <div className="space-y-4">
      {demoAccounts.map((account) => (
        <Card key={account.type} className="border-slate-200 hover:border-indigo/30 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-start gap-4">
              <UserAvatar
                src={account.avatar}
                name={account.name}
                size="lg"
              />
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-space-grotesk font-semibold text-navy truncate">
                    {account.name}
                  </h3>
                  <Badge className={account.badge.color}>
                    {account.badge.text}
                  </Badge>
                </div>
                
                <p className="text-sm text-slate-600 mb-1">{account.title}</p>
                <p className="text-xs text-slate-500 mb-2">{account.email}</p>
                <p className="text-sm text-slate-700 leading-relaxed mb-3">
                  {account.description}
                </p>
                
                <Button
                  onClick={() => onDemoLogin(account.type)}
                  disabled={loading}
                  className="w-full gap-2 bg-navy hover:bg-navy/90 text-white"
                  size="sm"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Signing In...
                    </>
                  ) : (
                    <>
                      <account.icon className="h-4 w-4" />
                      Try {account.badge.text}
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      <div className="mt-6 p-4 bg-sky-50 rounded-lg border border-slate-200">
        <h4 className="font-space-grotesk font-medium text-navy mb-2">
          Role-Based Access Control
        </h4>
        <div className="text-sm text-slate-600 space-y-1">
          <p>• <strong>Super Admin:</strong> Platform management and system oversight</p>
          <p>• <strong>Admin:</strong> Grant writing firm management, client relationships, and all approvals</p>
          <p>• <strong>Writer:</strong> Grant research and writing - requires admin approval for all submissions</p>
        </div>
      </div>
    </div>
  );
}