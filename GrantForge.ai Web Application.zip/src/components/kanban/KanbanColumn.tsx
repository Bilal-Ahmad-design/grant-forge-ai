import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Target } from 'lucide-react';
import { Column, Grant, User as UserType, TeamMember } from './types';
import { GrantCard } from './GrantCard';
import { formatAmount } from './helpers';

interface KanbanColumnProps {
  column: Column;
  user: UserType;
  teamMembers: TeamMember[];
  submitting: boolean;
  onMoveStage: (grantId: string, newStage: string) => void;
  onSelfAssign: (grantId: string) => void;
  onOpenAssignDialog: (grant: Grant) => void;
  onOpenApprovalDialog: (grant: Grant, action: 'approve' | 'reject') => void;
}

export function KanbanColumn({
  column,
  user,
  teamMembers,
  submitting,
  onMoveStage,
  onSelfAssign,
  onOpenAssignDialog,
  onOpenApprovalDialog
}: KanbanColumnProps) {
  const Icon = column.icon;

  return (
    <Card className={`${column.color} border-2`}>
      <CardHeader className="pb-3">
        <CardTitle className="font-space-grotesk text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Icon className="h-4 w-4" />
            {column.title}
          </div>
          <Badge variant="secondary">{column.grants.length}</Badge>
        </CardTitle>
        <CardDescription className="text-xs">
          {column.description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {column.grants.map((grant) => (
          <GrantCard
            key={grant.id}
            grant={grant}
            user={user}
            teamMembers={teamMembers}
            submitting={submitting}
            onMoveStage={onMoveStage}
            onSelfAssign={onSelfAssign}
            onOpenAssignDialog={onOpenAssignDialog}
            onOpenApprovalDialog={onOpenApprovalDialog}
          />
        ))}

        {column.grants.length === 0 && (
          <div className="text-center py-8 text-slate-500">
            <div className="text-xs">No grants in this stage</div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}