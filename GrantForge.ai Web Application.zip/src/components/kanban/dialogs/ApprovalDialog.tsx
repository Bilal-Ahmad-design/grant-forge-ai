import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../../ui/dialog';
import { Button } from '../../ui/button';
import { Label } from '../../ui/label';
import { Textarea } from '../../ui/textarea';
import { Loader2 } from 'lucide-react';

interface ApprovalDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  approvalAction: 'approve' | 'reject';
  approvalComments: string;
  setApprovalComments: (comments: string) => void;
  submitting: boolean;
  onApproval: () => void;
}

export function ApprovalDialog({
  open,
  onOpenChange,
  approvalAction,
  approvalComments,
  setApprovalComments,
  submitting,
  onApproval
}: ApprovalDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {approvalAction === 'approve' ? 'Approve Grant' : 'Request Revisions'}
          </DialogTitle>
          <DialogDescription>
            {approvalAction === 'approve' 
              ? 'Approve this grant for submission to the funder.'
              : 'Request revisions from the writer before submission.'
            }
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Comments {approvalAction === 'reject' ? '(Required)' : '(Optional)'}</Label>
            <Textarea
              value={approvalComments}
              onChange={(e) => setApprovalComments(e.target.value)}
              placeholder={
                approvalAction === 'approve' 
                  ? 'Add any final notes before approval...'
                  : 'Describe what needs to be revised...'
              }
              rows={4}
            />
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={onApproval}
              disabled={submitting || (approvalAction === 'reject' && !approvalComments.trim())}
              className={`flex-1 ${approvalAction === 'approve' ? 'bg-emerald hover:bg-emerald/90' : 'bg-red-500 hover:bg-red-600'}`}
            >
              {submitting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                approvalAction === 'approve' ? 'Approve Grant' : 'Request Revisions'
              )}
            </Button>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}