import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../../ui/dialog';
import { Button } from '../../ui/button';
import { Label } from '../../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';
import { Loader2 } from 'lucide-react';
import { Grant, TeamMember } from '../types';
import { ROLE_ICONS } from '../constants';

interface AssignmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedGrant: Grant | null;
  selectedAssignee: string;
  setSelectedAssignee: (assignee: string) => void;
  teamMembers: TeamMember[];
  submitting: boolean;
  onAssign: () => void;
}

export function AssignmentDialog({
  open,
  onOpenChange,
  selectedGrant,
  selectedAssignee,
  setSelectedAssignee,
  teamMembers,
  submitting,
  onAssign
}: AssignmentDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Assign Grant</DialogTitle>
          <DialogDescription>
            Choose a team member to assign this grant to.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Assign to:</Label>
            <Select value={selectedAssignee} onValueChange={setSelectedAssignee}>
              <SelectTrigger>
                <SelectValue placeholder="Select team member" />
              </SelectTrigger>
              <SelectContent>
                {teamMembers.map((member) => {
                  const MemberIcon = ROLE_ICONS[member.role as keyof typeof ROLE_ICONS] || ROLE_ICONS.default;
                  return (
                    <SelectItem key={member.id} value={member.id}>
                      <div className="flex items-center gap-2">
                        <MemberIcon className="h-4 w-4" />
                        {member.name} ({member.role.replace('-', ' ')})
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={onAssign}
              disabled={!selectedAssignee || submitting}
              className="flex-1"
            >
              {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Assign'}
            </Button>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}