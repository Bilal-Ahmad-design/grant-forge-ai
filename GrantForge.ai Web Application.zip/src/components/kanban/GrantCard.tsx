import React from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { 
  DollarSign, 
  Calendar, 
  User, 
  Clock, 
  ArrowRight,
  UserCheck,
  Award,
  XCircle,
  CheckCircle,
  Loader2
} from 'lucide-react';
import { Grant, User as UserType, TeamMember } from './types';
import { 
  STAGE_ICONS, 
  PRIORITY_COLORS, 
  STAGE_NAMES 
} from './constants';
import { 
  getNextStage, 
  getPreviousStage, 
  canMoveToStage, 
  getAssigneeName,
  canSelfAssign,
  canAssignToOthers,
  canApprove,
  canApproveGrant
} from './helpers';

interface GrantCardProps {
  grant: Grant;
  user: UserType;
  teamMembers: TeamMember[];
  submitting: boolean;
  onMoveStage: (grantId: string, newStage: string) => void;
  onSelfAssign: (grantId: string) => void;
  onOpenAssignDialog: (grant: Grant) => void;
  onOpenApprovalDialog: (grant: Grant, action: 'approve' | 'reject') => void;
}

export function GrantCard({
  grant,
  user,
  teamMembers,
  submitting,
  onMoveStage,
  onSelfAssign,
  onOpenAssignDialog,
  onOpenApprovalDialog
}: GrantCardProps) {
  const StageIcon = STAGE_ICONS[grant.stage as keyof typeof STAGE_ICONS] || STAGE_ICONS.research;
  const nextStage = getNextStage(grant.stage);
  const prevStage = getPreviousStage(grant.stage);
  const canMoveNext = nextStage && canMoveToStage(user, grant, nextStage).allowed;
  const canMovePrev = prevStage && canMoveToStage(user, grant, prevStage).allowed;

  return (
    <Card className="border-slate-200 hover:border-indigo transition-colors">
      <CardContent className="p-4 space-y-3">
        {/* Grant Header */}
        <div className="space-y-2">
          <div className="flex items-start justify-between">
            <h4 className="font-medium text-navy text-sm leading-tight flex-1">
              {grant.title}
            </h4>
            <Badge 
              className={PRIORITY_COLORS[grant.priority as keyof typeof PRIORITY_COLORS] || PRIORITY_COLORS.default} 
              variant="outline"
            >
              {grant.priority}
            </Badge>
          </div>
          <p className="text-xs text-slate-600">{grant.funder}</p>
          {grant.client_name && (
            <p className="text-xs text-slate-500">Client: {grant.client_name}</p>
          )}
        </div>

        {/* Grant Details */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-1">
            <DollarSign className="h-3 w-3 text-emerald" />
            <span className="font-medium text-emerald">{grant.amount}</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="h-3 w-3 text-red-500" />
            <span className="text-slate-600">
              {new Date(grant.deadline).toLocaleDateString()}
            </span>
          </div>
        </div>

        {/* Progress and Hours */}
        {grant.progress && grant.progress > 0 && (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600">Progress</span>
              <span className="font-medium">{grant.progress}%</span>
            </div>
            <Progress value={grant.progress} className="h-1" />
          </div>
        )}

        {grant.estimated_hours && (
          <div className="text-xs text-slate-600">
            <Clock className="h-3 w-3 inline mr-1" />
            {grant.actual_hours || 0}/{grant.estimated_hours}h
          </div>
        )}

        {/* Assignment Info */}
        <div className="text-xs">
          <div className="flex items-center gap-1 mb-1">
            <User className="h-3 w-3 text-slate-600" />
            <span className="text-slate-600">Assigned: {getAssigneeName(grant, user, teamMembers)}</span>
          </div>
          {grant.updated_by_name && (
            <p className="text-slate-500">Updated by: {grant.updated_by_name}</p>
          )}
        </div>

        {/* Tags */}
        {grant.tags && grant.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {grant.tags.slice(0, 2).map((tag, index) => (
              <Badge key={index} className="bg-slate-100 text-slate-600 text-xs px-1 py-0">
                {tag}
              </Badge>
            ))}
            {grant.tags.length > 2 && (
              <Badge className="bg-slate-100 text-slate-600 text-xs px-1 py-0">
                +{grant.tags.length - 2}
              </Badge>
            )}
          </div>
        )}

        {/* Stage Status */}
        {grant.stage === 'awarded' || grant.stage === 'denied' ? (
          <div className="text-center py-2">
            <div className={`font-bold text-lg ${
              grant.stage === 'awarded' 
                ? 'text-emerald' 
                : 'text-red-500'
            }`}>
              {grant.stage === 'awarded' ? 'AWARDED' : 'DENIED'}
            </div>
            <div className="flex items-center justify-center gap-1 mt-1">
              <StageIcon className={`h-4 w-4 ${
                grant.stage === 'awarded' ? 'text-emerald' : 'text-red-500'
              }`} />
              <span className={`text-sm font-medium ${
                grant.stage === 'awarded' ? 'text-emerald' : 'text-red-500'
              }`}>
                Final Result
              </span>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-1 text-xs">
            <StageIcon className="h-3 w-3 text-slate-600" />
            <span className="text-slate-600 capitalize">
              {STAGE_NAMES[grant.stage as keyof typeof STAGE_NAMES] || grant.stage}
            </span>
            {grant.approval_status === 'pending' && (
              <Badge className="bg-orange-100 text-orange-600 text-xs ml-1">
                Pending Approval
              </Badge>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col gap-2 pt-2 border-t border-slate-100">
          {/* Assignment Actions */}
          {!grant.assigned_to && (
            <div className="flex gap-1">
              {canSelfAssign(user.role) && (
                <Button 
                  size="sm" 
                  className="flex-1 text-xs h-7 bg-indigo hover:bg-indigo/90"
                  onClick={() => onSelfAssign(grant.id)}
                  disabled={submitting}
                >
                  {submitting ? <Loader2 className="h-3 w-3 animate-spin" /> : 'Self-Assign'}
                </Button>
              )}
              {canAssignToOthers(user.role) && (
                <Button 
                  size="sm" 
                  variant="outline"
                  className="flex-1 text-xs h-7"
                  onClick={() => onOpenAssignDialog(grant)}
                >
                  <UserCheck className="h-3 w-3" />
                </Button>
              )}
            </div>
          )}

          {/* Stage Movement Actions */}
          {grant.assigned_to === user.id || ['super-admin', 'admin'].includes(user.role) ? (
            <div className="flex gap-1">
              {/* Previous Stage */}
              {canMovePrev && (
                <Button 
                  size="sm" 
                  variant="outline"
                  className="text-xs h-7 px-2"
                  onClick={() => onMoveStage(grant.id, prevStage!)}
                  disabled={submitting}
                >
                  ←
                </Button>
              )}
              
              {/* Next Stage */}
              {canMoveNext && (
                <Button 
                  size="sm" 
                  className="flex-1 text-xs h-7 bg-emerald hover:bg-emerald/90"
                  onClick={() => onMoveStage(grant.id, nextStage!)}
                  disabled={submitting}
                >
                  {submitting ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <>
                      {nextStage === 'submitted' && user.role === 'writer' ? 'Submit for Approval' : `Move to ${nextStage}`}
                      <ArrowRight className="h-3 w-3 ml-1" />
                    </>
                  )}
                </Button>
              )}

              {/* Final Stage Actions */}
              {grant.stage === 'submitted' && canApproveGrant(user, grant) && (
                <>
                  <Button 
                    size="sm" 
                    className="text-xs h-7 px-2 bg-emerald hover:bg-emerald/90"
                    onClick={() => onMoveStage(grant.id, 'awarded')}
                    disabled={submitting}
                  >
                    <Award className="h-3 w-3" />
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="text-xs h-7 px-2 border-red-200 text-red-600 hover:bg-red-50"
                    onClick={() => onMoveStage(grant.id, 'denied')}
                    disabled={submitting}
                  >
                    <XCircle className="h-3 w-3" />
                  </Button>
                </>
              )}
            </div>
          ) : (
            <div className="text-xs text-slate-500 text-center py-1">
              {grant.assigned_to ? 'Assigned to another team member' : 'Available for assignment'}
            </div>
          )}

          {/* Approval Actions for Admins Only */}
          {grant.approval_status === 'pending' && canApproveGrant(user, grant) && (
            <div className="flex gap-1">
              <Button 
                size="sm" 
                className="flex-1 text-xs h-7 bg-emerald hover:bg-emerald/90"
                onClick={() => onOpenApprovalDialog(grant, 'approve')}
              >
                <CheckCircle className="h-3 w-3 mr-1" />
                Approve
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                className="flex-1 text-xs h-7 border-red-200 text-red-600 hover:bg-red-50"
                onClick={() => onOpenApprovalDialog(grant, 'reject')}
              >
                <XCircle className="h-3 w-3 mr-1" />
                Reject
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}