import { 
  Search, 
  PenTool, 
  Eye, 
  FileText, 
  Target,
  Crown,
  Settings,
  BookOpen,
  User,
  Award,
  XCircle
} from 'lucide-react';

export const STAGE_ORDER = ['research', 'writing', 'review', 'submitted', 'awarded', 'denied'];

export const STAGE_CONFIGS = [
  {
    id: 'research',
    title: 'Research',
    stage: 'research',
    color: 'border-blue-200 bg-blue-50',
    icon: Search,
    description: 'Grant opportunity research and analysis'
  },
  {
    id: 'writing',
    title: 'Writing',
    stage: 'writing',
    color: 'border-indigo bg-indigo/10',
    icon: PenTool,
    description: 'Proposal drafting and development'
  },
  {
    id: 'review',
    title: 'Review',
    stage: 'review',
    color: 'border-amber bg-amber/10',
    icon: Eye,
    description: 'Quality review and refinement'
  },
  {
    id: 'submitted',
    title: 'Submitted',
    stage: 'submitted',
    color: 'border-purple-200 bg-purple-50',
    icon: FileText,
    description: 'Submitted to funders'
  },
  {
    id: 'final',
    title: 'Final Results',
    stage: 'final',
    color: 'border-slate-200 bg-slate-50',
    icon: Target,
    description: 'Awarded or denied outcomes'
  }
];

export const STAGE_ICONS = {
  research: Search,
  writing: PenTool,
  review: Eye,
  submitted: FileText,
  awarded: Award,
  denied: XCircle
};

export const ROLE_ICONS = {
  'super-admin': Crown,
  'admin': Settings,
  'senior-writer': PenTool,
  'junior-writer': BookOpen,
  'default': User
};

export const ROLE_COLORS = {
  'super-admin': 'text-purple-600',
  'admin': 'text-indigo',
  'senior-writer': 'text-emerald',
  'junior-writer': 'text-amber',
  'default': 'text-slate-600'
};

export const PRIORITY_COLORS = {
  high: 'bg-red-100 text-red-700 border-red-200',
  medium: 'bg-amber/20 text-amber border-amber/30',
  low: 'bg-slate-100 text-slate-600 border-slate-200',
  default: 'bg-slate-100 text-slate-600 border-slate-200'
};

export const STAGE_NAMES = {
  research: 'Research',
  writing: 'Writing',
  review: 'Review',
  submitted: 'Submitted',
  awarded: 'Awarded',
  denied: 'Denied'
};