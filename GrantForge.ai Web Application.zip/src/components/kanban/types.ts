export interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

export interface Grant {
  id: string;
  title: string;
  funder: string;
  amount: string;
  deadline: string;
  stage: 'research' | 'writing' | 'review' | 'submitted' | 'awarded' | 'denied';
  priority: 'low' | 'medium' | 'high';
  assignee?: string;
  assigned_to?: string;
  organization?: string;
  created_by?: string;
  created_by_name?: string;
  requires_approval?: boolean;
  approval_status?: 'pending' | 'approved' | 'rejected';
  approval_history?: any[];
  submitted_for_approval_at?: string;
  submitted_by?: string;
  updated_at?: string;
  updated_by_name?: string;
  progress?: number;
  client_name?: string;
  estimated_hours?: number;
  actual_hours?: number;
  tags?: string[];
}

export interface Column {
  id: string;
  title: string;
  stage: string;
  color: string;
  icon: React.ComponentType<any>;
  grants: Grant[];
  description: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
}

export interface KanbanBoardProps {
  user: User;
  onNavigate?: (page: string) => void;
}