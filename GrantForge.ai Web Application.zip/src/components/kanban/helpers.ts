import { Grant, User } from './types';
import { STAGE_ORDER } from './constants';

// Utility function to format large numbers
export const formatAmount = (amount: string): string => {
  if (amount.includes('-')) {
    const parts = amount.split('-');
    const min = formatSingleAmount(parts[0].trim());
    const max = formatSingleAmount(parts[1].trim());
    return `${min} - ${max}`;
  }
  return formatSingleAmount(amount);
};

export const formatSingleAmount = (amount: string): string => {
  const match = amount.match(/\$?([\d,]+(?:,\d{3})*)/);
  if (!match) return amount;
  
  const num = parseInt(match[1].replace(/,/g, ''));
  if (num >= 1000000) {
    return `$${(num / 1000000).toFixed(num % 1000000 === 0 ? 0 : 1)}M`;
  } else if (num >= 1000) {
    return `$${(num / 1000).toFixed(num % 1000 === 0 ? 0 : 0)}K`;
  }
  return amount;
};

// Permission checking functions
export const canSelfAssign = (userRole: string): boolean => {
  return ['super-admin', 'admin', 'writer'].includes(userRole);
};

export const canAssignToOthers = (userRole: string): boolean => {
  return ['super-admin', 'admin'].includes(userRole);
};

export const canApprove = (userRole: string): boolean => {
  return ['super-admin', 'admin'].includes(userRole);
};

export const canApproveGrant = (user: User, grant: Grant): boolean => {
  // Only super admins and admins can approve grants
  return ['super-admin', 'admin'].includes(user.role);
};

export const requiresApprovalForStage = (userRole: string, stage: string): boolean => {
  return userRole === 'writer' && stage === 'submitted';
};

export const canMoveToStage = (user: User, grant: Grant, newStage: string) => {
  const currentIndex = STAGE_ORDER.indexOf(grant.stage);
  const newIndex = STAGE_ORDER.indexOf(newStage);

  // Super admins and admins can move grants freely
  if (['super-admin', 'admin'].includes(user.role)) {
    return { allowed: true, reason: '' };
  }

  // Must be assigned to user to move (except admins)
  if (grant.assigned_to !== user.id && !['super-admin', 'admin'].includes(user.role)) {
    return { allowed: false, reason: 'You can only move grants assigned to you' };
  }

  // Can't move backwards more than one stage (except final stages)
  if (newIndex < currentIndex - 1 && !['awarded', 'denied'].includes(newStage)) {
    return { allowed: false, reason: 'Cannot move backwards more than one stage' };
  }

  // Writers need approval for final submission
  if (user.role === 'writer' && newStage === 'submitted') {
    return { allowed: true, reason: 'Will require admin approval' };
  }

  // Can't skip stages in forward progression
  if (newIndex > currentIndex + 1 && currentIndex < 3) {
    return { allowed: false, reason: 'Cannot skip stages in the pipeline' };
  }

  return { allowed: true, reason: '' };
};

export const getNextStage = (currentStage: string): string | null => {
  const stageOrder = ['research', 'writing', 'review', 'submitted'];
  const currentIndex = stageOrder.indexOf(currentStage);
  return currentIndex < stageOrder.length - 1 ? stageOrder[currentIndex + 1] : null;
};

export const getPreviousStage = (currentStage: string): string | null => {
  const stageOrder = ['research', 'writing', 'review', 'submitted'];
  const currentIndex = stageOrder.indexOf(currentStage);
  return currentIndex > 0 ? stageOrder[currentIndex - 1] : null;
};

export const getAssigneeName = (grant: Grant, user: User, teamMembers: any[]): string => {
  if (!grant.assigned_to) return 'Unassigned';
  if (grant.assigned_to === user.id) return 'You';
  
  const assignee = teamMembers.find(m => m.id === grant.assigned_to);
  return assignee ? assignee.name : 'Unknown User';
};

export const createDemoGrants = (user: User): Grant[] => {
  return [
    {
      id: 'grant1',
      title: 'STEM Education Innovation Grant',
      funder: 'National Science Foundation',
      amount: formatAmount('$350,000'),
      deadline: '2024-09-15',
      stage: 'research',
      priority: 'high',
      organization: user.organization,
      created_by: 'admin1',
      created_by_name: 'Michael Rodriguez',
      assigned_to: user.role === 'writer' ? user.id : 'user2',
      requires_approval: false,
      progress: 35,
      client_name: 'Roosevelt Elementary School',
      estimated_hours: 120,
      actual_hours: 42,
      tags: ['STEM', 'K-5', 'Innovation']
    },
    {
      id: 'grant2',
      title: 'Rural Education Achievement Program',
      funder: 'US Department of Education',
      amount: formatAmount('$220,000'),
      deadline: '2024-08-30',
      stage: 'writing',
      priority: 'medium',
      assigned_to: user.role === 'writer' ? user.id : 'user3',
      organization: user.organization,
      created_by: 'admin1',
      created_by_name: 'Michael Rodriguez',
      requires_approval: user.role === 'writer',
      progress: 75,
      client_name: 'Jefferson High School',
      estimated_hours: 80,
      actual_hours: 60,
      tags: ['Rural', 'Achievement', 'K-12']
    },
    {
      id: 'grant3',
      title: 'Digital Infrastructure Modernization',
      funder: 'Federal Communications Commission',
      amount: formatAmount('$650,000'),
      deadline: '2024-11-15',
      stage: user.role === 'junior-writer' ? 'review' : 'submitted',
      priority: 'high',
      assigned_to: user.role === 'junior-writer' ? user.id : (user.role === 'senior-writer' ? user.id : 'user4'),
      organization: user.organization,
      created_by: 'admin1',
      created_by_name: 'Michael Rodriguez',
      requires_approval: true,
      approval_status: user.role === 'junior-writer' ? 'pending' : (user.role === 'senior-writer' ? 'pending' : 'approved'),
      progress: 95,
      client_name: 'Lincoln Middle School',
      estimated_hours: 200,
      actual_hours: 190,
      tags: ['Technology', 'Infrastructure', 'Modernization']
    },
    {
      id: 'grant4',
      title: 'Special Education Support Initiative',
      funder: 'State Education Department',
      amount: formatAmount('$95,000'),
      deadline: '2024-07-20',
      stage: 'awarded',
      priority: 'medium',
      assigned_to: 'user2',
      organization: user.organization,
      created_by: 'admin1',
      created_by_name: 'Michael Rodriguez',
      progress: 100,
      client_name: 'Washington Elementary',
      estimated_hours: 60,
      actual_hours: 58,
      tags: ['Special Ed', 'Support', 'Inclusion']
    },
    {
      id: 'grant5',
      title: 'Community Engagement in Education',
      funder: 'Local Foundation',
      amount: formatAmount('$45,000'),
      deadline: '2024-06-30',
      stage: 'denied',
      priority: 'low',
      assigned_to: 'user3',
      organization: user.organization,
      created_by: 'admin1',
      created_by_name: 'Michael Rodriguez',
      progress: 100,
      client_name: 'Community Learning Center',
      estimated_hours: 40,
      actual_hours: 38,
      tags: ['Community', 'Engagement', 'Outreach']
    },
    // Additional grant for senior writers to demonstrate self-approval
    ...(user.role === 'senior-writer' ? [{
      id: 'grant6',
      title: 'Arts Integration Program',
      funder: 'National Endowment for the Arts',
      amount: formatAmount('$125,000'),
      deadline: '2024-09-10',
      stage: 'submitted' as const,
      priority: 'medium' as const,
      assigned_to: user.id,
      organization: user.organization,
      created_by: user.id,
      created_by_name: user.name,
      requires_approval: true,
      approval_status: 'pending' as const,
      progress: 100,
      client_name: 'Madison Arts High School',
      estimated_hours: 90,
      actual_hours: 88,
      tags: ['Arts', 'Integration', 'Creative']
    }] : [])
  ];
};