import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { 
  Users, 
  UserPlus, 
  Edit, 
  Trash2, 
  Search,
  MoreHorizontal,
  Shield,
  Mail,
  Phone,
  Building,
  Calendar,
  Eye,
  UserCheck
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
  department?: string;
  phone?: string;
  joinDate: string;
  lastActive: string;
  status: 'active' | 'inactive';
  projectsCount: number;
  grantsWon: number;
  totalValue: number;
  gender: 'male' | 'female';
}

interface UserManagementProps {
  user: User;
  onImpersonate?: (targetUser: User) => void;
}

// Utility function to format large numbers
const formatValue = (value: number): string => {
  if (value >= 1000000) {
    return `$${(value / 1000000).toFixed(value % 1000000 === 0 ? 0 : 1)}M`;
  } else if (value >= 1000) {
    return `$${(value / 1000).toFixed(value % 1000 === 0 ? 0 : 0)}K`;
  }
  return `$${value.toLocaleString()}`;
};

// Get appropriate profile picture based on gender and name
const getProfilePicture = (name: string, gender: 'male' | 'female', id: string): string => {
  const femalePhotos = [
    'https://images.unsplash.com/photo-1494790108755-2616b612b5ad?w=48&h=48&fit=crop&crop=face',
    'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=48&h=48&fit=crop&crop=face',
    'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=48&h=48&fit=crop&crop=face',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=48&h=48&fit=crop&crop=face'
  ];
  
  const malePhotos = [
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=48&h=48&fit=crop&crop=face',
    'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=48&h=48&fit=crop&crop=face',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=48&h=48&fit=crop&crop=face',
    'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=48&h=48&fit=crop&crop=face'
  ];
  
  const photos = gender === 'female' ? femalePhotos : malePhotos;
  const index = parseInt(id) % photos.length;
  return photos[index];
};

export function UserManagement({ user, onImpersonate }: UserManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [showAddUserDialog, setShowAddUserDialog] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: 'junior-writer' as const,
    organization: '',
    department: '',
    phone: ''
  });

  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      name: 'Sarah Johnson',
      email: 'sarah.johnson@springfieldschools.edu',
      role: 'admin',
      organization: 'Springfield School District',
      department: 'Grant Development',
      phone: '(555) 123-4567',
      joinDate: '2023-01-15',
      lastActive: '2024-12-09T10:30:00Z',
      status: 'active',
      projectsCount: 45,
      grantsWon: 38,
      totalValue: 2500000,
      gender: 'female'
    },
    {
      id: '2',
      name: 'Michael Chen',
      email: 'michael.chen@springfieldschools.edu',
      role: 'senior-writer',
      organization: 'Springfield School District',
      department: 'Grant Writing',
      phone: '(555) 234-5678',
      joinDate: '2023-03-22',
      lastActive: '2024-12-09T09:15:00Z',
      status: 'active',
      projectsCount: 28,
      grantsWon: 24,
      totalValue: 1850000,
      gender: 'male'
    },
    {
      id: '3',
      name: 'Emily Rodriguez',
      email: 'emily.rodriguez@metroschools.org',
      role: 'junior-writer',
      organization: 'Metro School District',
      department: 'Special Programs',
      phone: '(555) 345-6789',
      joinDate: '2023-06-10',
      lastActive: '2024-12-08T16:45:00Z',
      status: 'active',
      projectsCount: 15,
      grantsWon: 12,
      totalValue: 750000,
      gender: 'female'
    },
    {
      id: '4',
      name: 'David Thompson',
      email: 'david.thompson@ruraledu.org',
      role: 'senior-writer',
      organization: 'Rural Education Consortium',
      department: 'Development',
      phone: '(555) 456-7890',
      joinDate: '2023-09-05',
      lastActive: '2024-12-07T14:20:00Z',
      status: 'active',
      projectsCount: 12,
      grantsWon: 9,
      totalValue: 480000,
      gender: 'male'
    },
    {
      id: '5',
      name: 'Jennifer Lee',
      email: 'jennifer.lee@cityschools.edu',
      role: 'admin',
      organization: 'City Schools Network',
      department: 'Strategic Initiatives',
      phone: '(555) 567-8901',
      joinDate: '2024-01-18',
      lastActive: '2024-11-28T11:30:00Z',
      status: 'inactive',
      projectsCount: 8,
      grantsWon: 6,
      totalValue: 320000,
      gender: 'female'
    },
    {
      id: '6',
      name: 'Alex Martinez',
      email: 'alex.martinez@valleyschools.edu',
      role: 'junior-writer',
      organization: 'Valley Public Schools',
      department: 'Grants Office',
      phone: '(555) 678-9012',
      joinDate: '2024-02-10',
      lastActive: '2024-12-09T08:45:00Z',
      status: 'active',
      projectsCount: 7,
      grantsWon: 5,
      totalValue: 280000,
      gender: 'male'
    }
  ]);

  const handleAddUser = () => {
    if (!newUser.name || !newUser.email || !newUser.organization) {
      toast.error('Please fill in all required fields');
      return;
    }

    const user: User = {
      id: Date.now().toString(),
      ...newUser,
      joinDate: new Date().toISOString().split('T')[0],
      lastActive: new Date().toISOString(),
      status: 'active',
      projectsCount: 0,
      grantsWon: 0,
      totalValue: 0,
      gender: 'male' // Default, should be customizable in production
    };

    setUsers(prev => [user, ...prev]);
    setShowAddUserDialog(false);
    setNewUser({
      name: '',
      email: '',
      role: 'junior-writer',
      organization: '',
      department: '',
      phone: ''
    });
    toast.success('User added successfully');
  };

  const handleDeleteUser = (userId: string) => {
    setUsers(prev => prev.filter(user => user.id !== userId));
    toast.success('User removed');
  };

  const handleToggleStatus = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId 
        ? { ...user, status: user.status === 'active' ? 'inactive' : 'active' }
        : user
    ));
    
    const targetUser = users.find(u => u.id === userId);
    const newStatus = targetUser?.status === 'active' ? 'inactive' : 'active';
    toast.success(`User ${newStatus === 'active' ? 'activated' : 'deactivated'} successfully`);
  };

  const handleImpersonate = (targetUser: User) => {
    if (onImpersonate) {
      onImpersonate(targetUser);
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'super-admin': return 'bg-navy text-white';
      case 'admin': return 'bg-emerald text-white';
      case 'senior-writer': return 'bg-indigo text-white';
      case 'junior-writer': return 'bg-amber text-navy';
      default: return 'bg-slate-200 text-slate-700';
    }
  };

  const getRoleDisplayName = (role: string) => {
    switch (role) {
      case 'super-admin': return 'Super Admin';
      case 'admin': return 'Admin';
      case 'senior-writer': return 'Senior Writer';
      case 'junior-writer': return 'Junior Writer';
      default: return role;
    }
  };

  const getStatusColor = (status: string) => {
    return status === 'active' ? 'bg-emerald text-white' : 'bg-slate-200 text-slate-700';
  };

  const formatLastActive = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 48) return 'Yesterday';
    return date.toLocaleDateString();
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.organization.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = filterRole === 'all' || user.role === filterRole;
    
    return matchesSearch && matchesRole;
  });

  const totalUsers = users.length;
  const activeUsers = users.filter(u => u.status === 'active').length;
  const adminUsers = users.filter(u => u.role === 'admin' || u.role === 'super-admin').length;
  const totalValue = users.reduce((sum, u) => sum + u.totalValue, 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">User Management</h1>
          <p className="text-slate-600">Manage users, roles, and access permissions</p>
        </div>
        <Dialog open={showAddUserDialog} onOpenChange={setShowAddUserDialog}>
          <DialogTrigger asChild>
            <Button className="bg-navy hover:bg-indigo gap-2">
              <UserPlus className="h-4 w-4" />
              Add User
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
              <DialogDescription>
                Create a new user account and assign their role and organization.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={newUser.name}
                    onChange={(e) => setNewUser(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="John Doe"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="john.doe@organization.edu"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="role">Role *</Label>
                  <Select value={newUser.role} onValueChange={(value: any) => setNewUser(prev => ({ ...prev, role: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="junior-writer">Junior Writer</SelectItem>
                      <SelectItem value="senior-writer">Senior Writer</SelectItem>
                      <SelectItem value="admin">Administrator</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={newUser.phone}
                    onChange={(e) => setNewUser(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="(555) 123-4567"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="organization">Organization *</Label>
                <Input
                  id="organization"
                  value={newUser.organization}
                  onChange={(e) => setNewUser(prev => ({ ...prev, organization: e.target.value }))}
                  placeholder="School District / Organization Name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Input
                  id="department"
                  value={newUser.department}
                  onChange={(e) => setNewUser(prev => ({ ...prev, department: e.target.value }))}
                  placeholder="Grant Development / Special Programs"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button onClick={handleAddUser} className="flex-1 bg-navy hover:bg-indigo">
                  Create User
                </Button>
                <Button variant="outline" onClick={() => setShowAddUserDialog(false)} className="flex-1">
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Users</p>
                <p className="text-2xl font-bold text-navy">{totalUsers}</p>
              </div>
              <Users className="h-8 w-8 text-indigo" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Active Users</p>
                <p className="text-2xl font-bold text-emerald">{activeUsers}</p>
              </div>
              <UserCheck className="h-8 w-8 text-emerald" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Administrators</p>
                <p className="text-2xl font-bold text-amber">{adminUsers}</p>
              </div>
              <Shield className="h-8 w-8 text-amber" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Secured Value</p>
                <p className="text-2xl font-bold text-emerald">{formatValue(totalValue)}</p>
              </div>
              <Building className="h-8 w-8 text-emerald" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-slate-200">
        <CardContent className="pt-6">
          <div className="flex gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-600" />
              <Input
                placeholder="Search users by name, email, or organization..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-sky-50 border-slate-200"
              />
            </div>
            <Select value={filterRole} onValueChange={setFilterRole}>
              <SelectTrigger className="w-48 bg-sky-50 border-slate-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="super-admin">Super Admins</SelectItem>
                <SelectItem value="admin">Administrators</SelectItem>
                <SelectItem value="senior-writer">Senior Writers</SelectItem>
                <SelectItem value="junior-writer">Junior Writers</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Users List */}
      <div className="grid gap-4">
        {filteredUsers.map((targetUser) => (
          <Card key={targetUser.id} className="border-slate-200 hover:border-indigo transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={getProfilePicture(targetUser.name, targetUser.gender, targetUser.id)} />
                    <AvatarFallback className="bg-navy text-white">
                      {targetUser.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-medium text-navy">{targetUser.name}</h3>
                      <Badge className={`${getRoleColor(targetUser.role)} text-xs`}>
                        {getRoleDisplayName(targetUser.role)}
                      </Badge>
                      <Badge className={`${getStatusColor(targetUser.status)} text-xs`}>
                        {targetUser.status.charAt(0).toUpperCase() + targetUser.status.slice(1)}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-slate-600">
                          <Mail className="h-3 w-3" />
                          <span>{targetUser.email}</span>
                        </div>
                        {targetUser.phone && (
                          <div className="flex items-center gap-2 text-slate-600">
                            <Phone className="h-3 w-3" />
                            <span>{targetUser.phone}</span>
                          </div>
                        )}
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-slate-600">
                          <Building className="h-3 w-3" />
                          <span>{targetUser.organization}</span>
                        </div>
                        {targetUser.department && (
                          <div className="text-slate-600">
                            {targetUser.department}
                          </div>
                        )}
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-slate-600">
                          <Calendar className="h-3 w-3" />
                          <span>Joined {new Date(targetUser.joinDate).toLocaleDateString()}</span>
                        </div>
                        <div className="text-slate-600">
                          Last active: {formatLastActive(targetUser.lastActive)}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="text-right text-sm">
                    <div className="text-slate-600">Performance</div>
                    <div className="space-y-1">
                      <div><span className="font-medium">{targetUser.projectsCount}</span> projects</div>
                      <div><span className="font-medium text-emerald">{targetUser.grantsWon}</span> grants won</div>
                      <div><span className="font-medium text-emerald">{formatValue(targetUser.totalValue)}</span> secured</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    {user.role === 'super-admin' && targetUser.role !== 'super-admin' && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleImpersonate(targetUser)}
                        className="h-8 px-3 text-xs gap-1 bg-indigo/10 text-indigo hover:bg-indigo hover:text-white"
                      >
                        <Eye className="h-3 w-3" />
                        View as User
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleToggleStatus(targetUser.id)}
                      className="h-8 px-3 text-xs"
                    >
                      {targetUser.status === 'active' ? 'Deactivate' : 'Activate'}
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <Edit className="h-3 w-3" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                      onClick={() => handleDeleteUser(targetUser.id)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredUsers.length === 0 && (
          <Card className="border-slate-200">
            <CardContent className="py-12 text-center">
              <Users className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="font-space-grotesk text-lg mb-2">No users found</h3>
              <p className="text-slate-600 mb-4">
                {searchTerm || filterRole !== 'all' 
                  ? "No users match your current filters."
                  : "Get started by adding your first user."
                }
              </p>
              {(!searchTerm && filterRole === 'all') && (
                <Button onClick={() => setShowAddUserDialog(true)} className="gap-2">
                  <UserPlus className="h-4 w-4" />
                  Add First User
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}