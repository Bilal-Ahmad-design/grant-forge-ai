import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../ui/tooltip';
import { ScrollArea } from '../ui/scroll-area';
import { Avatar, AvatarFallback } from '../ui/avatar';
import {
  Bold,
  Italic,
  Underline,
  List,
  ListOrdered,
  Quote,
  AlignLeft,
  AlignCenter,
  AlignRight,
  MessageSquare,
  Users,
  Save,
  Download,
  Share,
  Clock,
  Zap,
  Settings,
  MoreHorizontal,
  Check,
  X,
  Bot,
  Sparkles,
  FileText,
  History,
  Plus,
  Minus
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../../utils/supabase/client';

interface CollaborativeUser {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  color: string;
  isTyping: boolean;
  cursor: number;
}

interface Comment {
  id: string;
  content: string;
  author: {
    id: string;
    name: string;
    avatar?: string;
  };
  timestamp: string;
  resolved: boolean;
  replies: Comment[];
  mentions: string[];
  position: {
    from: number;
    to: number;
  };
}

interface Document {
  id: string;
  title: string;
  content: string;
  grantId?: string;
  section: string;
  status: 'draft' | 'in-review' | 'approved' | 'needs-revision';
  lastModified: string;
  version: number;
  collaborators: CollaborativeUser[];
  comments: Comment[];
  wordCount: number;
  aiSuggestions: number;
}

interface CollaborativeEditorProps {
  document: Document;
  user: any;
  onDocumentUpdate: (document: Document) => void;
  onNavigate: (page: string) => void;
}

export function CollaborativeEditor({ document, user, onDocumentUpdate, onNavigate }: CollaborativeEditorProps) {
  const [content, setContent] = useState(document.content || '');
  const [isSaving, setIsSaving] = useState(false);
  const [collaborators, setCollaborators] = useState<CollaborativeUser[]>(document.collaborators || []);
  const [comments, setComments] = useState<Comment[]>(document.comments || []);
  const [selectedText, setSelectedText] = useState('');
  const [showComments, setShowComments] = useState(true);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [documentStats, setDocumentStats] = useState({
    wordCount: 0,
    characterCount: 0,
    readingTime: 0
  });

  const editorRef = useRef<HTMLDivElement>(null);
  const saveTimeoutRef = useRef<NodeJS.Timeout>();

  // Color palette for collaborators
  const collaboratorColors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
    '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9'
  ];

  useEffect(() => {
    updateDocumentStats(content);
  }, [content]);

  useEffect(() => {
    // Simulate real-time collaboration
    const interval = setInterval(() => {
      const mockCollaborators = [
        {
          id: 'collab1',
          name: 'Sarah Mitchell',
          email: 'sarah@school.edu',
          color: collaboratorColors[0],
          isTyping: Math.random() > 0.8,
          cursor: 0
        },
        {
          id: 'collab2', 
          name: 'Dr. Johnson',
          email: 'johnson@district.edu',
          color: collaboratorColors[1],
          isTyping: Math.random() > 0.9,
          cursor: 0
        }
      ];
      setCollaborators(mockCollaborators);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const updateDocumentStats = (text: string) => {
    const plainText = text.replace(/<[^>]*>/g, ''); // Remove HTML tags
    const wordCount = plainText.trim() ? plainText.trim().split(/\s+/).length : 0;
    const characterCount = plainText.length;
    const readingTime = Math.ceil(wordCount / 200); // Average reading speed

    setDocumentStats({
      wordCount,
      characterCount,
      readingTime
    });
  };

  const debouncedSave = useCallback(() => {
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }

    saveTimeoutRef.current = setTimeout(async () => {
      setIsSaving(true);
      try {
        const updatedDocument = {
          ...document,
          content,
          lastModified: new Date().toISOString(),
          wordCount: documentStats.wordCount,
          version: document.version + 1
        };

        await apiRequest(`/documents/${document.id}`, {
          method: 'PUT',
          body: JSON.stringify(updatedDocument)
        });

        onDocumentUpdate(updatedDocument);
        toast.success('Document saved');
      } catch (error) {
        console.error('Error saving document:', error);
        toast.error('Failed to save document');
      } finally {
        setIsSaving(false);
      }
    }, 1000);
  }, [content, document, documentStats.wordCount, onDocumentUpdate]);

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    debouncedSave();
  };

  const handleAIAssist = async (type: 'improve' | 'expand' | 'summarize' | 'custom') => {
    if (!selectedText && type !== 'custom') {
      toast.error('Please select text to assist with');
      return;
    }

    setAiLoading(true);
    try {
      const prompt = type === 'custom' ? aiPrompt : generateAIPrompt(type, selectedText);
      
      const response = await apiRequest('/ai/writing-assist', {
        method: 'POST',
        body: JSON.stringify({
          prompt,
          context: selectedText || content,
          documentType: 'grant-proposal',
          section: document.section
        })
      });

      if (response.suggestion) {
        // Insert AI suggestion
        const newContent = content + '\n\n' + response.suggestion;
        handleContentChange(newContent);
        
        toast.success('AI suggestion added');
        setShowAIAssistant(false);
        setAiPrompt('');
      }
    } catch (error) {
      console.error('AI assist error:', error);
      toast.error('AI assistance failed');
    } finally {
      setAiLoading(false);
    }
  };

  const generateAIPrompt = (type: string, text: string): string => {
    switch (type) {
      case 'improve':
        return `Improve the following grant proposal text for clarity, impact, and persuasiveness: "${text}"`;
      case 'expand':
        return `Expand on the following grant proposal section with more detail and supporting information: "${text}"`;
      case 'summarize':
        return `Create a concise summary of the following grant proposal content: "${text}"`;
      default:
        return '';
    }
  };

  const addComment = async (commentText: string) => {
    if (!commentText.trim()) return;

    try {
      const newComment: Comment = {
        id: `comment-${Date.now()}`,
        content: commentText,
        author: {
          id: user.id,
          name: user.name,
          avatar: user.avatar
        },
        timestamp: new Date().toISOString(),
        resolved: false,
        replies: [],
        mentions: extractMentions(commentText),
        position: { from: 0, to: 0 }
      };

      const response = await apiRequest(`/documents/${document.id}/comments`, {
        method: 'POST',
        body: JSON.stringify(newComment)
      });

      setComments(prev => [...prev, response.comment || newComment]);
      toast.success('Comment added');
    } catch (error) {
      console.error('Error adding comment:', error);
      toast.error('Failed to add comment');
    }
  };

  const extractMentions = (content: string): string[] => {
    const mentionRegex = /@(\w+)/g;
    const mentions = [];
    let match;
    while ((match = mentionRegex.exec(content)) !== null) {
      mentions.push(match[1]);
    }
    return mentions;
  };

  const formatDocument = async (format: 'pdf' | 'docx' | 'html') => {
    try {
      const response = await apiRequest(`/documents/${document.id}/export`, {
        method: 'POST',
        body: JSON.stringify({ format })
      });

      if (response.downloadUrl) {
        window.open(response.downloadUrl, '_blank');
        toast.success(`Document exported as ${format.toUpperCase()}`);
      }
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export document');
    }
  };

  const applyFormat = (command: string) => {
    document.execCommand(command, false);
    if (editorRef.current) {
      const newContent = editorRef.current.innerHTML;
      handleContentChange(newContent);
    }
  };

  const handleTextSelection = () => {
    const selection = window.getSelection();
    if (selection && selection.toString()) {
      setSelectedText(selection.toString());
    } else {
      setSelectedText('');
    }
  };

  return (
    <div className="flex h-full bg-white">
      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="border-b border-slate-200 bg-white sticky top-0 z-10">
          <div className="flex items-center justify-between p-3">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-space-grotesk font-semibold text-navy">
                {document.title}
              </h2>
              <Badge 
                className={
                  document.status === 'approved' ? 'bg-emerald text-white' :
                  document.status === 'in-review' ? 'bg-amber text-navy' :
                  document.status === 'needs-revision' ? 'bg-red-500 text-white' :
                  'bg-slate-200 text-slate-700'
                }
              >
                {document.status.replace('-', ' ')}
              </Badge>
              {isSaving && (
                <div className="flex items-center gap-1 text-sm text-slate-600">
                  <div className="animate-spin rounded-full h-3 w-3 border-b border-indigo"></div>
                  Saving...
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              {/* Collaborators */}
              <div className="flex items-center gap-1">
                {collaborators.slice(0, 3).map((collaborator) => (
                  <Tooltip key={collaborator.id}>
                    <TooltipTrigger>
                      <Avatar className="h-6 w-6 border-2" style={{ borderColor: collaborator.color }}>
                        <AvatarFallback className="text-xs">
                          {collaborator.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{collaborator.name}</p>
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>

              {/* Action Buttons */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowComments(!showComments)}
                className="gap-2"
              >
                <MessageSquare className="h-4 w-4" />
                Comments ({comments.length})
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAIAssistant(!showAIAssistant)}
                className="gap-2"
              >
                <Bot className="h-4 w-4" />
                AI Assist
              </Button>

              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Download className="h-4 w-4" />
                    Export
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-48">
                  <div className="space-y-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start"
                      onClick={() => formatDocument('pdf')}
                    >
                      Export as PDF
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start"
                      onClick={() => formatDocument('docx')}
                    >
                      Export as Word
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start"
                      onClick={() => formatDocument('html')}
                    >
                      Export as HTML
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Editor Toolbar */}
          <div className="flex items-center gap-1 px-3 pb-3 flex-wrap">
            {/* Text Formatting */}
            <div className="flex items-center gap-1 border-r border-slate-200 pr-2 mr-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('bold')}
              >
                <Bold className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('italic')}
              >
                <Italic className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('underline')}
              >
                <Underline className="h-4 w-4" />
              </Button>
            </div>

            {/* Lists */}
            <div className="flex items-center gap-1 border-r border-slate-200 pr-2 mr-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('insertUnorderedList')}
              >
                <List className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('insertOrderedList')}
              >
                <ListOrdered className="h-4 w-4" />
              </Button>
            </div>

            {/* Alignment */}
            <div className="flex items-center gap-1 border-r border-slate-200 pr-2 mr-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('justifyLeft')}
              >
                <AlignLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('justifyCenter')}
              >
                <AlignCenter className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('justifyRight')}
              >
                <AlignRight className="h-4 w-4" />
              </Button>
            </div>

            {/* Additional Tools */}
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => applyFormat('formatBlock')}
              >
                <Quote className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Editor Content */}
        <div className="flex-1 relative">
          <div 
            ref={editorRef}
            contentEditable
            className="prose prose-lg max-w-none p-6 focus:outline-none min-h-full border-none"
            style={{ minHeight: 'calc(100vh - 200px)' }}
            dangerouslySetInnerHTML={{ __html: content }}
            onInput={(e) => {
              const newContent = e.currentTarget.innerHTML;
              handleContentChange(newContent);
            }}
            onMouseUp={handleTextSelection}
            onKeyUp={handleTextSelection}
            suppressContentEditableWarning={true}
          />
        </div>

        {/* Document Stats */}
        <div className="border-t border-slate-200 bg-slate-50 px-6 py-2">
          <div className="flex items-center justify-between text-sm text-slate-600">
            <div className="flex items-center gap-4">
              <span>{documentStats.wordCount} words</span>
              <span>{documentStats.characterCount} characters</span>
              <span>{documentStats.readingTime} min read</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>Last saved: {new Date(document.lastModified).toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Comments Sidebar */}
      {showComments && (
        <div className="w-80 border-l border-slate-200 bg-slate-50 flex flex-col">
          <div className="p-4 border-b border-slate-200">
            <h3 className="font-space-grotesk font-semibold text-navy">Comments</h3>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-4">
              {/* Add Comment Form */}
              <div className="space-y-2">
                <Label>Add Comment</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Type your comment..."
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        addComment(e.currentTarget.value);
                        e.currentTarget.value = '';
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    onClick={(e) => {
                      const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                      if (input) {
                        addComment(input.value);
                        input.value = '';
                      }
                    }}
                  >
                    Add
                  </Button>
                </div>
              </div>

              <Separator />

              {comments.length === 0 ? (
                <div className="text-center text-slate-500 py-8">
                  <MessageSquare className="h-8 w-8 mx-auto mb-2" />
                  <p>No comments yet</p>
                  <p className="text-sm">Add the first comment above</p>
                </div>
              ) : (
                comments.map((comment) => (
                  <CommentCard 
                    key={comment.id} 
                    comment={comment} 
                    onResolve={(id) => {
                      setComments(prev => prev.map(c => 
                        c.id === id ? { ...c, resolved: true } : c
                      ));
                    }}
                  />
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      )}

      {/* AI Assistant Sidebar */}
      {showAIAssistant && (
        <div className="w-80 border-l border-slate-200 bg-white flex flex-col">
          <div className="p-4 border-b border-slate-200">
            <h3 className="font-space-grotesk font-semibold text-navy flex items-center gap-2">
              <Bot className="h-5 w-5" />
              AI Writing Assistant
            </h3>
          </div>
          <div className="p-4 space-y-4">
            {selectedText && (
              <div className="bg-sky-50 p-3 rounded-lg">
                <p className="text-sm text-slate-600 mb-2">Selected text:</p>
                <p className="text-sm font-medium italic">"{selectedText.substring(0, 100)}..."</p>
              </div>
            )}

            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                onClick={() => handleAIAssist('improve')}
                disabled={!selectedText || aiLoading}
              >
                <Sparkles className="h-4 w-4" />
                Improve Writing
              </Button>
              <Button
                variant="outline" 
                className="w-full justify-start gap-2"
                onClick={() => handleAIAssist('expand')}
                disabled={!selectedText || aiLoading}
              >
                <Plus className="h-4 w-4" />
                Expand Content
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                onClick={() => handleAIAssist('summarize')}
                disabled={!selectedText || aiLoading}
              >
                <Minus className="h-4 w-4" />
                Summarize
              </Button>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label>Custom AI Request</Label>
              <textarea
                className="w-full p-2 border border-slate-200 rounded-md text-sm resize-none"
                rows={3}
                placeholder="Ask AI to help with specific writing tasks..."
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
              />
              <Button
                variant="default"
                className="w-full gap-2"
                onClick={() => handleAIAssist('custom')}
                disabled={!aiPrompt.trim() || aiLoading}
              >
                {aiLoading ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b border-white"></div>
                ) : (
                  <Zap className="h-4 w-4" />
                )}
                Get AI Help
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CommentCard({ comment, onResolve }: { comment: Comment; onResolve: (id: string) => void }) {
  return (
    <Card className={`${comment.resolved ? 'opacity-60' : ''}`}>
      <CardContent className="p-3">
        <div className="flex items-start gap-2">
          <Avatar className="h-6 w-6">
            <AvatarFallback className="text-xs">
              {comment.author.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-sm font-medium">{comment.author.name}</span>
              <span className="text-xs text-slate-500">
                {new Date(comment.timestamp).toLocaleTimeString()}
              </span>
            </div>
            <p className="text-sm text-slate-700">{comment.content}</p>
            
            {comment.mentions.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {comment.mentions.map((mention, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    @{mention}
                  </Badge>
                ))}
              </div>
            )}

            <div className="flex items-center gap-2 mt-2">
              {!comment.resolved && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => onResolve(comment.id)}
                  className="text-xs gap-1"
                >
                  <Check className="h-3 w-3" />
                  Resolve
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}