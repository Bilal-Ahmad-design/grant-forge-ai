import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { ScrollArea } from '../ui/scroll-area';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import {
  FileText,
  Plus,
  Search,
  Filter,
  Download,
  Share2,
  Clock,
  Users,
  MessageSquare,
  Eye,
  Edit,
  Trash2,
  Copy,
  FolderOpen,
  Archive,
  Star,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  XCircle,
  MoreHorizontal,
  Calendar,
  Target,
  Activity,
  Settings,
  Bot,
  Zap,
  History,
  GitBranch,
  BookOpen
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../../utils/supabase/client';
import { CollaborativeEditor } from './CollaborativeEditor';

interface Document {
  id: string;
  title: string;
  content: string;
  grantId?: string;
  grantTitle?: string;
  section: 'executive-summary' | 'needs-statement' | 'project-description' | 'budget' | 'evaluation' | 'sustainability' | 'appendices';
  status: 'draft' | 'in-review' | 'approved' | 'needs-revision';
  lastModified: string;
  createdAt: string;
  author: {
    id: string;
    name: string;
    avatar?: string;
  };
  collaborators: Array<{
    id: string;
    name: string;
    avatar?: string;
    role: 'editor' | 'reviewer' | 'viewer';
    lastActive: string;
  }>;
  version: number;
  wordCount: number;
  comments: number;
  aiSuggestions: number;
  progress: number;
  deadline?: string;
  template?: string;
  tags: string[];
}

interface Template {
  id: string;
  name: string;
  description: string;
  sections: string[];
  category: 'federal' | 'state' | 'foundation' | 'private';
  wordCount: number;
  estimatedTime: string;
}

interface DocumentWorkspaceProps {
  user: any;
  onNavigate: (page: string) => void;
}

export function DocumentWorkspace({ user, onNavigate }: DocumentWorkspaceProps) {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [activeTab, setActiveTab] = useState('my-documents');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterSection, setFilterSection] = useState('all');
  const [loading, setLoading] = useState(true);
  const [showNewDocumentDialog, setShowNewDocumentDialog] = useState(false);
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);

  const [newDocument, setNewDocument] = useState({
    title: '',
    grantId: '',
    section: 'executive-summary',
    template: '',
    collaborators: [] as string[]
  });

  const [teamStats, setTeamStats] = useState({
    totalDocuments: 0,
    inProgress: 0,
    completed: 0,
    overdue: 0,
    activeCollaborators: 0,
    wordsWritten: 0,
    commentsResolved: 0
  });

  useEffect(() => {
    loadDocuments();
    loadTemplates();
    loadTeamStats();
  }, []);

  // Initialize with demo documents if none exist
  useEffect(() => {
    if (documents.length === 0 && !loading) {
      const demoDocuments: Document[] = [
        {
          id: 'demo-doc-1',
          title: 'STEM Education Innovation Grant - Executive Summary',
          content: `<h1>Executive Summary</h1>
<p>Roosevelt Elementary School District respectfully requests $250,000 from the National Science Foundation to implement an innovative STEM education program that will transform how we teach science, technology, engineering, and mathematics to our K-5 students.</p>

<h2>Project Overview</h2>
<p>Our "Young Innovators STEM Academy" will serve 450 students across three elementary schools, providing hands-on learning experiences that prepare students for 21st-century careers while addressing the critical need for STEM literacy in our community.</p>

<h2>Impact Statement</h2>
<p>This program will directly address the achievement gap in STEM subjects, with a focus on engaging underrepresented students in meaningful scientific inquiry and problem-solving activities.</p>`,
          grantId: 'grant1',
          grantTitle: 'STEM Education Innovation Grant',
          section: 'executive-summary',
          status: 'draft',
          lastModified: new Date().toISOString(),
          createdAt: new Date(Date.now() - 86400000).toISOString(),
          author: {
            id: user.id,
            name: user.name,
            avatar: user.avatar
          },
          collaborators: [
            {
              id: 'collab1',
              name: 'Sarah Mitchell',
              avatar: undefined,
              role: 'editor',
              lastActive: new Date().toISOString()
            },
            {
              id: 'collab2',
              name: 'Dr. Johnson',
              avatar: undefined,
              role: 'reviewer',
              lastActive: new Date(Date.now() - 3600000).toISOString()
            }
          ],
          version: 3,
          wordCount: 127,
          comments: 2,
          aiSuggestions: 1,
          progress: 75,
          deadline: '2024-09-15',
          template: 'federal-education-basic',
          tags: ['STEM', 'Elementary', 'Innovation']
        },
        {
          id: 'demo-doc-2',
          title: 'Rural Education Achievement - Needs Statement',
          content: `<h1>Statement of Need</h1>
<p>Jefferson High School serves a rural community where 68% of students qualify for free or reduced lunch, and educational opportunities are limited by geographic isolation and resource constraints.</p>

<h2>Academic Challenges</h2>
<p>Current standardized test scores show our students performing 15-20 points below state averages in mathematics and reading comprehension. This achievement gap has persisted for the past five years despite various intervention attempts.</p>

<h2>Community Context</h2>
<p>Our district covers 120 square miles of rural territory, making it difficult for students to access after-school programs, tutoring services, and enrichment activities available in urban areas.</p>`,
          grantId: 'grant2',
          grantTitle: 'Rural Education Achievement Program',
          section: 'needs-statement',
          status: 'in-review',
          lastModified: new Date(Date.now() - 7200000).toISOString(),
          createdAt: new Date(Date.now() - 172800000).toISOString(),
          author: {
            id: user.id,
            name: user.name,
            avatar: user.avatar
          },
          collaborators: [
            {
              id: 'collab3',
              name: 'Maria Rodriguez',
              avatar: undefined,
              role: 'editor',
              lastActive: new Date(Date.now() - 1800000).toISOString()
            }
          ],
          version: 2,
          wordCount: 156,
          comments: 4,
          aiSuggestions: 3,
          progress: 90,
          deadline: '2024-08-30',
          template: 'federal-education-basic',
          tags: ['Rural', 'Achievement', 'High School']
        },
        {
          id: 'demo-doc-3',
          title: 'Digital Infrastructure Project Description',
          content: `<h1>Project Description</h1>
<p>The Digital Infrastructure Modernization Project will upgrade Lincoln Middle School's technology infrastructure to support 21st-century learning and bridge the digital divide affecting our students.</p>

<h2>Implementation Plan</h2>
<p><strong>Phase 1: Network Infrastructure (Months 1-3)</strong></p>
<ul>
<li>Install fiber optic connections throughout the building</li>
<li>Upgrade wireless access points to support high-speed internet</li>
<li>Implement network security protocols</li>
</ul>

<p><strong>Phase 2: Device Deployment (Months 4-6)</strong></p>
<ul>
<li>Purchase and distribute tablets to all 380 students</li>
<li>Set up mobile device management system</li>
<li>Train faculty on device integration</li>
</ul>`,
          grantId: 'grant3',
          grantTitle: 'Digital Infrastructure Modernization',
          section: 'project-description',
          status: 'approved',
          lastModified: new Date(Date.now() - 14400000).toISOString(),
          createdAt: new Date(Date.now() - 259200000).toISOString(),
          author: {
            id: 'author2',
            name: 'Dr. Amanda Chen',
            avatar: undefined
          },
          collaborators: [
            {
              id: user.id,
              name: user.name,
              avatar: user.avatar,
              role: 'reviewer',
              lastActive: new Date().toISOString()
            }
          ],
          version: 4,
          wordCount: 189,
          comments: 1,
          aiSuggestions: 2,
          progress: 100,
          deadline: '2024-11-15',
          template: 'federal-education-basic',
          tags: ['Technology', 'Infrastructure', 'Middle School']
        }
      ];
      
      setDocuments(demoDocuments);
      setTeamStats({
        totalDocuments: 3,
        inProgress: 2,
        completed: 1,
        overdue: 0,
        activeCollaborators: 4,
        wordsWritten: 472,
        commentsResolved: 5
      });
    }
  }, [documents.length, loading, user]);

  const loadDocuments = async () => {
    try {
      const response = await apiRequest('/documents');
      setDocuments(response.documents || []);
    } catch (error) {
      console.error('Error loading documents:', error);
      toast.error('Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const loadTemplates = async () => {
    try {
      const response = await apiRequest('/documents/templates');
      setTemplates(response.templates || []);
    } catch (error) {
      console.error('Error loading templates:', error);
      // Fallback to demo templates
      setTemplates([
        {
          id: 'federal-education-basic',
          name: 'Federal Education Grant (Basic)',
          description: 'Standard template for federal education grants with all required sections',
          sections: ['executive-summary', 'needs-statement', 'project-description', 'evaluation', 'sustainability'],
          category: 'federal',
          wordCount: 2500,
          estimatedTime: '2-3 weeks'
        },
        {
          id: 'foundation-program',
          name: 'Foundation Program Grant', 
          description: 'Template for foundation grants focusing on program development',
          sections: ['project-description', 'budget'],
          category: 'foundation',
          wordCount: 1500,
          estimatedTime: '1-2 weeks'
        },
        {
          id: 'state-education',
          name: 'State Education Initiative',
          description: 'Template for state-level education improvement grants',
          sections: ['executive-summary', 'needs-statement', 'project-description'],
          category: 'state',
          wordCount: 2000,
          estimatedTime: '2 weeks'
        }
      ]);
    }
  };

  const loadTeamStats = async () => {
    try {
      const response = await apiRequest('/documents/stats');
      setTeamStats(response.stats || teamStats);
    } catch (error) {
      console.error('Error loading team stats:', error);
    }
  };

  const createDocument = async () => {
    try {
      const response = await apiRequest('/documents', {
        method: 'POST',
        body: JSON.stringify({
          ...newDocument,
          authorId: user.id
        })
      });

      setDocuments(prev => [response.document, ...prev]);
      setSelectedDocument(response.document);
      setShowNewDocumentDialog(false);
      setNewDocument({
        title: '',
        grantId: '',
        section: 'executive-summary',
        template: '',
        collaborators: []
      });
      toast.success('Document created successfully');
    } catch (error) {
      console.error('Error creating document:', error);
      toast.error('Failed to create document');
    }
  };

  const duplicateDocument = async (document: Document) => {
    try {
      const response = await apiRequest(`/documents/${document.id}/duplicate`, {
        method: 'POST'
      });

      setDocuments(prev => [response.document, ...prev]);
      toast.success('Document duplicated successfully');
    } catch (error) {
      console.error('Error duplicating document:', error);
      toast.error('Failed to duplicate document');
    }
  };

  const deleteDocument = async (documentId: string) => {
    if (!confirm('Are you sure you want to delete this document?')) return;

    try {
      await apiRequest(`/documents/${documentId}`, {
        method: 'DELETE'
      });

      setDocuments(prev => prev.filter(d => d.id !== documentId));
      if (selectedDocument?.id === documentId) {
        setSelectedDocument(null);
      }
      toast.success('Document deleted successfully');
    } catch (error) {
      console.error('Error deleting document:', error);
      toast.error('Failed to delete document');
    }
  };

  const updateDocumentStatus = async (documentId: string, status: Document['status']) => {
    try {
      const response = await apiRequest(`/documents/${documentId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status })
      });

      setDocuments(prev => prev.map(d => 
        d.id === documentId ? { ...d, status } : d
      ));
      
      if (selectedDocument?.id === documentId) {
        setSelectedDocument(prev => prev ? { ...prev, status } : null);
      }

      toast.success(`Document status updated to ${status.replace('-', ' ')}`);
    } catch (error) {
      console.error('Error updating document status:', error);
      toast.error('Failed to update document status');
    }
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         doc.grantTitle?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || doc.status === filterStatus;
    const matchesSection = filterSection === 'all' || doc.section === filterSection;
    
    return matchesSearch && matchesStatus && matchesSection;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-slate-200 text-slate-700';
      case 'in-review': return 'bg-amber text-navy';
      case 'approved': return 'bg-emerald text-white';
      case 'needs-revision': return 'bg-red-500 text-white';
      default: return 'bg-slate-200 text-slate-700';
    }
  };

  const getSectionTitle = (section: string) => {
    const sectionMap: { [key: string]: string } = {
      'executive-summary': 'Executive Summary',
      'needs-statement': 'Needs Statement',
      'project-description': 'Project Description',
      'budget': 'Budget',
      'evaluation': 'Evaluation',
      'sustainability': 'Sustainability',
      'appendices': 'Appendices'
    };
    return sectionMap[section] || section;
  };

  if (selectedDocument) {
    return (
      <div className="h-full">
        <CollaborativeEditor
          document={selectedDocument}
          user={user}
          onDocumentUpdate={(updatedDoc) => {
            setSelectedDocument(updatedDoc);
            setDocuments(prev => prev.map(d => 
              d.id === updatedDoc.id ? updatedDoc : d
            ));
          }}
          onNavigate={onNavigate}
        />
        <div className="absolute top-4 left-4 z-20">
          <Button
            variant="outline"
            onClick={() => setSelectedDocument(null)}
            className="bg-white shadow-sm"
          >
            ← Back to Documents
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-space-grotesk font-semibold text-navy">
            Document Workspace
          </h1>
          <p className="text-slate-600">
            Collaborate on grant proposals with AI-powered writing assistance
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={() => setShowTemplateDialog(true)}
            className="gap-2"
          >
            <BookOpen className="h-4 w-4" />
            Templates
          </Button>
          <Button
            onClick={() => setShowNewDocumentDialog(true)}
            className="bg-navy hover:bg-navy/90 gap-2"
          >
            <Plus className="h-4 w-4" />
            New Document
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="my-documents" className="gap-2">
            <FileText className="h-4 w-4" />
            My Documents
          </TabsTrigger>
          <TabsTrigger value="team-documents" className="gap-2">
            <Users className="h-4 w-4" />
            Team Documents
          </TabsTrigger>
          <TabsTrigger value="analytics" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="admin" className="gap-2">
            <Settings className="h-4 w-4" />
            Admin View
          </TabsTrigger>
        </TabsList>

        {/* My Documents Tab */}
        <TabsContent value="my-documents" className="space-y-6">
          {/* Search and Filters */}
          <Card className="border-slate-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input
                    placeholder="Search documents..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="in-review">In Review</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="needs-revision">Needs Revision</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterSection} onValueChange={setFilterSection}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Section" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sections</SelectItem>
                    <SelectItem value="executive-summary">Executive Summary</SelectItem>
                    <SelectItem value="needs-statement">Needs Statement</SelectItem>
                    <SelectItem value="project-description">Project Description</SelectItem>
                    <SelectItem value="budget">Budget</SelectItem>
                    <SelectItem value="evaluation">Evaluation</SelectItem>
                    <SelectItem value="sustainability">Sustainability</SelectItem>
                    <SelectItem value="appendices">Appendices</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Documents Grid */}
          {loading ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="border-slate-200">
                  <CardContent className="p-4">
                    <div className="animate-pulse space-y-3">
                      <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                      <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                      <div className="h-3 bg-slate-200 rounded w-full"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredDocuments.length === 0 ? (
            <Card className="border-slate-200">
              <CardContent className="p-12 text-center">
                <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-navy mb-2">
                  No documents found
                </h3>
                <p className="text-slate-600 mb-4">
                  {searchQuery || filterStatus !== 'all' || filterSection !== 'all'
                    ? 'Try adjusting your search criteria'
                    : 'Create your first document to get started'
                  }
                </p>
                <Button onClick={() => setShowNewDocumentDialog(true)}>
                  Create Document
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredDocuments.map((document) => (
                <DocumentCard
                  key={document.id}
                  document={document}
                  onOpen={setSelectedDocument}
                  onDuplicate={duplicateDocument}
                  onDelete={deleteDocument}
                  onStatusUpdate={updateDocumentStatus}
                  currentUserId={user.id}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Team Documents Tab */}
        <TabsContent value="team-documents" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <Card className="border-slate-200">
                <CardHeader>
                  <CardTitle className="text-lg font-space-grotesk text-navy">
                    Team Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {documents.slice(0, 5).map((doc) => (
                      <div key={doc.id} className="flex items-center gap-3 p-3 bg-sky-50 rounded-lg">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>{doc.author.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{doc.author.name}</p>
                          <p className="text-xs text-slate-600">
                            Updated "{doc.title}" • {new Date(doc.lastModified).toLocaleTimeString()}
                          </p>
                        </div>
                        <Badge className={getStatusColor(doc.status)}>
                          {doc.status.replace('-', ' ')}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Card className="border-slate-200">
                <CardHeader>
                  <CardTitle className="text-lg font-space-grotesk text-navy">
                    Team Stats
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-navy">{teamStats.totalDocuments}</div>
                      <div className="text-xs text-slate-600">Total Documents</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-amber">{teamStats.inProgress}</div>
                      <div className="text-xs text-slate-600">In Progress</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-emerald">{teamStats.completed}</div>
                      <div className="text-xs text-slate-600">Completed</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-500">{teamStats.overdue}</div>
                      <div className="text-xs text-slate-600">Overdue</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-slate-200">
                <CardHeader>
                  <CardTitle className="text-lg font-space-grotesk text-navy">
                    Active Collaborators
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex -space-x-2">
                    {[...Array(Math.min(teamStats.activeCollaborators, 5))].map((_, i) => (
                      <Avatar key={i} className="h-8 w-8 border-2 border-white">
                        <AvatarFallback>U{i + 1}</AvatarFallback>
                      </Avatar>
                    ))}
                    {teamStats.activeCollaborators > 5 && (
                      <div className="h-8 w-8 rounded-full bg-slate-200 border-2 border-white flex items-center justify-center text-xs">
                        +{teamStats.activeCollaborators - 5}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-8 w-8 text-indigo" />
                  <div>
                    <div className="text-2xl font-bold text-navy">{teamStats.wordsWritten.toLocaleString()}</div>
                    <div className="text-sm text-slate-600">Words Written</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-8 w-8 text-emerald" />
                  <div>
                    <div className="text-2xl font-bold text-navy">{teamStats.commentsResolved}</div>
                    <div className="text-sm text-slate-600">Comments Resolved</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Bot className="h-8 w-8 text-amber" />
                  <div>
                    <div className="text-2xl font-bold text-navy">156</div>
                    <div className="text-sm text-slate-600">AI Suggestions</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-8 w-8 text-slate-500" />
                  <div>
                    <div className="text-2xl font-bold text-navy">24.5h</div>
                    <div className="text-sm text-slate-600">Time Saved</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="text-lg font-space-grotesk text-navy">
                Writing Progress Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <TrendingUp className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-navy mb-2">
                  Analytics Dashboard Coming Soon
                </h3>
                <p className="text-slate-600">
                  View detailed insights about team productivity, writing patterns, and collaboration metrics.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Admin View Tab */}
        <TabsContent value="admin" className="space-y-6">
          {user.role === 'admin' || user.role === 'super-admin' ? (
            <AdminWritingDashboard 
              documents={documents} 
              teamStats={teamStats} 
              onStatusUpdate={updateDocumentStatus}
            />
          ) : (
            <Card className="border-slate-200">
              <CardContent className="p-12 text-center">
                <AlertCircle className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-navy mb-2">
                  Admin Access Required
                </h3>
                <p className="text-slate-600">
                  You need administrator privileges to view the admin dashboard.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* New Document Dialog */}
      <Dialog open={showNewDocumentDialog} onOpenChange={setShowNewDocumentDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-space-grotesk text-navy">
              Create New Document
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Document Title</Label>
              <Input
                id="title"
                placeholder="Enter document title..."
                value={newDocument.title}
                onChange={(e) => setNewDocument(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="section">Section</Label>
                <Select value={newDocument.section} onValueChange={(value) => 
                  setNewDocument(prev => ({ ...prev, section: value }))
                }>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="executive-summary">Executive Summary</SelectItem>
                    <SelectItem value="needs-statement">Needs Statement</SelectItem>
                    <SelectItem value="project-description">Project Description</SelectItem>
                    <SelectItem value="budget">Budget</SelectItem>
                    <SelectItem value="evaluation">Evaluation</SelectItem>
                    <SelectItem value="sustainability">Sustainability</SelectItem>
                    <SelectItem value="appendices">Appendices</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="template">Template (Optional)</Label>
                <Select value={newDocument.template} onValueChange={(value) => 
                  setNewDocument(prev => ({ ...prev, template: value }))
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose template" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">No Template</SelectItem>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setShowNewDocumentDialog(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={createDocument}
                disabled={!newDocument.title.trim()}
                className="flex-1 bg-navy hover:bg-navy/90"
              >
                Create Document
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Templates Dialog */}
      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="font-space-grotesk text-navy">
              Document Templates
            </DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 md:grid-cols-2">
            {templates.map((template) => (
              <Card key={template.id} className="border-slate-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">{template.name}</CardTitle>
                  <Badge variant="outline">{template.category}</Badge>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-slate-600">{template.description}</p>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{template.wordCount.toLocaleString()} words</span>
                    <span>{template.estimatedTime}</span>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setNewDocument(prev => ({ ...prev, template: template.id }));
                      setShowTemplateDialog(false);
                      setShowNewDocumentDialog(true);
                    }}
                  >
                    Use Template
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DocumentCard({
  document,
  onOpen,
  onDuplicate,
  onDelete,
  onStatusUpdate,
  currentUserId
}: {
  document: Document;
  onOpen: (doc: Document) => void;
  onDuplicate: (doc: Document) => void;
  onDelete: (id: string) => void;
  onStatusUpdate: (id: string, status: Document['status']) => void;
  currentUserId: string;
}) {
  const isAuthor = document.author.id === currentUserId;
  const canEdit = isAuthor || document.collaborators.some(c => c.id === currentUserId && c.role === 'editor');

  return (
    <Card className="border-slate-200 hover:border-indigo transition-colors cursor-pointer group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1" onClick={() => onOpen(document)}>
            <h3 className="font-semibold text-navy line-clamp-2 mb-1">
              {document.title}
            </h3>
            {document.grantTitle && (
              <p className="text-sm text-slate-600 mb-2">
                Grant: {document.grantTitle}
              </p>
            )}
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className="text-xs">
                {document.section.replace('-', ' ')}
              </Badge>
              <Badge className={`text-xs ${
                document.status === 'approved' ? 'bg-emerald text-white' :
                document.status === 'in-review' ? 'bg-amber text-navy' :
                document.status === 'needs-revision' ? 'bg-red-500 text-white' :
                'bg-slate-200 text-slate-700'
              }`}>
                {document.status.replace('-', ' ')}
              </Badge>
            </div>
          </div>

          <div className="opacity-0 group-hover:opacity-100 transition-opacity">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48" align="end">
                <div className="space-y-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start gap-2"
                    onClick={() => onOpen(document)}
                  >
                    <Edit className="h-4 w-4" />
                    Open
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start gap-2"
                    onClick={() => onDuplicate(document)}
                  >
                    <Copy className="h-4 w-4" />
                    Duplicate
                  </Button>
                  {isAuthor && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start gap-2 text-red-600 hover:text-red-700"
                      onClick={() => onDelete(document.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0" onClick={() => onOpen(document)}>
        <div className="space-y-3">
          {document.progress > 0 && (
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-slate-600">Progress</span>
                <span className="font-medium">{document.progress}%</span>
              </div>
              <Progress value={document.progress} className="h-2" />
            </div>
          )}

          <div className="flex items-center justify-between text-sm text-slate-600">
            <div className="flex items-center gap-3">
              <span>{document.wordCount} words</span>
              <span>{document.comments} comments</span>
            </div>
            <span>{new Date(document.lastModified).toLocaleDateString()}</span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <Avatar className="h-5 w-5">
                <AvatarFallback className="text-xs">
                  {document.author.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <span className="text-xs text-slate-600">{document.author.name}</span>
            </div>

            <div className="flex -space-x-1">
              {document.collaborators.slice(0, 3).map((collaborator) => (
                <Avatar key={collaborator.id} className="h-5 w-5 border border-white">
                  <AvatarFallback className="text-xs">
                    {collaborator.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
              ))}
              {document.collaborators.length > 3 && (
                <div className="h-5 w-5 rounded-full bg-slate-200 border border-white flex items-center justify-center text-xs">
                  +{document.collaborators.length - 3}
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function AdminWritingDashboard({
  documents,
  teamStats,
  onStatusUpdate
}: {
  documents: Document[];
  teamStats: any;
  onStatusUpdate: (id: string, status: Document['status']) => void;
}) {
  const pendingReview = documents.filter(d => d.status === 'in-review');
  const needsRevision = documents.filter(d => d.status === 'needs-revision');

  return (
    <div className="space-y-6">
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-space-grotesk text-navy">
            Admin Writing Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <h3 className="font-medium text-navy mb-3">Documents Pending Review</h3>
              <div className="space-y-2">
                {pendingReview.length === 0 ? (
                  <p className="text-sm text-slate-600">No documents pending review</p>
                ) : (
                  pendingReview.map((doc) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 bg-amber/10 rounded-lg">
                      <div>
                        <p className="font-medium text-sm">{doc.title}</p>
                        <p className="text-xs text-slate-600">by {doc.author.name}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onStatusUpdate(doc.id, 'approved')}
                          className="gap-1"
                        >
                          <CheckCircle className="h-3 w-3" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onStatusUpdate(doc.id, 'needs-revision')}
                          className="gap-1"
                        >
                          <XCircle className="h-3 w-3" />
                          Revise
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div>
              <h3 className="font-medium text-navy mb-3">Real-time Activity</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-emerald rounded-full animate-pulse"></div>
                  <span>3 writers currently active</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-amber rounded-full"></div>
                  <span>2 documents updated in last hour</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-indigo rounded-full"></div>
                  <span>15 AI suggestions applied today</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}