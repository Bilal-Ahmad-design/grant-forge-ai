export const kpis = [
  {
    title: 'Total Funding Secured',
    value: '$2.4M',
    change: '+18%',
    trend: 'up' as const,
    period: 'vs last quarter',
    icon: 'DollarSign',
    color: 'text-emerald'
  },
  {
    title: 'Active Grant Writers',
    value: '12',
    change: '+2',
    trend: 'up' as const,
    period: 'this month',
    icon: 'Users',
    color: 'text-indigo'
  },
  {
    title: 'Win Rate',
    value: '68%',
    change: '+5%',
    trend: 'up' as const,
    period: 'vs last quarter',
    icon: 'Award',
    color: 'text-emerald'
  },
  {
    title: 'Avg. Proposal Time',
    value: '14.2 days',
    change: '-2.1 days',
    trend: 'up' as const,
    period: 'improvement',
    icon: 'Clock',
    color: 'text-amber'
  },
  {
    title: 'Pipeline Value',
    value: '$3.8M',
    change: '+12%',
    trend: 'up' as const,
    period: 'this quarter',
    icon: 'Target',
    color: 'text-navy'
  },
  {
    title: 'Billable Hours',
    value: '1,247',
    change: '-8%',
    trend: 'down' as const,
    period: 'this month',
    icon: 'Clock',
    color: 'text-slate-600'
  }
];

export const teamPerformance = [
  {
    name: 'Sarah Chen',
    role: 'Senior Grant Writer',
    grants: 8,
    value: '$890K',
    winRate: 75,
    avgTime: '12.5 days',
    efficiency: 92
  },
  {
    name: 'Michael Torres',
    role: 'Grant Writer',
    grants: 6,
    value: '$640K',
    winRate: 67,
    avgTime: '15.2 days',
    efficiency: 85
  },
  {
    name: 'Lisa Park',
    role: 'Senior Grant Writer',
    grants: 7,
    value: '$780K',
    winRate: 71,
    avgTime: '13.8 days',
    efficiency: 88
  },
  {
    name: 'David Kim',
    role: 'Grant Writer',
    grants: 5,
    value: '$520K',
    winRate: 60,
    avgTime: '16.9 days',
    efficiency: 78
  }
];

export const clientMetrics = [
  {
    name: 'Springfield School District',
    grants: 12,
    value: '$1.2M',
    status: 'Active',
    satisfaction: 95,
    color: 'bg-emerald'
  },
  {
    name: 'Riverside County Schools',
    grants: 8,
    value: '$780K',
    status: 'Active',
    satisfaction: 88,
    color: 'bg-indigo'
  },
  {
    name: 'Lincoln Educational Services',
    grants: 6,
    value: '$450K',
    status: 'On Hold',
    satisfaction: 82,
    color: 'bg-amber'
  },
  {
    name: 'Metro High School',
    grants: 4,
    value: '$320K',
    status: 'Active',
    satisfaction: 91,
    color: 'bg-purple-500'
  }
];

export const alerts = [
  {
    type: 'warning' as const,
    title: 'Deadline Approaching',
    message: 'NSF STEM Grant deadline in 3 days - needs final review',
    time: '2 hours ago'
  },
  {
    type: 'info' as const,
    title: 'New Opportunity',
    message: '3 new grants match Springfield District criteria',
    time: '4 hours ago'
  },
  {
    type: 'success' as const,
    title: 'Grant Awarded',
    message: 'Rural Education Achievement Grant - $75,000 secured',
    time: '1 day ago'
  },
  {
    type: 'warning' as const,
    title: 'Budget Overrun',
    message: 'Lincoln Project exceeded estimated hours by 15%',
    time: '2 days ago'
  }
];