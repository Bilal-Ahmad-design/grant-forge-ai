import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { 
  Play, 
  Pause, 
  Square, 
  Clock, 
  Calendar, 
  BarChart3,
  Plus,
  Edit,
  Trash2,
  Download
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface TimeEntry {
  id: string;
  project: string;
  task: string;
  description: string;
  startTime: string;
  endTime: string;
  duration: number; // in minutes
  date: string;
  billable: boolean;
  rate?: number;
}

interface Project {
  id: string;
  name: string;
  client: string;
  rate: number;
  color: string;
}

export function TimeTracker() {
  const [isRunning, setIsRunning] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [currentProject, setCurrentProject] = useState('');
  const [currentTask, setCurrentTask] = useState('');
  const [currentDescription, setCurrentDescription] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const projects: Project[] = [
    { id: '1', name: 'NSF STEM Grant', client: 'Springfield Elementary', rate: 125, color: 'bg-indigo' },
    { id: '2', name: 'Rural Education Grant', client: 'Riverside School District', rate: 100, color: 'bg-emerald' },
    { id: '3', name: 'Arts Integration Grant', client: 'Lincoln Middle School', rate: 110, color: 'bg-amber' },
    { id: '4', name: 'Technology Fund', client: 'Metro High School', rate: 135, color: 'bg-purple-500' },
  ];

  const taskTypes = [
    'Research & Discovery',
    'Application Writing',
    'Budget Development',
    'Review & Editing',
    'Client Meetings',
    'Administrative',
    'Proposal Submission'
  ];

  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([
    {
      id: '1',
      project: 'NSF STEM Grant',
      task: 'Application Writing',
      description: 'Writing narrative for educational impact section',
      startTime: '09:00',
      endTime: '11:30',
      duration: 150,
      date: '2024-08-02',
      billable: true,
      rate: 125
    },
    {
      id: '2',
      project: 'Rural Education Grant',
      task: 'Research & Discovery',
      description: 'Researching eligible programs and requirements',
      startTime: '13:00',
      endTime: '14:45',
      duration: 105,
      date: '2024-08-02',
      billable: true,
      rate: 100
    },
    {
      id: '3',
      project: 'Arts Integration Grant',
      task: 'Client Meetings',
      description: 'Initial consultation with department heads',
      startTime: '15:30',
      endTime: '16:30',
      duration: 60,
      date: '2024-08-01',
      billable: true,
      rate: 110
    }
  ]);

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && startTime) {
      interval = setInterval(() => {
        setElapsedTime(Date.now() - startTime.getTime());
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, startTime]);

  const formatTime = (milliseconds: number) => {
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    return `${hours.toString().padStart(2, '0')}:${(minutes % 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const handleStart = () => {
    if (!currentProject || !currentTask) {
      toast.error('Please select a project and task before starting the timer');
      return;
    }
    setStartTime(new Date());
    setIsRunning(true);
    setElapsedTime(0);
    toast.success('Timer started');
  };

  const handlePause = () => {
    setIsRunning(false);
    toast.success('Timer paused');
  };

  const handleStop = () => {
    if (!startTime) return;

    const endTime = new Date();
    const duration = Math.floor((endTime.getTime() - startTime.getTime()) / 60000); // Convert to minutes
    const project = projects.find(p => p.id === currentProject);

    const newEntry: TimeEntry = {
      id: Date.now().toString(),
      project: project?.name || '',
      task: currentTask,
      description: currentDescription,
      startTime: startTime.toTimeString().slice(0, 5),
      endTime: endTime.toTimeString().slice(0, 5),
      duration,
      date: new Date().toISOString().split('T')[0],
      billable: true,
      rate: project?.rate || 0
    };

    setTimeEntries(prev => [newEntry, ...prev]);
    setIsRunning(false);
    setStartTime(null);
    setElapsedTime(0);
    setCurrentDescription('');
    toast.success('Time entry saved');
  };

  const handleDeleteEntry = (id: string) => {
    setTimeEntries(prev => prev.filter(entry => entry.id !== id));
    toast.success('Time entry deleted');
  };

  const getProjectColor = (projectName: string) => {
    const project = projects.find(p => p.name === projectName);
    return project?.color || 'bg-slate-500';
  };

  const getTodayStats = () => {
    const today = new Date().toISOString().split('T')[0];
    const todayEntries = timeEntries.filter(entry => entry.date === today);
    const totalMinutes = todayEntries.reduce((sum, entry) => sum + entry.duration, 0);
    const billableMinutes = todayEntries.filter(entry => entry.billable).reduce((sum, entry) => sum + entry.duration, 0);
    const totalEarnings = todayEntries.filter(entry => entry.billable).reduce((sum, entry) => sum + (entry.duration / 60) * (entry.rate || 0), 0);

    return {
      totalTime: formatDuration(totalMinutes),
      billableTime: formatDuration(billableMinutes),
      earnings: totalEarnings,
      entries: todayEntries.length
    };
  };

  const getWeekStats = () => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const weekEntries = timeEntries.filter(entry => new Date(entry.date) >= oneWeekAgo);
    const totalMinutes = weekEntries.reduce((sum, entry) => sum + entry.duration, 0);
    const totalEarnings = weekEntries.filter(entry => entry.billable).reduce((sum, entry) => sum + (entry.duration / 60) * (entry.rate || 0), 0);

    return {
      totalTime: formatDuration(totalMinutes),
      earnings: totalEarnings,
      entries: weekEntries.length
    };
  };

  const todayStats = getTodayStats();
  const weekStats = getWeekStats();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">Time Tracking</h1>
          <p className="text-slate-600">Track billable hours and manage your time efficiently</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export Timesheet
          </Button>
          <Button variant="outline" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            View Reports
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Today's Time</p>
                <p className="text-xl font-bold text-navy">{todayStats.totalTime}</p>
              </div>
              <Clock className="h-8 w-8 text-indigo" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Billable Today</p>
                <p className="text-xl font-bold text-emerald">{todayStats.billableTime}</p>
              </div>
              <Calendar className="h-8 w-8 text-emerald" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Today's Earnings</p>
                <p className="text-xl font-bold text-emerald">${todayStats.earnings.toFixed(0)}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-amber" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Week Total</p>
                <p className="text-xl font-bold text-navy">${weekStats.earnings.toFixed(0)}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-navy" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timer Section */}
        <div className="lg:col-span-1">
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="font-space-grotesk">Current Timer</CardTitle>
              <CardDescription>Track time for your current task</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Timer Display */}
              <div className="text-center py-6">
                <div className="text-4xl font-bold font-mono text-navy mb-2">
                  {formatTime(elapsedTime)}
                </div>
                <div className="text-sm text-slate-600">
                  {isRunning ? 'Timer running' : 'Timer stopped'}
                </div>
              </div>

              {/* Timer Controls */}
              <div className="flex justify-center gap-2">
                {!isRunning ? (
                  <Button 
                    onClick={handleStart}
                    className="bg-emerald hover:bg-emerald/90 gap-2"
                  >
                    <Play className="h-4 w-4" />
                    Start
                  </Button>
                ) : (
                  <Button 
                    onClick={handlePause}
                    variant="outline"
                    className="gap-2"
                  >
                    <Pause className="h-4 w-4" />
                    Pause
                  </Button>
                )}
                
                <Button 
                  onClick={handleStop}
                  variant="outline"
                  className="gap-2"
                  disabled={!isRunning && elapsedTime === 0}
                >
                  <Square className="h-4 w-4" />
                  Stop
                </Button>
              </div>

              {/* Project Selection */}
              <div className="space-y-3">
                <div>
                  <Label htmlFor="project">Project *</Label>
                  <Select value={currentProject} onValueChange={setCurrentProject}>
                    <SelectTrigger className="bg-sky-50 border-slate-200">
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${project.color}`} />
                            <span>{project.name}</span>
                            <span className="text-xs text-slate-600">• ${project.rate}/hr</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="task">Task *</Label>
                  <Select value={currentTask} onValueChange={setCurrentTask}>
                    <SelectTrigger className="bg-sky-50 border-slate-200">
                      <SelectValue placeholder="Select task type" />
                    </SelectTrigger>
                    <SelectContent>
                      {taskTypes.map((task) => (
                        <SelectItem key={task} value={task}>{task}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="What are you working on?"
                    value={currentDescription}
                    onChange={(e) => setCurrentDescription(e.target.value)}
                    className="bg-sky-50 border-slate-200"
                    rows={2}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Time Entries */}
        <div className="lg:col-span-2">
          <Card className="border-slate-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="font-space-grotesk">Time Entries</CardTitle>
                  <CardDescription>Recent time tracking entries</CardDescription>
                </div>
                <Button variant="outline" size="sm" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Manual Entry
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {timeEntries.slice(0, 8).map((entry) => (
                  <div 
                    key={entry.id} 
                    className="flex items-center justify-between p-4 border border-slate-200 rounded-lg hover:bg-sky-50 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <div className={`w-3 h-3 rounded-full ${getProjectColor(entry.project)}`} />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-navy">{entry.project}</h4>
                          <Badge className="bg-slate-200 text-slate-700 text-xs">
                            {entry.task}
                          </Badge>
                          {entry.billable && (
                            <Badge className="bg-emerald text-white text-xs">
                              Billable
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-slate-600 line-clamp-1">{entry.description}</p>
                        <div className="flex items-center gap-4 text-xs text-slate-500 mt-1">
                          <span>{entry.date}</span>
                          <span>{entry.startTime} - {entry.endTime}</span>
                          {entry.billable && entry.rate && (
                            <span>${((entry.duration / 60) * entry.rate).toFixed(0)} earned</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="font-medium text-navy">{formatDuration(entry.duration)}</div>
                        {entry.rate && (
                          <div className="text-xs text-slate-600">${entry.rate}/hr</div>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                          onClick={() => handleDeleteEntry(entry.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}

                {timeEntries.length === 0 && (
                  <div className="text-center py-8 text-slate-600">
                    <Clock className="h-12 w-12 mx-auto mb-4 text-slate-400" />
                    <p>No time entries yet</p>
                    <p className="text-sm">Start the timer to begin tracking your time</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}