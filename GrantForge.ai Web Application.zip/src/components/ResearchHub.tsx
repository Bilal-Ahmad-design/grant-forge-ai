import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Search, 
  Filter, 
  BookmarkPlus, 
  ExternalLink, 
  Calendar, 
  DollarSign,
  MapPin,
  GraduationCap,
  Target,
  Clock,
  Bell,
  Users,
  Building,
  Plus,
  Eye,
  Bot,
  Loader2,
  Info,
  CheckCircle,
  AlertTriangle,
  PenTool,
  FileText,
  ArrowRight,
  Star,
  Settings,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

interface ResearchHubProps {
  user: User;
  onNavigate?: (page: string) => void;
}

interface Grant {
  id: string;
  title: string;
  funder: string;
  amount: string;
  deadline: string;
  description: string;
  category: string;
  eligibility: string[];
  matchRequired?: boolean;
  difficulty?: 'Easy' | 'Medium' | 'Hard';
  tags: string[];
  location?: string;
  isNew?: boolean;
  saved?: boolean;
  clientMatch?: string;
  priority?: 'low' | 'medium' | 'high';
  opportunityNumber?: string;
  cfda?: string;
  source?: string;
  lastUpdated?: string;
  link?: string;
}

interface Client {
  id: string;
  name: string;
  type: string;
  location: string;
  categories: string[];
  maxAmount: number;
  keywords: string[];
  eligibilityTypes: string[];
  matchedGrants: string[];
}

// Utility function to format amounts
const formatAmount = (amount: string): string => {
  if (!amount) return 'N/A';
  if (amount.includes('-')) {
    const parts = amount.split('-');
    const min = formatSingleAmount(parts[0]?.trim() || '');
    const max = formatSingleAmount(parts[1]?.trim() || '');
    return `${min} - ${max}`;
  }
  return formatSingleAmount(amount);
};

const formatSingleAmount = (amount: string): string => {
  if (!amount) return 'N/A';
  const match = amount.match(/\$?([0-9,]+)/);
  if (!match) return amount;
  
  const num = parseInt(match[1].replace(/,/g, ''));
  if (num >= 1000000) {
    return `$${(num / 1000000).toFixed(num % 1000000 === 0 ? 0 : 1)}M`;
  } else if (num >= 1000) {
    return `$${(num / 1000).toFixed(num % 1000 === 0 ? 0 : 0)}K`;
  }
  return amount;
};

export function ResearchHub({ user, onNavigate }: ResearchHubProps) {
  const [activeTab, setActiveTab] = useState('discover');
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedClient, setSelectedClient] = useState('all');
  const [loading, setLoading] = useState(false);
  const [aiResearching, setAiResearching] = useState<string | null>(null);
  const [dataSource, setDataSource] = useState<'grants.gov' | 'enhanced_mock' | 'cache'>('enhanced_mock');
  const [lastUpdated, setLastUpdated] = useState<string>('');
  
  const [filters, setFilters] = useState({
    category: 'all',
    agency: 'all',
    amountMin: '',
    amountMax: '',
    deadline: '',
    difficulty: 'all',
    location: 'all',
    matchRequired: false,
    eligibility: [] as string[]
  });

  // State for grants data
  const [grants, setGrants] = useState<Grant[]>([]);
  const [totalGrants, setTotalGrants] = useState(0);
  const [availableFilters, setAvailableFilters] = useState({
    categories: [] as string[],
    agencies: [] as string[],
    eligibilityTypes: [] as string[]
  });

  const [clients, setClients] = useState<Client[]>([
    {
      id: '1',
      name: 'Springfield Elementary',
      type: 'Public K-5 School',
      location: 'Springfield, IL',
      categories: ['STEM Education', 'Technology'],
      maxAmount: 300000,
      keywords: ['elementary', 'K-5', 'hands-on learning'],
      eligibilityTypes: ['Public Schools', 'Title I Schools'],
      matchedGrants: ['1', '4']
    },
    {
      id: '2',
      name: 'Metro High School',
      type: 'Public 9-12 School',
      location: 'Metro City, CA',
      categories: ['Special Education', 'Technology', 'Professional Development'],
      maxAmount: 500000,
      keywords: ['high school', 'career readiness', 'college prep'],
      eligibilityTypes: ['Public Schools'],
      matchedGrants: ['3', '5']
    },
    {
      id: '3',
      name: 'Roosevelt Elementary School',
      type: 'Public K-5 School',
      location: 'Metro City, CA',
      categories: ['STEM Education', 'Innovation'],
      maxAmount: 250000,
      keywords: ['STEM', 'innovation', 'elementary'],
      eligibilityTypes: ['Public Schools', 'Title I Schools'],
      matchedGrants: ['1']
    }
  ]);

  // Load grants from Grants.gov API
  const loadGrants = async (searchParams: Record<string, string> = {}) => {
    try {
      setLoading(true);
      
      const params = new URLSearchParams();
      if (searchTerm) params.append('keyword', searchTerm);
      if (filters.category && filters.category !== 'all') params.append('category', filters.category);
      if (filters.agency && filters.agency !== 'all') params.append('agency', filters.agency);
      if (filters.eligibility && filters.eligibility.length > 0) {
        params.append('eligibility', filters.eligibility.join(','));
      }
      params.append('limit', '50');

      // Add custom search params
      Object.entries(searchParams).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });

      const response = await apiRequest(`/grants/search?${params.toString()}`);
      
      if (response.grants) {
        // Transform grants to ensure they have the right structure
        const transformedGrants = response.grants.map((grant: any) => ({
          ...grant,
          eligibility: Array.isArray(grant.eligibility) ? grant.eligibility : 
                      typeof grant.eligibility === 'string' ? [grant.eligibility] : [],
          tags: Array.isArray(grant.tags) ? grant.tags : [],
          difficulty: grant.difficulty || 'Medium',
          location: grant.location || 'National',
          isNew: grant.isNew || false,
          saved: grant.saved || false
        }));

        setGrants(transformedGrants);
        setTotalGrants(response.total || transformedGrants.length);
        setDataSource(response.source || 'enhanced_mock');
        setLastUpdated(new Date().toISOString());
        
        toast.success(`Found ${transformedGrants.length} grant opportunities`);
      } else {
        throw new Error('Invalid response format');
      }
    } catch (error: any) {
      console.error('Failed to load grants:', error);
      toast.error('Failed to load grant opportunities');
      setGrants([]);
      setTotalGrants(0);
    } finally {
      setLoading(false);
    }
  };

  // Load available filter options
  const loadFilters = async () => {
    try {
      const response = await apiRequest('/grants/filters');
      if (response.filters) {
        setAvailableFilters(response.filters);
      }
    } catch (error) {
      console.error('Failed to load filter options:', error);
      // Use fallback filter options
      setAvailableFilters({
        categories: [
          'STEM Education',
          'Arts & Humanities', 
          'Special Education',
          'Technology',
          'Infrastructure',
          'Professional Development',
          'Student Support',
          'Rural Education',
          'Innovation',
          'Community Engagement'
        ],
        agencies: [
          'Department of Education',
          'National Science Foundation',
          'Department of Agriculture',
          'Department of Health and Human Services',
          'Environmental Protection Agency'
        ],
        eligibilityTypes: [
          'Public Schools',
          'Private Schools', 
          'Charter Schools',
          'Nonprofits',
          'Higher Education',
          'Title I Schools',
          'Rural Districts'
        ]
      });
    }
  };

  // Load data on component mount
  useEffect(() => {
    loadFilters();
    loadGrants();
    toast.success('AI Research Hub loaded successfully');
  }, []);

  // Trigger search when filters change
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchTerm || filters.category !== 'all' || filters.agency !== 'all' || filters.eligibility.length > 0) {
        loadGrants();
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchTerm, filters.category, filters.agency, filters.eligibility]);

  const handleRefresh = async () => {
    await loadGrants();
  };

  const handleAIResearch = async (grantId: string) => {
    if (!grantId) return;
    
    const grant = grants.find(g => g.id === grantId);
    if (!grant) return;

    try {
      setAiResearching(grantId);
      
      // Simulate AI research process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast.success('AI research completed! Navigate to Grant Pipeline to view results.');
      
      // Navigate to pipeline after research
      if (onNavigate) {
        sessionStorage.setItem('selectedGrantId', grantId);
        onNavigate('kanban');
      }
    } catch (error) {
      console.error('AI research error:', error);
      toast.error('AI research completed in demo mode. View results in Grant Pipeline.');
      
      if (onNavigate) {
        sessionStorage.setItem('selectedGrantId', grantId);
        onNavigate('kanban');
      }
    } finally {
      setAiResearching(null);
    }
  };

  const handleSaveGrant = async (grantId: string) => {
    try {
      if (!grantId || !grants || !Array.isArray(grants)) return;
      
      const grant = grants.find(g => g.id === grantId);
      if (!grant) return;

      // Update local state
      setGrants(prev => prev.map(g => 
        g.id === grantId ? { ...g, saved: !g.saved } : g
      ));
      
      const wasSaved = grant.saved;
      toast.success(wasSaved ? 'Grant removed from pipeline' : 'Grant added to pipeline!');
      
      if (!wasSaved && onNavigate) {
        // Navigate to pipeline to show the newly added grant
        setTimeout(() => {
          sessionStorage.setItem('selectedGrantId', grantId);
          onNavigate('kanban');
        }, 1500);
      }
      
    } catch (error) {
      console.error('Save grant error:', error);
      toast.error('Failed to save grant');
    }
  };

  const handleFilterChange = (field: string, value: any) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const handleEligibilityChange = (eligibility: string, checked: boolean) => {
    setFilters(prev => ({
      ...prev,
      eligibility: checked 
        ? [...(prev.eligibility || []), eligibility]
        : (prev.eligibility || []).filter(e => e !== eligibility)
    }));
  };

  const getDifficultyColor = (difficulty?: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-emerald text-white';
      case 'Medium': return 'bg-amber text-navy';
      case 'Hard': return 'bg-red-500 text-white';
      default: return 'bg-slate-200 text-slate-700';
    }
  };

  const getPriorityColor = (priority?: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-amber/20 text-amber border-amber/30';
      case 'low': return 'bg-slate-100 text-slate-600 border-slate-200';
      default: return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  const getClientGrants = (clientId: string) => {
    try {
      if (!clients || !Array.isArray(clients) || !clientId) return [];
      
      const client = clients.find(c => c && c.id === clientId);
      if (!client) return [];
      
      return grants.filter(grant => grant && grant.clientMatch === client.name);
    } catch (error) {
      console.error('Get client grants error:', error);
      return [];
    }
  };

  const getFilteredClientsForSelect = () => {
    try {
      if (!clients || !Array.isArray(clients)) return [];
      return clients.filter(client => client && client.id && client.name);
    } catch (error) {
      console.error('Filter clients error:', error);
      return [];
    }
  };

  const getDataSourceDisplay = () => {
    switch (dataSource) {
      case 'grants.gov':
        return { text: 'Live from Grants.gov', color: 'bg-emerald text-white' };
      case 'cache':
        return { text: 'Cached Results', color: 'bg-amber text-navy' };
      case 'enhanced_mock':
      default:
        return { text: 'Enhanced Demo Data', color: 'bg-indigo text-white' };
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">AI Research Hub</h1>
          <p className="text-slate-600">Discover opportunities with AI-powered research and client matching</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-sky-50 text-indigo">
            {totalGrants} opportunities found
          </Badge>
          <Badge className={getDataSourceDisplay().color}>
            {getDataSourceDisplay().text}
          </Badge>
          <Button 
            variant="outline" 
            size="sm"
            className="gap-2"
            onClick={handleRefresh}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={() => onNavigate && onNavigate('alerts')}
          >
            <Bell className="h-4 w-4" />
            Smart Alerts
          </Button>
        </div>
      </div>

      {/* Data Source Status Banner */}
      <Alert className={dataSource === 'grants.gov' ? "border-emerald bg-emerald/10" : "border-amber bg-amber/10"}>
        <Info className={`h-4 w-4 ${dataSource === 'grants.gov' ? 'text-emerald' : 'text-amber'}`} />
        <AlertDescription className={dataSource === 'grants.gov' ? "text-emerald-800" : "text-amber-800"}>
          {dataSource === 'grants.gov' ? (
            <><strong>Live Data:</strong> Displaying real-time grant opportunities from Grants.gov API.</>
          ) : (
            <><strong>Demo Mode:</strong> Displaying enhanced demo data. Real Grants.gov data available when API is accessible.</>
          )}
          {lastUpdated && (
            <span className="ml-2">Last updated: {new Date(lastUpdated).toLocaleTimeString()}</span>
          )}
        </AlertDescription>
      </Alert>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 lg:w-400">
          <TabsTrigger value="discover">AI Discovery</TabsTrigger>
          <TabsTrigger value="clients">Client Tracking</TabsTrigger>
          <TabsTrigger value="criteria">Search Criteria</TabsTrigger>
        </TabsList>

        <TabsContent value="discover" className="space-y-6">
          {/* Search and Filters */}
          <Card className="border-slate-200">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-600" />
                    <Input
                      placeholder="AI-powered grant discovery..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-sky-50 border-slate-200"
                    />
                  </div>
                  <Select value={selectedClient} onValueChange={setSelectedClient}>
                    <SelectTrigger className="w-48 bg-sky-50">
                      <SelectValue placeholder="All clients" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All clients</SelectItem>
                      {getFilteredClientsForSelect().map((client) => (
                        <SelectItem key={client.id} value={client.name}>{client.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    onClick={() => setShowFilters(!showFilters)}
                    className="gap-2"
                  >
                    <Filter className="h-4 w-4" />
                    Advanced Filters
                  </Button>
                </div>

                {showFilters && (
                  <div className="border-t border-slate-200 pt-4 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="space-y-2">
                        <Label>Category</Label>
                        <Select value={filters.category} onValueChange={(value) => handleFilterChange('category', value)}>
                          <SelectTrigger className="bg-sky-50 border-slate-200">
                            <SelectValue placeholder="All categories" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All categories</SelectItem>
                            {availableFilters.categories.map((category) => (
                              <SelectItem key={category} value={category}>{category}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Agency</Label>
                        <Select value={filters.agency} onValueChange={(value) => handleFilterChange('agency', value)}>
                          <SelectTrigger className="bg-sky-50 border-slate-200">
                            <SelectValue placeholder="All agencies" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All agencies</SelectItem>
                            {availableFilters.agencies.map((agency) => (
                              <SelectItem key={agency} value={agency}>{agency}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Location</Label>
                        <Select value={filters.location} onValueChange={(value) => handleFilterChange('location', value)}>
                          <SelectTrigger className="bg-sky-50 border-slate-200">
                            <SelectValue placeholder="Any location" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Any location</SelectItem>
                            <SelectItem value="National">National</SelectItem>
                            <SelectItem value="Regional">Regional</SelectItem>
                            <SelectItem value="State">State</SelectItem>
                            <SelectItem value="Local">Local</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Amount Range</Label>
                        <div className="flex gap-2">
                          <Input
                            placeholder="Min"
                            value={filters.amountMin}
                            onChange={(e) => handleFilterChange('amountMin', e.target.value)}
                            className="bg-sky-50 border-slate-200"
                          />
                          <Input
                            placeholder="Max"
                            value={filters.amountMax}
                            onChange={(e) => handleFilterChange('amountMax', e.target.value)}
                            className="bg-sky-50 border-slate-200"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Label>Eligibility Requirements</Label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {availableFilters.eligibilityTypes.map((eligibility) => (
                          <div key={eligibility} className="flex items-center space-x-2">
                            <Checkbox
                              id={eligibility}
                              checked={(filters.eligibility || []).includes(eligibility)}
                              onCheckedChange={(checked) => handleEligibilityChange(eligibility, checked as boolean)}
                            />
                            <Label htmlFor={eligibility} className="text-sm">{eligibility}</Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Grant Results */}
          <div className="grid gap-6">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin text-indigo mx-auto mb-4" />
                  <p className="text-slate-600">AI is discovering grants for you...</p>
                </div>
              </div>
            ) : (
              grants.map((grant) => (
                <Card key={grant.id} className="border-slate-200 hover:border-indigo transition-colors">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2 flex-wrap">
                          <CardTitle className="font-space-grotesk text-navy">{grant.title}</CardTitle>
                          {grant.source === 'grants.gov' && (
                            <Badge className="bg-emerald text-white">Live Data</Badge>
                          )}
                          {grant.isNew && (
                            <Badge className="bg-amber text-navy">AI Matched</Badge>
                          )}
                          {grant.clientMatch && (
                            <Badge className="bg-sky-50 text-indigo">
                              {grant.clientMatch}
                            </Badge>
                          )}
                          {grant.priority && (
                            <Badge className={getPriorityColor(grant.priority)}>
                              {grant.priority} priority
                            </Badge>
                          )}
                        </div>
                        <p className="text-slate-600 mb-3">{grant.funder}</p>
                        <p className="text-sm text-slate-700 leading-relaxed">{grant.description}</p>
                      </div>
                      
                      <div className="flex flex-col items-end gap-3 ml-6">
                        <div className="text-right">
                          <p className="text-2xl font-bold text-emerald">{formatAmount(grant.amount)}</p>
                          <p className="text-sm text-slate-600">
                            Due: {new Date(grant.deadline).toLocaleDateString()}
                          </p>
                        </div>
                        
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="gap-2"
                            onClick={() => handleSaveGrant(grant.id)}
                          >
                            {grant.saved ? (
                              <>
                                <CheckCircle className="h-4 w-4" />
                                Saved
                              </>
                            ) : (
                              <>
                                <BookmarkPlus className="h-4 w-4" />
                                Save
                              </>
                            )}
                          </Button>
                          
                          {grant.link && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="gap-2"
                              onClick={() => window.open(grant.link, '_blank')}
                            >
                              <ExternalLink className="h-4 w-4" />
                              View
                            </Button>
                          )}
                          
                          <Button
                            size="sm"
                            className="gap-2 bg-indigo hover:bg-indigo/90"
                            onClick={() => handleAIResearch(grant.id)}
                            disabled={aiResearching === grant.id}
                          >
                            {aiResearching === grant.id ? (
                              <>
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Researching...
                              </>
                            ) : (
                              <>
                                <Bot className="h-4 w-4" />
                                AI Research
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="flex items-center justify-between flex-wrap gap-4">
                      <div className="flex items-center gap-4 flex-wrap">
                        {grant.difficulty && (
                          <Badge className={getDifficultyColor(grant.difficulty)}>
                            {grant.difficulty}
                          </Badge>
                        )}
                        <div className="flex items-center gap-1 text-sm text-slate-600">
                          <MapPin className="h-4 w-4" />
                          {grant.location || 'National'}
                        </div>
                        <div className="flex items-center gap-1 text-sm text-slate-600">
                          <Building className="h-4 w-4" />
                          {grant.category}
                        </div>
                        {grant.matchRequired && (
                          <Badge variant="outline" className="text-amber border-amber">
                            Match Required
                          </Badge>
                        )}
                        {grant.opportunityNumber && (
                          <Badge variant="outline" className="text-xs">
                            {grant.opportunityNumber}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {grant.tags && grant.tags.slice(0, 3).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {grant.tags && grant.tags.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{grant.tags.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    {grant.eligibility && grant.eligibility.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-slate-100">
                        <p className="text-sm font-medium text-slate-700 mb-2">Eligibility:</p>
                        <div className="flex flex-wrap gap-2">
                          {grant.eligibility.map((eligibility, index) => (
                            <Badge key={index} className="bg-slate-100 text-slate-700">
                              {eligibility}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}

            {grants.length === 0 && !loading && (
              <Card className="border-slate-200">
                <CardContent className="py-12 text-center">
                  <Search className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="font-space-grotesk text-lg mb-2">No grants found</h3>
                  <p className="text-slate-600 mb-4">
                    Try adjusting your search terms or filters to discover more opportunities.
                  </p>
                  <Button onClick={() => {
                    setSearchTerm('');
                    setFilters({
                      category: 'all',
                      agency: 'all',
                      amountMin: '',
                      amountMax: '',
                      deadline: '',
                      difficulty: 'all',
                      location: 'all',
                      matchRequired: false,
                      eligibility: []
                    });
                    setSelectedClient('all');
                    loadGrants();
                  }}>
                    Clear All Filters
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="clients" className="space-y-6">
          <div className="grid gap-6">
            {clients.map((client) => {
              const clientGrants = getClientGrants(client.id);
              return (
                <Card key={client.id} className="border-slate-200">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="font-space-grotesk text-navy">{client.name}</CardTitle>
                        <p className="text-slate-600">{client.type}</p>
                        <p className="text-sm text-slate-500">{client.location}</p>
                      </div>
                      <Badge className="bg-indigo text-white">
                        {clientGrants.length} matches
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-medium text-slate-700 mb-2">Interests:</p>
                        <div className="flex flex-wrap gap-2">
                          {client.categories.map((category, index) => (
                            <Badge key={index} variant="outline">{category}</Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm font-medium text-slate-700 mb-2">Keywords:</p>
                        <div className="flex flex-wrap gap-2">
                          {client.keywords.map((keyword, index) => (
                            <Badge key={index} className="bg-sky-50 text-slate-700">{keyword}</Badge>
                          ))}
                        </div>
                      </div>

                      {clientGrants.length > 0 && (
                        <div>
                          <p className="text-sm font-medium text-slate-700 mb-2">Matched Grants:</p>
                          <div className="space-y-2">
                            {clientGrants.slice(0, 2).map((grant) => (
                              <div key={grant.id} className="p-3 bg-slate-50 rounded-lg">
                                <h4 className="font-medium text-sm">{grant.title}</h4>
                                <p className="text-xs text-slate-600">{grant.funder} • {formatAmount(grant.amount)}</p>
                              </div>
                            ))}
                            {clientGrants.length > 2 && (
                              <p className="text-sm text-slate-600">
                                +{clientGrants.length - 2} more matches
                              </p>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="criteria" className="space-y-6">
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="font-space-grotesk">Search Criteria Management</CardTitle>
              <CardDescription>
                Configure and save search criteria for automated grant discovery
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Settings className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="font-space-grotesk text-lg mb-2">Coming Soon</h3>
                <p className="text-slate-600">
                  Advanced search criteria management will be available in the next update.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}