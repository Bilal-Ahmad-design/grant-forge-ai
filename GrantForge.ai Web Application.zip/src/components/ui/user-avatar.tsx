import React, { useState } from 'react';

interface UserAvatarProps {
  src?: string;
  name: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export function UserAvatar({ src, name, size = 'md', className = '' }: UserAvatarProps) {
  const [imageError, setImageError] = useState(false);
  
  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'h-8 w-8 text-xs';
      case 'md':
        return 'h-10 w-10 text-sm';
      case 'lg':
        return 'h-16 w-16 text-lg';
      case 'xl':
        return 'h-24 w-24 text-xl';
      default:
        return 'h-10 w-10 text-sm';
    }
  };

  const initials = name
    .split(' ')
    .map(word => word.charAt(0))
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const handleImageError = () => {
    setImageError(true);
  };

  // If we have a src and no image error, try to load the image
  if (src && !imageError) {
    return (
      <div className={`${getSizeClasses()} rounded-full overflow-hidden bg-slate-200 flex-shrink-0 ${className}`}>
        <img
          src={src}
          alt={`${name} avatar`}
          className="h-full w-full object-cover"
          onError={handleImageError}
          onLoad={() => setImageError(false)}
        />
      </div>
    );
  }

  // Fallback to initials
  return (
    <div className={`${getSizeClasses()} bg-indigo text-white rounded-full flex items-center justify-center font-medium flex-shrink-0 ${className}`}>
      {initials}
    </div>
  );
}