import React, { useState, useEffect } from 'react';
import { DocumentWorkspace } from './writing/DocumentWorkspace';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  FileText,
  Users,
  Clock,
  TrendingUp,
  MessageSquare,
  Bot,
  Zap,
  CheckCircle,
  AlertCircle,
  Star,
  Activity
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';

interface WritingStats {
  totalDocuments: number;
  inProgress: number;
  completed: number;
  overdue: number;
  activeCollaborators: number;
  wordsWritten: number;
  commentsResolved: number;
  aiSuggestions: number;
}

interface WritingWorkspaceProps {
  user: any;
  onNavigate: (page: string) => void;
}

export function WritingWorkspace({ user, onNavigate }: WritingWorkspaceProps) {
  const [stats, setStats] = useState<WritingStats>({
    totalDocuments: 0,
    inProgress: 0,
    completed: 0,
    overdue: 0,
    activeCollaborators: 0,
    wordsWritten: 0,
    commentsResolved: 0,
    aiSuggestions: 0
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadWritingStats();
  }, []);

  const loadWritingStats = async () => {
    try {
      const response = await apiRequest('/documents/stats');
      setStats(response.stats || stats);
    } catch (error) {
      console.error('Error loading writing stats:', error);
      toast.error('Failed to load writing statistics');
    } finally {
      setLoading(false);
    }
  };

  if (activeTab === 'documents') {
    return <DocumentWorkspace user={user} onNavigate={onNavigate} />;
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-space-grotesk font-semibold text-navy">
          Writing & Collaboration Hub
        </h1>
        <p className="text-slate-600">
          AI-powered collaborative grant writing with real-time editing and team oversight
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="documents" className="gap-2">
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="collaboration" className="gap-2">
            <Users className="h-4 w-4" />
            Team Activity
          </TabsTrigger>
          <TabsTrigger value="ai-insights" className="gap-2">
            <Bot className="h-4 w-4" />
            AI Insights
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo/10 rounded-lg">
                    <FileText className="h-6 w-6 text-indigo" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-navy">{stats.totalDocuments}</div>
                    <div className="text-sm text-slate-600">Total Documents</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber/10 rounded-lg">
                    <Clock className="h-6 w-6 text-amber" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-navy">{stats.inProgress}</div>
                    <div className="text-sm text-slate-600">In Progress</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald/10 rounded-lg">
                    <CheckCircle className="h-6 w-6 text-emerald" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-navy">{stats.completed}</div>
                    <div className="text-sm text-slate-600">Completed</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-100 rounded-lg">
                    <AlertCircle className="h-6 w-6 text-red-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-navy">{stats.overdue}</div>
                    <div className="text-sm text-slate-600">Overdue</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle className="text-lg font-space-grotesk text-navy">
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={() => setActiveTab('documents')}
                  className="w-full justify-start gap-3 bg-navy hover:bg-navy/90"
                >
                  <FileText className="h-5 w-5" />
                  Create New Document
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setActiveTab('collaboration')}
                  className="w-full justify-start gap-3"
                >
                  <Users className="h-5 w-5" />
                  View Team Activity
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setActiveTab('ai-insights')}
                  className="w-full justify-start gap-3"
                >
                  <Bot className="h-5 w-5" />
                  AI Writing Assistant
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onNavigate('kanban')}
                  className="w-full justify-start gap-3"
                >
                  <Activity className="h-5 w-5" />
                  Grant Pipeline
                </Button>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle className="text-lg font-space-grotesk text-navy">
                  Writing Productivity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Words Written</span>
                  <span className="font-semibold text-navy">{stats.wordsWritten.toLocaleString()}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Comments Resolved</span>
                  <span className="font-semibold text-navy">{stats.commentsResolved}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">AI Suggestions Used</span>
                  <span className="font-semibold text-navy">{stats.aiSuggestions}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Active Collaborators</span>
                  <span className="font-semibold text-navy">{stats.activeCollaborators}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Feature Highlights */}
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="text-lg font-space-grotesk text-navy">
                Collaborative Writing Features
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <div className="flex items-start gap-3 p-4 bg-sky-50 rounded-lg">
                  <div className="p-2 bg-indigo rounded-lg">
                    <FileText className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-navy mb-1">Real-time Editing</h4>
                    <p className="text-sm text-slate-600">
                      Collaborate simultaneously with live cursors and instant sync
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-sky-50 rounded-lg">
                  <div className="p-2 bg-emerald rounded-lg">
                    <MessageSquare className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-navy mb-1">Smart Comments</h4>
                    <p className="text-sm text-slate-600">
                      @mention team members with threaded discussions and notifications
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-sky-50 rounded-lg">
                  <div className="p-2 bg-amber rounded-lg">
                    <Bot className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-navy mb-1">AI Writing Assistant</h4>
                    <p className="text-sm text-slate-600">
                      Get intelligent suggestions for improving grant proposals
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-sky-50 rounded-lg">
                  <div className="p-2 bg-slate-600 rounded-lg">
                    <Users className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-navy mb-1">Team Oversight</h4>
                    <p className="text-sm text-slate-600">
                      Admins can monitor writing progress and approve submissions
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-sky-50 rounded-lg">
                  <div className="p-2 bg-navy rounded-lg">
                    <Clock className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-navy mb-1">Version Control</h4>
                    <p className="text-sm text-slate-600">
                      Track changes with automatic versioning and revision history
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-sky-50 rounded-lg">
                  <div className="p-2 bg-indigo rounded-lg">
                    <Star className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-navy mb-1">Templates</h4>
                    <p className="text-sm text-slate-600">
                      Start with proven templates for federal, state, and foundation grants
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Team Activity Tab */}
        <TabsContent value="collaboration" className="space-y-6">
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="text-lg font-space-grotesk text-navy">
                Real-time Team Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Users className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-navy mb-2">
                  Team Activity Dashboard
                </h3>
                <p className="text-slate-600 mb-4">
                  View live writing progress, active collaborators, and team productivity metrics.
                </p>
                <Button onClick={() => setActiveTab('documents')}>
                  Start Collaborating
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Insights Tab */}
        <TabsContent value="ai-insights" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle className="text-lg font-space-grotesk text-navy flex items-center gap-2">
                  <Bot className="h-5 w-5" />
                  AI Writing Statistics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Total AI Suggestions</span>
                  <Badge className="bg-amber text-navy">{stats.aiSuggestions}</Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Writing Quality Improvements</span>
                  <Badge className="bg-emerald text-white">87%</Badge>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Time Saved</span>
                  <Badge className="bg-indigo text-white">24.5 hours</Badge>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Content Generation</span>
                  <Badge className="bg-slate-600 text-white">2,340 words</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle className="text-lg font-space-grotesk text-navy">
                  AI Capabilities
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-sky-50 rounded-lg">
                  <Zap className="h-5 w-5 text-amber" />
                  <div>
                    <p className="font-medium text-navy">Content Enhancement</p>
                    <p className="text-sm text-slate-600">Improve clarity and persuasiveness</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-sky-50 rounded-lg">
                  <Zap className="h-5 w-5 text-amber" />
                  <div>
                    <p className="font-medium text-navy">Section Expansion</p>
                    <p className="text-sm text-slate-600">Add detailed supporting information</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-sky-50 rounded-lg">
                  <Zap className="h-5 w-5 text-amber" />
                  <div>
                    <p className="font-medium text-navy">Smart Summarization</p>
                    <p className="text-sm text-slate-600">Create concise executive summaries</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-sky-50 rounded-lg">
                  <Zap className="h-5 w-5 text-amber" />
                  <div>
                    <p className="font-medium text-navy">Custom Assistance</p>
                    <p className="text-sm text-slate-600">Get help with specific writing tasks</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="text-lg font-space-grotesk text-navy">
                Recent AI Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Bot className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-navy mb-2">
                  AI Insights Coming Soon
                </h3>
                <p className="text-slate-600 mb-4">
                  View detailed analytics about AI writing assistance usage and effectiveness.
                </p>
                <Button onClick={() => setActiveTab('documents')}>
                  Try AI Assistant
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}