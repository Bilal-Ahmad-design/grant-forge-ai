import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  CheckCircle, 
  AlertTriangle, 
  Loader2, 
  Database,
  Server,
  Users,
  FileText,
  BarChart3,
  Shield,
  Key,
  Activity
} from 'lucide-react';
import { apiRequest } from '../utils/supabase/client';
import { toast } from 'sonner@2.0.3';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

interface SystemHealthProps {
  user: User;
}

interface HealthCheck {
  name: string;
  endpoint: string;
  status: 'checking' | 'healthy' | 'warning' | 'error';
  message: string;
  icon: any;
  details?: any;
}

export function SystemHealth({ user }: SystemHealthProps) {
  const [healthChecks, setHealthChecks] = useState<HealthCheck[]>([
    { name: 'Backend Health', endpoint: '/health', status: 'checking', message: 'Checking server status...', icon: Server },
    { name: 'Authentication', endpoint: '/auth/profile', status: 'checking', message: 'Verifying authentication...', icon: Shield },
    { name: 'Grant Pipeline', endpoint: '/grants/pipeline', status: 'checking', message: 'Testing grant pipeline API...', icon: Activity },
    { name: 'Client Management', endpoint: '/clients/managed', status: 'checking', message: 'Testing client management API...', icon: Users },
    { name: 'Analytics', endpoint: '/analytics', status: 'checking', message: 'Testing analytics API...', icon: BarChart3 },
    { name: 'Alerts System', endpoint: '/alerts', status: 'checking', message: 'Testing alerts system...', icon: AlertTriangle }
  ]);
  
  const [overallStatus, setOverallStatus] = useState<'checking' | 'healthy' | 'warning' | 'error'>('checking');
  const [loading, setLoading] = useState(false);

  const runHealthChecks = async () => {
    setLoading(true);
    const updatedChecks = [...healthChecks];
    
    for (let i = 0; i < updatedChecks.length; i++) {
      const check = updatedChecks[i];
      
      try {
        const response = await apiRequest(check.endpoint);
        
        if (response) {
          check.status = 'healthy';
          check.message = 'API responding correctly';
          check.details = response;
        } else {
          check.status = 'warning';
          check.message = 'API responded but no data returned';
        }
      } catch (error: any) {
        // Some endpoints might not exist or require different permissions
        if (error.message.includes('404') || error.message.includes('not found')) {
          check.status = 'warning';
          check.message = 'Endpoint not implemented (demo mode available)';
        } else if (error.message.includes('401') || error.message.includes('403')) {
          check.status = 'warning';
          check.message = 'Permission restricted (expected for role-based access)';
        } else {
          check.status = 'error';
          check.message = `Error: ${error.message}`;
        }
      }
      
      // Update the state progressively
      setHealthChecks([...updatedChecks]);
      
      // Add small delay to see progress
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    // Determine overall status
    const hasErrors = updatedChecks.some(check => check.status === 'error');
    const hasWarnings = updatedChecks.some(check => check.status === 'warning');
    
    if (hasErrors) {
      setOverallStatus('error');
      toast.error('Some systems have errors - check the details below');
    } else if (hasWarnings) {
      setOverallStatus('warning');
      toast.success('System operational with some warnings');
    } else {
      setOverallStatus('healthy');
      toast.success('All systems healthy!');
    }
    
    setLoading(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-emerald';
      case 'warning': return 'text-amber';
      case 'error': return 'text-red-500';
      default: return 'text-slate-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'healthy': return 'bg-emerald text-white';
      case 'warning': return 'bg-amber text-navy';
      case 'error': return 'bg-red-500 text-white';
      default: return 'bg-slate-500 text-white';
    }
  };

  const getOverallStatusColor = () => {
    switch (overallStatus) {
      case 'healthy': return 'border-emerald bg-emerald/10';
      case 'warning': return 'border-amber bg-amber/10';
      case 'error': return 'border-red-500 bg-red-500/10';
      default: return 'border-slate-200 bg-slate-50';
    }
  };

  const getOverallStatusIcon = () => {
    switch (overallStatus) {
      case 'healthy': return CheckCircle;
      case 'warning': return AlertTriangle;
      case 'error': return AlertTriangle;
      default: return Activity;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">System Health Dashboard</h1>
          <p className="text-slate-600">Monitor the health and status of all GrantForge.ai systems</p>
        </div>
        <Button 
          onClick={runHealthChecks}
          disabled={loading}
          className="bg-navy hover:bg-indigo gap-2"
        >
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Activity className="h-4 w-4" />
          )}
          {loading ? 'Running Tests...' : 'Run Health Check'}
        </Button>
      </div>

      {/* Overall Status */}
      <Alert className={getOverallStatusColor()}>
        {React.createElement(getOverallStatusIcon(), { 
          className: `h-4 w-4 ${getStatusColor(overallStatus)}` 
        })}
        <AlertDescription>
          <strong>System Status:</strong>{' '}
          {overallStatus === 'checking' && 'Click "Run Health Check" to test all systems'}
          {overallStatus === 'healthy' && 'All systems operational'}
          {overallStatus === 'warning' && 'Systems operational with some warnings'}
          {overallStatus === 'error' && 'Some systems have issues that need attention'}
        </AlertDescription>
      </Alert>

      {/* Connection Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-slate-200">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Database className="h-4 w-4 text-indigo" />
              Database Connection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-xs text-slate-600">Project ID</p>
              <p className="font-mono text-sm">qafcjuqtazduydhisvds</p>
              <p className="text-xs text-slate-600 mt-2">KV Store Table</p>
              <p className="font-mono text-sm">kv_store_647288d6</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Server className="h-4 w-4 text-indigo" />
              API Server
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-xs text-slate-600">Function Path</p>
              <p className="font-mono text-sm">/functions/v1/make-server-647288d6</p>
              <p className="text-xs text-slate-600 mt-2">Framework</p>
              <p className="font-mono text-sm">Hono + Deno</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Shield className="h-4 w-4 text-indigo" />
              Authentication
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-xs text-slate-600">Current User</p>
              <p className="text-sm font-medium">{user.name}</p>
              <p className="text-xs text-slate-600 mt-2">Role</p>
              <Badge className="bg-indigo text-white text-xs">{user.role}</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Health Check Results */}
      <div className="grid gap-4">
        <h2 className="font-space-grotesk text-lg">Component Health Checks</h2>
        
        {healthChecks.map((check) => {
          const Icon = check.icon;
          return (
            <Card key={check.name} className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Icon className={`h-5 w-5 ${getStatusColor(check.status)}`} />
                    <div>
                      <h3 className="font-medium text-navy">{check.name}</h3>
                      <p className="text-sm text-slate-600">{check.message}</p>
                      <p className="text-xs text-slate-500 font-mono">{check.endpoint}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {check.status === 'checking' && loading && (
                      <Loader2 className="h-4 w-4 animate-spin text-slate-500" />
                    )}
                    <Badge className={getStatusBadge(check.status)}>
                      {check.status === 'checking' ? 'Testing...' : check.status}
                    </Badge>
                  </div>
                </div>
                
                {check.details && check.status === 'healthy' && (
                  <div className="mt-3 p-2 bg-slate-50 rounded text-xs">
                    <p className="text-slate-600">
                      <span className="font-medium">Response:</span> {JSON.stringify(check.details).substring(0, 100)}...
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="font-space-grotesk">Quick Actions & Information</CardTitle>
          <CardDescription>Useful links and development information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium text-navy mb-2">Database Management</h4>
              <p className="text-sm text-slate-600 mb-2">
                Access your Supabase database directly:
              </p>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.open('https://supabase.com/dashboard/project/qafcjuqtazduydhisvds/database/tables', '_blank')}
                className="gap-2"
              >
                <Database className="h-4 w-4" />
                View Database
              </Button>
            </div>
            
            <div>
              <h4 className="font-medium text-navy mb-2">Edge Functions</h4>
              <p className="text-sm text-slate-600 mb-2">
                Monitor and manage server functions:
              </p>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.open('https://supabase.com/dashboard/project/qafcjuqtazduydhisvds/functions', '_blank')}
                className="gap-2"
              >
                <Server className="h-4 w-4" />
                View Functions
              </Button>
            </div>
          </div>
          
          <div className="border-t border-slate-200 pt-4">
            <h4 className="font-medium text-navy mb-2">System Architecture</h4>
            <div className="text-sm text-slate-600 space-y-1">
              <p>• <strong>Frontend:</strong> React + TypeScript + Tailwind CSS</p>
              <p>• <strong>Backend:</strong> Supabase Edge Functions (Hono + Deno)</p>
              <p>• <strong>Database:</strong> PostgreSQL with KV Store abstraction</p>
              <p>• <strong>Authentication:</strong> Supabase Auth with role-based access</p>
              <p>• <strong>API Integration:</strong> OpenAI ChatGPT (configurable)</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}