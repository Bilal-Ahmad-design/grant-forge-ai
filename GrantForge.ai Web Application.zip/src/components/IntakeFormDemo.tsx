import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  FileText, 
  Upload, 
  Users, 
  Settings,
  CheckCircle,
  Clock,
  AlertCircle,
  Building,
  PlusCircle
} from 'lucide-react';
import { EnhancedIntakeForm } from './forms/EnhancedIntakeForm';
import { toast } from 'sonner@2.0.3';

interface IntakeFormDemoProps {
  user: any;
}

interface IntakeSubmission {
  id: string;
  organizationName: string;
  projectTitle: string;
  submittedAt: string;
  status: 'draft' | 'submitted' | 'under_review' | 'approved' | 'needs_revision';
  documentsCount: number;
  assignedTo?: string;
}

export function IntakeFormDemo({ user }: IntakeFormDemoProps) {
  const [activeTab, setActiveTab] = useState('new-form');
  const [submissions, setSubmissions] = useState<IntakeSubmission[]>([
    {
      id: 'intake_001',
      organizationName: 'Roosevelt Elementary School',
      projectTitle: 'STEM Innovation Lab',
      submittedAt: '2024-08-10T14:30:00Z',
      status: 'under_review',
      documentsCount: 8,
      assignedTo: 'Dr. Lisa Chen'
    },
    {
      id: 'intake_002',
      organizationName: 'Lincoln Middle School',
      projectTitle: 'Digital Literacy Program',
      submittedAt: '2024-08-08T09:15:00Z',
      status: 'approved',
      documentsCount: 6,
      assignedTo: 'Michael Rodriguez'
    },
    {
      id: 'intake_003',
      organizationName: 'Washington High School',
      projectTitle: 'Community Arts Initiative',
      submittedAt: '2024-08-05T16:45:00Z',
      status: 'needs_revision',
      documentsCount: 4,
      assignedTo: 'Dr. Lisa Chen'
    }
  ]);

  const [selectedSubmission, setSelectedSubmission] = useState<string | null>(null);

  const statusConfig = {
    draft: { 
      label: 'Draft', 
      color: 'bg-slate-100 text-slate-700', 
      icon: Clock 
    },
    submitted: { 
      label: 'Submitted', 
      color: 'bg-sky-100 text-sky-700', 
      icon: FileText 
    },
    under_review: { 
      label: 'Under Review', 
      color: 'bg-amber text-navy', 
      icon: AlertCircle 
    },
    approved: { 
      label: 'Approved', 
      color: 'bg-emerald text-white', 
      icon: CheckCircle 
    },
    needs_revision: { 
      label: 'Needs Revision', 
      color: 'bg-red-100 text-red-700', 
      icon: AlertCircle 
    }
  };

  const handleFormSubmit = (formData: any, documents: any) => {
    console.log('Form submitted:', formData, documents);
    
    const newSubmission: IntakeSubmission = {
      id: `intake_${Date.now()}`,
      organizationName: formData.organizationName,
      projectTitle: formData.projectTitle,
      submittedAt: new Date().toISOString(),
      status: 'submitted',
      documentsCount: Object.values(documents).flat().length,
      assignedTo: undefined
    };

    setSubmissions(prev => [newSubmission, ...prev]);
    setActiveTab('submissions');
    toast.success('Intake form submitted successfully! We will review your submission and contact you within 2-3 business days.');
  };

  const handleFormSave = (formData: any, documents: any) => {
    console.log('Form saved as draft:', formData, documents);
    toast.success('Form saved as draft');
  };

  const getSubmissionStatus = (submission: IntakeSubmission) => {
    const config = statusConfig[submission.status];
    const StatusIcon = config.icon;
    return (
      <Badge className={config.color}>
        <StatusIcon className="h-3 w-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-space-grotesk font-semibold text-navy">
          Client Intake Management
        </h1>
        <p className="text-slate-600">
          Manage client intake forms, document uploads, and submission workflow
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="new-form" className="gap-2">
            <PlusCircle className="h-4 w-4" />
            New Intake Form
          </TabsTrigger>
          <TabsTrigger value="submissions" className="gap-2">
            <FileText className="h-4 w-4" />
            Submissions ({submissions.length})
          </TabsTrigger>
          <TabsTrigger value="templates" className="gap-2">
            <Settings className="h-4 w-4" />
            Form Templates
          </TabsTrigger>
        </TabsList>

        {/* New Intake Form Tab */}
        <TabsContent value="new-form">
          <EnhancedIntakeForm
            user={user}
            onSubmit={handleFormSubmit}
            onSave={handleFormSave}
            editable={true}
          />
        </TabsContent>

        {/* Submissions Tab */}
        <TabsContent value="submissions" className="space-y-6">
          <div className="grid gap-4">
            {submissions.map((submission) => (
              <Card key={submission.id} className="border-slate-200 hover:border-indigo transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-3">
                        <h3 className="font-medium text-navy">
                          {submission.organizationName}
                        </h3>
                        {getSubmissionStatus(submission)}
                      </div>
                      
                      <div className="space-y-1">
                        <p className="text-sm text-slate-700 font-medium">
                          Project: {submission.projectTitle}
                        </p>
                        <div className="flex items-center gap-4 text-xs text-slate-500">
                          <span>
                            Submitted: {new Date(submission.submittedAt).toLocaleDateString()}
                          </span>
                          <span>
                            Documents: {submission.documentsCount}
                          </span>
                          {submission.assignedTo && (
                            <span>
                              Assigned to: {submission.assignedTo}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedSubmission(submission.id)}
                      >
                        Review
                      </Button>
                      {user.role === 'admin' && submission.status === 'submitted' && (
                        <Button
                          size="sm"
                          className="bg-emerald hover:bg-emerald/90"
                          onClick={() => {
                            setSubmissions(prev =>
                              prev.map(s =>
                                s.id === submission.id
                                  ? { ...s, status: 'approved' as const, assignedTo: user.name }
                                  : s
                              )
                            );
                            toast.success('Submission approved successfully');
                          }}
                        >
                          Approve
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {submissions.length === 0 && (
            <Card className="border-slate-200">
              <CardContent className="p-12 text-center">
                <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-navy mb-2">
                  No Submissions Yet
                </h3>
                <p className="text-slate-600 mb-4">
                  Client intake submissions will appear here once they are received.
                </p>
                <Button 
                  onClick={() => setActiveTab('new-form')}
                  className="bg-navy hover:bg-navy/90"
                >
                  Create New Intake Form
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="border-slate-200 hover:border-indigo transition-colors">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-space-grotesk text-navy flex items-center gap-2">
                  <Building className="h-5 w-5" />
                  K-12 Education Template
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-slate-600">
                  Standard template for K-12 educational institutions with common grant requirements.
                </p>
                <div className="flex flex-wrap gap-1">
                  <Badge variant="outline" className="text-xs">Schools</Badge>
                  <Badge variant="outline" className="text-xs">Districts</Badge>
                  <Badge variant="outline" className="text-xs">Education</Badge>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    Preview
                  </Button>
                  <Button size="sm" className="flex-1 bg-navy hover:bg-navy/90">
                    Use Template
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200 hover:border-indigo transition-colors">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-space-grotesk text-navy flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Nonprofit Template
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-slate-600">
                  Comprehensive template for nonprofit organizations seeking grant funding.
                </p>
                <div className="flex flex-wrap gap-1">
                  <Badge variant="outline" className="text-xs">Nonprofits</Badge>
                  <Badge variant="outline" className="text-xs">501(c)(3)</Badge>
                  <Badge variant="outline" className="text-xs">Community</Badge>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    Preview
                  </Button>
                  <Button size="sm" className="flex-1 bg-navy hover:bg-navy/90">
                    Use Template
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200 hover:border-indigo transition-colors">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-space-grotesk text-navy flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Custom Template
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-slate-600">
                  Create a custom template with your own fields and document requirements.
                </p>
                <div className="flex flex-wrap gap-1">
                  <Badge variant="outline" className="text-xs">Custom</Badge>
                  <Badge variant="outline" className="text-xs">Flexible</Badge>
                  <Badge variant="outline" className="text-xs">Reusable</Badge>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    Learn More
                  </Button>
                  <Button size="sm" className="flex-1 bg-navy hover:bg-navy/90">
                    Create Template
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="text-lg font-space-grotesk text-navy">
                Template Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <h4 className="font-medium text-navy">Dynamic Form Fields</h4>
                  <p className="text-sm text-slate-600">
                    Add, remove, and customize form fields to match your specific requirements.
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-navy">Document Categories</h4>
                  <p className="text-sm text-slate-600">
                    Organize required documents into categories with specific file type restrictions.
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-navy">Workflow Automation</h4>
                  <p className="text-sm text-slate-600">
                    Automatically route submissions based on project type or funding amount.
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-navy">Validation Rules</h4>
                  <p className="text-sm text-slate-600">
                    Set up custom validation rules to ensure data quality and completeness.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-sky-50 rounded-lg">
                <FileText className="h-5 w-5 text-indigo" />
              </div>
              <div>
                <p className="text-lg font-semibold text-navy">
                  {submissions.filter(s => s.status === 'submitted').length}
                </p>
                <p className="text-xs text-slate-600">Pending Review</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald/10 rounded-lg">
                <CheckCircle className="h-5 w-5 text-emerald" />
              </div>
              <div>
                <p className="text-lg font-semibold text-navy">
                  {submissions.filter(s => s.status === 'approved').length}
                </p>
                <p className="text-xs text-slate-600">Approved</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber/10 rounded-lg">
                <AlertCircle className="h-5 w-5 text-amber" />
              </div>
              <div>
                <p className="text-lg font-semibold text-navy">
                  {submissions.filter(s => s.status === 'needs_revision').length}
                </p>
                <p className="text-xs text-slate-600">Need Revision</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-navy/10 rounded-lg">
                <Upload className="h-5 w-5 text-navy" />
              </div>
              <div>
                <p className="text-lg font-semibold text-navy">
                  {submissions.reduce((total, s) => total + s.documentsCount, 0)}
                </p>
                <p className="text-xs text-slate-600">Documents Uploaded</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}