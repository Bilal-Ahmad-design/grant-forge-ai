# GrantForge.ai Role-Based Access Control

## Role Hierarchy & Permissions

### Super Admin
**Focus:** Platform Administration
- **Dashboard:** User analytics, platform metrics, system overview
- **User Management:** Add/edit/deactivate users, impersonation functionality
- **System Health:** API status, database monitoring, platform performance
- **Special Powers:** Can impersonate any other user to view their experience

### Admin
**Focus:** Full Grant Management & Team Oversight
- **Dashboard:** Grant portfolio overview, team performance
- **Research Hub:** Grant opportunity discovery and filtering
- **Grant Pipeline:** Full Kanban management with all permissions
- **Daily Alerts:** Grant deadlines and opportunity notifications
- **Client Management:** ✅ Add/edit clients, relationship management
- **Intake Form Demo:** ✅ Client onboarding and needs assessment
- **Team Analytics:** ✅ KPIs, writer performance, financial metrics

### Senior Writer
**Focus:** Independent Grant Writing & Self-Management
- **Dashboard:** Personal grant portfolio, assigned opportunities
- **Research Hub:** Grant opportunity discovery and filtering
- **Grant Pipeline:** Can self-assign opportunities, move through stages, approve own grants
- **Daily Alerts:** Personal deadlines and assigned grant notifications
- **Permissions:** Can submit directly and approve their own grants for final submission

### Junior Writer
**Focus:** Guided Grant Writing & Learning
- **Dashboard:** Personal grant portfolio, assigned opportunities
- **Research Hub:** Grant opportunity discovery and filtering
- **Grant Pipeline:** Can work on assigned grants, limited stage movement
- **Daily Alerts:** Personal deadlines and assigned grant notifications
- **Permissions:** Requires admin review before submission

## Navigation Access Matrix

| Feature | Super Admin | Admin | Senior Writer | Junior Writer |
|---------|-------------|-------|---------------|---------------|
| Platform Dashboard | ✅ | ❌ | ❌ | ❌ |
| User Management | ✅ | ❌ | ❌ | ❌ |
| System Health | ✅ | ❌ | ❌ | ❌ |
| Grant Dashboard | ❌* | ✅ | ✅ | ✅ |
| Research Hub | ❌* | ✅ | ✅ | ✅ |
| Grant Pipeline | ❌* | ✅ | ✅ | ✅ |
| Daily Alerts | ❌* | ✅ | ✅ | ✅ |
| Client Management | ❌* | ✅ | ❌ | ❌ |
| Intake Forms | ❌* | ✅ | ❌ | ❌ |
| Team Analytics | ❌* | ✅ | ❌ | ❌ |

*Super Admin can access these via impersonation

## Clear Separation of Concerns

1. **Super Admin:** Platform oversight, no grant writing
2. **Admin:** Full grant management + team leadership
3. **Writers:** Grant research, writing, and tracking only

This structure ensures each role has access to exactly what they need for their responsibilities, with appropriate escalation paths and oversight mechanisms.