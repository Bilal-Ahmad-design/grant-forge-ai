import React, { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Plus, 
  Search, 
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';

// Import types and utilities
import { Grant, User, Column, TeamMember, KanbanBoardProps } from './kanban/types';
import { STAGE_CONFIGS } from './kanban/constants';
import { 
  formatAmount, 
  createDemoGrants, 
  canMoveToStage, 
  requiresApprovalForStage,
  canSelfAssign,
  canAssignToOthers,
  canApprove
} from './kanban/helpers';

// Import components
import { KanbanColumn } from './kanban/KanbanColumn';
import { AssignmentDialog } from './kanban/dialogs/AssignmentDialog';
import { ApprovalDialog } from './kanban/dialogs/ApprovalDialog';
import { MoveStageDialog } from './kanban/dialogs/MoveStageDialog';

export function KanbanBoard({ user, onNavigate }: KanbanBoardProps) {
  const [loading, setLoading] = useState(true);
  const [grants, setGrants] = useState<Grant[]>([]);
  const [selectedGrant, setSelectedGrant] = useState<Grant | null>(null);
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false);
  const [moveDialogOpen, setMoveDialogOpen] = useState(false);
  const [approvalAction, setApprovalAction] = useState<'approve' | 'reject'>('approve');
  const [approvalComments, setApprovalComments] = useState('');
  const [targetStage, setTargetStage] = useState('');
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedAssignee, setSelectedAssignee] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterAssignee, setFilterAssignee] = useState('all');
  const [demoMode, setDemoMode] = useState(false);

  // Available team members for assignment
  const teamMembers: TeamMember[] = [
    { id: user.id, name: user.name, role: user.role },
    { id: 'user2', name: 'Lisa Thompson', role: 'senior-writer' },
    { id: 'user3', name: 'Alex Martinez', role: 'junior-writer' },
    { id: 'user4', name: 'Maria Santos', role: 'senior-writer' },
    { id: 'user5', name: 'David Chen', role: 'junior-writer' }
  ].filter(member => member.role !== 'super-admin');

  useEffect(() => {
    loadGrants();
  }, [user]);

  const loadGrants = async () => {
    try {
      setLoading(true);
      const response = await apiRequest('/grants/pipeline');
      const grantsData = response.grants || [];
      
      if (grantsData.length > 0) {
        setGrants(grantsData);
        setDemoMode(false);
      } else {
        setGrants(createDemoGrants(user));
        setDemoMode(true);
      }
    } catch (error) {
      console.error('Error loading grants:', error);
      setGrants(createDemoGrants(user));
      setDemoMode(true);
      toast.success('Running in demo mode - all actions will work locally');
    } finally {
      setLoading(false);
    }
  };

  const handleMoveStage = async (grantId: string, newStage: string, skipDialog = false) => {
    const grant = grants.find(g => g.id === grantId);
    if (!grant) return;

    const canMove = canMoveToStage(user, grant, newStage);
    if (!canMove.allowed) {
      toast.error(canMove.reason);
      return;
    }

    if (user.role === 'junior-writer' && newStage === 'submitted' && !skipDialog) {
      setSelectedGrant(grant);
      setTargetStage(newStage);
      setMoveDialogOpen(true);
      return;
    }

    try {
      setSubmitting(true);
      
      const response = await apiRequest(`/grants/pipeline/${grantId}/move`, {
        method: 'PATCH',
        body: JSON.stringify({
          stage: newStage,
          requires_approval: requiresApprovalForStage(user.role, newStage)
        })
      });

      if (response.grant || response.demo_mode) {
        setGrants(prev => prev.map(g => 
          g.id === grantId 
            ? { 
                ...g, 
                stage: newStage as any,
                approval_status: requiresApprovalForStage(user.role, newStage) ? 'pending' : undefined,
                updated_at: new Date().toISOString(),
                updated_by_name: user.name
              }
            : g
        ));

        const successMessage = requiresApprovalForStage(user.role, newStage) 
          ? `Grant moved and submitted for approval!`
          : `Grant moved to ${newStage}!`;

        toast.success(response.demo_mode ? `${successMessage} (Demo mode)` : successMessage);
      }
      setMoveDialogOpen(false);
    } catch (error: any) {
      console.error('Error moving grant stage:', error);
      
      setGrants(prev => prev.map(g => 
        g.id === grantId 
          ? { 
              ...g, 
              stage: newStage as any,
              approval_status: requiresApprovalForStage(user.role, newStage) ? 'pending' : undefined,
              updated_at: new Date().toISOString(),
              updated_by_name: user.name
            }
          : g
      ));

      toast.success(`Grant moved to ${newStage}! (Demo mode)`);
      setMoveDialogOpen(false);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSelfAssign = async (grantId: string) => {
    if (!canSelfAssign(user.role)) {
      toast.error('You do not have permission to self-assign grants');
      return;
    }

    try {
      setSubmitting(true);
      await apiRequest(`/grants/pipeline/${grantId}/assign`, {
        method: 'PATCH',
        body: JSON.stringify({ assignTo: user.id })
      });

      setGrants(prev => prev.map(g => 
        g.id === grantId ? { ...g, assigned_to: user.id, updated_at: new Date().toISOString() } : g
      ));
      toast.success('Grant assigned to you successfully!');
    } catch (error: any) {
      console.error('Error self-assigning grant:', error);
      setGrants(prev => prev.map(g => 
        g.id === grantId ? { ...g, assigned_to: user.id, updated_at: new Date().toISOString() } : g
      ));
      toast.success('Grant assigned to you! (Demo mode)');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAssignToOther = async () => {
    if (!selectedGrant || !selectedAssignee) return;

    try {
      setSubmitting(true);
      await apiRequest(`/grants/pipeline/${selectedGrant.id}/assign`, {
        method: 'PATCH',
        body: JSON.stringify({ assignTo: selectedAssignee })
      });

      setGrants(prev => prev.map(g => 
        g.id === selectedGrant.id ? { ...g, assigned_to: selectedAssignee, updated_at: new Date().toISOString() } : g
      ));
      
      toast.success('Grant assigned successfully!');
      setAssignDialogOpen(false);
      setSelectedAssignee('');
    } catch (error: any) {
      console.error('Error assigning grant:', error);
      setGrants(prev => prev.map(g => 
        g.id === selectedGrant.id ? { ...g, assigned_to: selectedAssignee, updated_at: new Date().toISOString() } : g
      ));
      
      toast.success('Grant assigned successfully! (Demo mode)');
      setAssignDialogOpen(false);
      setSelectedAssignee('');
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprovalAction = async () => {
    if (!selectedGrant) return;

    try {
      setSubmitting(true);
      await apiRequest(`/grants/pipeline/${selectedGrant.id}/approve`, {
        method: 'PATCH',
        body: JSON.stringify({
          action: approvalAction,
          comments: approvalComments,
          stage: targetStage || selectedGrant.stage
        })
      });

      const newStage = approvalAction === 'approve' ? (targetStage || 'submitted') : selectedGrant.stage;
      const newApprovalStatus = approvalAction === 'approve' ? 'approved' : 'rejected';

      setGrants(prev => prev.map(g => 
        g.id === selectedGrant.id 
          ? { 
              ...g, 
              stage: newStage as any,
              approval_status: newApprovalStatus,
              updated_at: new Date().toISOString()
            }
          : g
      ));

      toast.success(`Grant ${approvalAction}d successfully!`);
      setApprovalDialogOpen(false);
      setApprovalComments('');
    } catch (error: any) {
      console.error(`Error ${approvalAction}ing grant:`, error);
      
      const newStage = approvalAction === 'approve' ? (targetStage || 'submitted') : selectedGrant.stage;
      const newApprovalStatus = approvalAction === 'approve' ? 'approved' : 'rejected';

      setGrants(prev => prev.map(g => 
        g.id === selectedGrant.id 
          ? { 
              ...g, 
              stage: newStage as any,
              approval_status: newApprovalStatus,
              updated_at: new Date().toISOString()
            }
          : g
      ));
      
      toast.success(`Grant ${approvalAction}d successfully! (Demo mode)`);
      setApprovalDialogOpen(false);
      setApprovalComments('');
    } finally {
      setSubmitting(false);
    }
  };

  // Filter grants based on search and filters
  const filteredGrants = grants.filter(grant => {
    const matchesSearch = grant.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         grant.funder.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         grant.client_name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPriority = filterPriority === 'all' || grant.priority === filterPriority;
    
    const matchesAssignee = filterAssignee === 'all' || 
                           (filterAssignee === 'me' && grant.assigned_to === user.id) ||
                           (filterAssignee === 'unassigned' && !grant.assigned_to) ||
                           grant.assigned_to === filterAssignee;

    return matchesSearch && matchesPriority && matchesAssignee;
  });

  // Organize grants into columns
  const getColumns = (): Column[] => {
    return STAGE_CONFIGS.map(config => ({
      ...config,
      grants: config.id === 'final' 
        ? filteredGrants.filter(g => g.stage === 'awarded' || g.stage === 'denied')
        : filteredGrants.filter(g => g.stage === config.stage)
    }));
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center min-h-96">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-indigo mx-auto mb-4" />
            <p className="text-slate-600">Loading grant pipeline...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Demo Mode Banner */}
      {demoMode && (
        <Alert className="border-amber bg-amber/10">
          <AlertTriangle className="h-4 w-4 text-amber" />
          <AlertDescription className="text-amber-800">
            <strong>Demo Mode:</strong> You're working with sample data. All actions will update locally but won't persist after refresh.
          </AlertDescription>
        </Alert>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">Grant Pipeline</h1>
          <p className="text-slate-600">
            Track grants through Research → Writing → Review → Submitted → Final Results
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-indigo text-white">
            {filteredGrants.length} grants
          </Badge>
          <Button 
            className="bg-navy hover:bg-indigo gap-2"
            onClick={() => onNavigate && onNavigate('research')}
          >
            <Plus className="h-4 w-4" />
            Add Grant
          </Button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-wrap items-center gap-4 p-4 bg-white rounded-lg border border-slate-200">
        <div className="flex-1 min-w-64">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-600" />
            <Input
              placeholder="Search grants, funders, or clients..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-sky-50"
            />
          </div>
        </div>
        
        <Select value={filterPriority} onValueChange={setFilterPriority}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priorities</SelectItem>
            <SelectItem value="high">High Priority</SelectItem>
            <SelectItem value="medium">Medium Priority</SelectItem>
            <SelectItem value="low">Low Priority</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterAssignee} onValueChange={setFilterAssignee}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Assignees</SelectItem>
            <SelectItem value="me">My Grants</SelectItem>
            <SelectItem value="unassigned">Unassigned</SelectItem>
            {teamMembers.map(member => (
              <SelectItem key={member.id} value={member.id}>
                {member.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Pipeline Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {getColumns().map(column => {
          const Icon = column.icon;
          const totalValue = column.grants.reduce((sum, grant) => {
            const match = grant.amount.match(/\$?([\d,]+(?:,\d{3})*)/);
            return sum + (match ? parseInt(match[1].replace(/,/g, '')) : 0);
          }, 0);

          return (
            <Card key={column.id} className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <Icon className="h-5 w-5 text-slate-600" />
                  <Badge variant="secondary">{column.grants.length}</Badge>
                </div>
                <h3 className="font-medium text-slate-900">{column.title}</h3>
                <p className="text-sm text-slate-600 mb-2">{column.description}</p>
                {totalValue > 0 && (
                  <p className="text-xs text-emerald font-medium">
                    {formatAmount(`$${totalValue.toLocaleString()}`)} total
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 min-h-96">
        {getColumns().map((column) => (
          <KanbanColumn
            key={column.id}
            column={column}
            user={user}
            teamMembers={teamMembers}
            submitting={submitting}
            onMoveStage={handleMoveStage}
            onSelfAssign={handleSelfAssign}
            onOpenAssignDialog={(grant) => {
              setSelectedGrant(grant);
              setAssignDialogOpen(true);
            }}
            onOpenApprovalDialog={(grant, action) => {
              setSelectedGrant(grant);
              setApprovalAction(action);
              setApprovalDialogOpen(true);
            }}
          />
        ))}
      </div>

      {/* Dialogs */}
      <AssignmentDialog
        open={assignDialogOpen}
        onOpenChange={setAssignDialogOpen}
        selectedGrant={selectedGrant}
        selectedAssignee={selectedAssignee}
        setSelectedAssignee={setSelectedAssignee}
        teamMembers={teamMembers}
        submitting={submitting}
        onAssign={handleAssignToOther}
      />

      <MoveStageDialog
        open={moveDialogOpen}
        onOpenChange={setMoveDialogOpen}
        submitting={submitting}
        onConfirm={() => handleMoveStage(selectedGrant?.id || '', targetStage, true)}
      />

      <ApprovalDialog
        open={approvalDialogOpen}
        onOpenChange={setApprovalDialogOpen}
        approvalAction={approvalAction}
        approvalComments={approvalComments}
        setApprovalComments={setApprovalComments}
        submitting={submitting}
        onApproval={handleApprovalAction}
      />
    </div>
  );
}