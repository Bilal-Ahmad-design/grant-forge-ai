import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Search, 
  Filter, 
  Save, 
  ExternalLink, 
  Calendar, 
  DollarSign, 
  MapPin, 
  Users, 
  Clock, 
  Star,
  Eye,
  Bookmark,
  BookmarkCheck,
  TrendingUp,
  Database,
  RefreshCw,
  Settings,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  CheckCircle,
  XCircle,
  Zap,
  Globe
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';

interface Grant {
  id: string;
  title: string;
  description: string;
  funder: string;
  fundingAgency: string;
  amount: string;
  deadline: string;
  category: string;
  eligibility: string[];
  location: string;
  tags: string[];
  difficulty: 'Easy' | 'Medium' | 'Hard';
  status: 'Open' | 'Closed' | 'Archived' | 'Upcoming';
  sources: {
    source: string;
    sourceUrl: string;
    confidence: number;
    lastUpdated: string;
  }[];
  isNew: boolean;
  isFeatured: boolean;
  saved?: boolean;
  viewed?: boolean;
  daysUntilDeadline?: number;
  relevanceScore?: number;
  matchRequired: boolean;
  matchPercentage?: number;
  opportunityNumber: string;
}

interface SearchFilters {
  keyword: string;
  category: string;
  agency: string;
  location: string;
  amountMin: string;
  amountMax: string;
  deadlineMin: string;
  deadlineMax: string;
  difficulty: string[];
  sources: string[];
  tags: string[];
  includeExpired: boolean;
  sortBy: string;
  sortOrder: string;
}

interface GrantSource {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  priority: number;
  categories: string[];
  lastUpdated: string;
}

interface SearchResult {
  grants: Grant[];
  total: number;
  sources: {
    [sourceId: string]: {
      count: number;
      status: 'success' | 'error' | 'timeout';
      error?: string;
      fetchTime: number;
    };
  };
  searchTime: number;
  cached: boolean;
  suggestions?: string[];
}

interface EnhancedResearchHubProps {
  user: any;
  onNavigate: (page: string) => void;
}

export function EnhancedResearchHub({ user, onNavigate }: EnhancedResearchHubProps) {
  const [grants, setGrants] = useState<Grant[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchResult, setSearchResult] = useState<SearchResult | null>(null);
  const [sources, setSources] = useState<GrantSource[]>([]);
  const [activeTab, setActiveTab] = useState('search');
  const [selectedGrant, setSelectedGrant] = useState<Grant | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState<SearchFilters>({
    keyword: '',
    category: 'all',
    agency: 'all',
    location: 'all',
    amountMin: '',
    amountMax: '',
    deadlineMin: '',
    deadlineMax: '',
    difficulty: [],
    sources: [],
    tags: [],
    includeExpired: false,
    sortBy: 'relevance',
    sortOrder: 'desc'
  });

  // Load sources on component mount
  useEffect(() => {
    loadSources();
  }, []);

  // Auto-search when tab changes to search
  useEffect(() => {
    if (activeTab === 'search' && grants.length === 0) {
      handleSearch();
    }
  }, [activeTab]);

  const loadSources = async () => {
    try {
      const response = await apiRequest('/grants/sources');
      setSources(response.sources || []);
    } catch (error) {
      console.error('Error loading sources:', error);
      toast.error('Failed to load grant sources');
    }
  };

  const handleSearch = async () => {
    setLoading(true);
    try {
      const searchParams = new URLSearchParams();
      
      // Add basic filters
      if (filters.keyword) searchParams.append('keyword', filters.keyword);
      if (filters.category !== 'all') searchParams.append('category', filters.category);
      if (filters.agency !== 'all') searchParams.append('agency', filters.agency);
      if (filters.location !== 'all') searchParams.append('location', filters.location);
      
      // Add advanced filters
      if (filters.amountMin) searchParams.append('amountMin', filters.amountMin);
      if (filters.amountMax) searchParams.append('amountMax', filters.amountMax);
      if (filters.deadlineMin) searchParams.append('deadlineMin', filters.deadlineMin);
      if (filters.deadlineMax) searchParams.append('deadlineMax', filters.deadlineMax);
      if (filters.difficulty.length > 0) searchParams.append('difficulty', filters.difficulty.join(','));
      if (filters.sources.length > 0) searchParams.append('sources', filters.sources.join(','));
      if (filters.tags.length > 0) searchParams.append('tags', filters.tags.join(','));
      
      searchParams.append('includeExpired', filters.includeExpired.toString());
      searchParams.append('sortBy', filters.sortBy);
      searchParams.append('sortOrder', filters.sortOrder);
      searchParams.append('limit', '50');

      const response = await apiRequest(`/grants/search?${searchParams}`);
      
      setSearchResult(response);
      setGrants(response.grants || []);
      
      if (response.cached) {
        toast.info('Results loaded from cache');
      } else {
        toast.success(`Found ${response.total} grants from ${Object.keys(response.sources).length} sources`);
      }
    } catch (error: any) {
      console.error('Search error:', error);
      toast.error('Search failed: ' + (error.message || 'Unknown error'));
      setGrants([]);
      setSearchResult(null);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveGrant = async (grant: Grant) => {
    try {
      if (grant.saved) {
        await apiRequest('/grants/unsave', {
          method: 'POST',
          body: JSON.stringify({ grantId: grant.id })
        });
        toast.success('Grant removed from saved list');
      } else {
        await apiRequest('/grants/save', {
          method: 'POST',
          body: JSON.stringify({ grantId: grant.id })
        });
        toast.success('Grant saved successfully');
      }
      
      // Update the grant in the local state
      setGrants(prev => prev.map(g => 
        g.id === grant.id ? { ...g, saved: !g.saved } : g
      ));
    } catch (error) {
      console.error('Error saving grant:', error);
      toast.error('Failed to save grant');
    }
  };

  const handleFilterChange = (key: keyof SearchFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      keyword: '',
      category: 'all',
      agency: 'all',
      location: 'all',
      amountMin: '',
      amountMax: '',
      deadlineMin: '',
      deadlineMax: '',
      difficulty: [],
      sources: [],
      tags: [],
      includeExpired: false,
      sortBy: 'relevance',
      sortOrder: 'desc'
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-emerald text-white';
      case 'Medium': return 'bg-amber text-navy';
      case 'Hard': return 'bg-red-500 text-white';
      default: return 'bg-slate-200 text-slate-700';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open': return 'bg-emerald text-white';
      case 'Upcoming': return 'bg-indigo text-white';
      case 'Closed': return 'bg-slate-500 text-white';
      case 'Archived': return 'bg-slate-300 text-slate-700';
      default: return 'bg-slate-200 text-slate-700';
    }
  };

  const getSourceIcon = (sourceId: string) => {
    const iconMap: { [key: string]: React.ReactNode } = {
      'grants-gov': <Globe className="h-3 w-3" />,
      'sam-gov': <Database className="h-3 w-3" />,
      'schoolsafety-gov': <Users className="h-3 w-3" />,
      'candid': <Star className="h-3 w-3" />,
      'grantwatch': <TrendingUp className="h-3 w-3" />,
      'state-doe': <MapPin className="h-3 w-3" />
    };
    return iconMap[sourceId] || <Database className="h-3 w-3" />;
  };

  const GrantCard = ({ grant }: { grant: Grant }) => (
    <Card className="border-slate-200 hover:border-indigo transition-all duration-200 hover:shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-navy line-clamp-2">
                {grant.title}
              </h3>
              {grant.isNew && (
                <Badge className="bg-amber text-navy text-xs">New</Badge>
              )}
              {grant.isFeatured && (
                <Badge className="bg-indigo text-white text-xs">Featured</Badge>
              )}
            </div>
            
            <div className="flex items-center gap-2 text-sm text-slate-600 mb-2">
              <span className="font-medium">{grant.funder}</span>
              <span>•</span>
              <Badge className={getDifficultyColor(grant.difficulty)}>
                {grant.difficulty}
              </Badge>
              <Badge className={getStatusColor(grant.status)}>
                {grant.status}
              </Badge>
            </div>

            <div className="flex items-center gap-4 text-sm text-slate-600">
              <div className="flex items-center gap-1">
                <DollarSign className="h-4 w-4" />
                <span>{grant.amount}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                <span>{new Date(grant.deadline).toLocaleDateString()}</span>
                {grant.daysUntilDeadline !== undefined && grant.daysUntilDeadline >= 0 && (
                  <span className="text-amber">({grant.daysUntilDeadline} days)</span>
                )}
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                <span>{grant.location}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => handleSaveGrant(grant)}
              className={grant.saved ? 'text-amber' : 'text-slate-500'}
            >
              {grant.saved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setSelectedGrant(grant)}
            >
              View Details
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <p className="text-sm text-slate-700 line-clamp-2 mb-3">
          {grant.description}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex flex-wrap gap-1">
            {grant.tags.slice(0, 3).map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
            {grant.tags.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{grant.tags.length - 3} more
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-1">
            {grant.sources.map((source, index) => (
              <div
                key={index}
                className="flex items-center gap-1 text-xs text-slate-500"
                title={source.source}
              >
                {getSourceIcon(source.source)}
              </div>
            ))}
            {grant.sources.length > 1 && (
              <Badge variant="outline" className="text-xs">
                {grant.sources.length} sources
              </Badge>
            )}
          </div>
        </div>

        {grant.matchRequired && (
          <div className="mt-2 p-2 bg-amber/10 rounded-md">
            <p className="text-xs text-amber-700">
              Match required: {grant.matchPercentage || 'See details'}%
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );

  const SourceStatus = () => (
    <Card className="border-slate-200">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-space-grotesk text-navy flex items-center gap-2">
          <Database className="h-5 w-5" />
          Search Sources Status
        </CardTitle>
      </CardHeader>
      <CardContent>
        {searchResult ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span>Search completed in {searchResult.searchTime}ms</span>
              {searchResult.cached && <Badge variant="outline">Cached</Badge>}
            </div>
            
            <div className="space-y-2">
              {Object.entries(searchResult.sources).map(([sourceId, stats]) => {
                const source = sources.find(s => s.id === sourceId);
                const statusIcon = stats.status === 'success' 
                  ? <CheckCircle className="h-4 w-4 text-emerald" />
                  : stats.status === 'timeout'
                  ? <Clock className="h-4 w-4 text-amber" />
                  : <XCircle className="h-4 w-4 text-red-500" />;
                  
                return (
                  <div key={sourceId} className="flex items-center justify-between p-2 bg-sky-50 rounded-md">
                    <div className="flex items-center gap-2">
                      {getSourceIcon(sourceId)}
                      <span className="text-sm font-medium">{source?.name || sourceId}</span>
                      {statusIcon}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <span>{stats.count} results</span>
                      <span>•</span>
                      <span>{stats.fetchTime}ms</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <p className="text-sm text-slate-600">Run a search to see source status</p>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-space-grotesk font-semibold text-navy">
          Research Hub
        </h1>
        <p className="text-slate-600">
          Search and discover grant opportunities from multiple sources
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="search" className="gap-2">
            <Search className="h-4 w-4" />
            Search Grants
          </TabsTrigger>
          <TabsTrigger value="saved" className="gap-2">
            <Bookmark className="h-4 w-4" />
            Saved Grants
          </TabsTrigger>
          <TabsTrigger value="sources" className="gap-2">
            <Database className="h-4 w-4" />
            Sources
          </TabsTrigger>
          <TabsTrigger value="analytics" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        {/* Search Tab */}
        <TabsContent value="search" className="space-y-6">
          {/* Search Controls */}
          <Card className="border-slate-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-space-grotesk text-navy">
                  Search Grants
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowFilters(!showFilters)}
                    className="gap-2"
                  >
                    <Filter className="h-4 w-4" />
                    {showFilters ? 'Hide Filters' : 'Show Filters'}
                    {showFilters ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={clearFilters}
                    disabled={!Object.values(filters).some(v => 
                      Array.isArray(v) ? v.length > 0 : v && v !== 'all' && v !== 'relevance' && v !== 'desc' && v !== false
                    )}
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Basic Search */}
              <div className="flex gap-3">
                <div className="flex-1">
                  <Input
                    placeholder="Search grants by keyword..."
                    value={filters.keyword}
                    onChange={(e) => handleFilterChange('keyword', e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  />
                </div>
                <Button 
                  onClick={handleSearch} 
                  disabled={loading}
                  className="bg-navy hover:bg-navy/90 gap-2"
                >
                  {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                  Search
                </Button>
              </div>

              {/* Quick Filters */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <Select value={filters.category} onValueChange={(value) => handleFilterChange('category', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="STEM Education">STEM Education</SelectItem>
                    <SelectItem value="Teacher Quality">Teacher Quality</SelectItem>
                    <SelectItem value="School Safety">School Safety</SelectItem>
                    <SelectItem value="Infrastructure">Infrastructure</SelectItem>
                    <SelectItem value="Arts Education">Arts Education</SelectItem>
                    <SelectItem value="Technology">Technology</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.agency} onValueChange={(value) => handleFilterChange('agency', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Agency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Agencies</SelectItem>
                    <SelectItem value="Department of Education">Department of Education</SelectItem>
                    <SelectItem value="National Science Foundation">National Science Foundation</SelectItem>
                    <SelectItem value="Department of Agriculture">Department of Agriculture</SelectItem>
                    <SelectItem value="Department of Health">Department of Health</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.location} onValueChange={(value) => handleFilterChange('location', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Locations</SelectItem>
                    <SelectItem value="National">National</SelectItem>
                    <SelectItem value="California">California</SelectItem>
                    <SelectItem value="Texas">Texas</SelectItem>
                    <SelectItem value="New York">New York</SelectItem>
                    <SelectItem value="Florida">Florida</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.sortBy} onValueChange={(value) => handleFilterChange('sortBy', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relevance">Relevance</SelectItem>
                    <SelectItem value="deadline">Deadline</SelectItem>
                    <SelectItem value="amount">Amount</SelectItem>
                    <SelectItem value="updated">Last Updated</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Advanced Filters */}
              <Collapsible open={showFilters} onOpenChange={setShowFilters}>
                <CollapsibleContent className="space-y-4 pt-4 border-t border-slate-200">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Amount Range</Label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="Min amount"
                          value={filters.amountMin}
                          onChange={(e) => handleFilterChange('amountMin', e.target.value)}
                        />
                        <Input
                          placeholder="Max amount"
                          value={filters.amountMax}
                          onChange={(e) => handleFilterChange('amountMax', e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Deadline Range</Label>
                      <div className="flex gap-2">
                        <Input
                          type="date"
                          value={filters.deadlineMin}
                          onChange={(e) => handleFilterChange('deadlineMin', e.target.value)}
                        />
                        <Input
                          type="date"
                          value={filters.deadlineMax}
                          onChange={(e) => handleFilterChange('deadlineMax', e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Difficulty Level</Label>
                    <div className="flex gap-3">
                      {['Easy', 'Medium', 'Hard'].map((difficulty) => (
                        <div key={difficulty} className="flex items-center space-x-2">
                          <Checkbox
                            id={`difficulty-${difficulty}`}
                            checked={filters.difficulty.includes(difficulty)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                handleFilterChange('difficulty', [...filters.difficulty, difficulty]);
                              } else {
                                handleFilterChange('difficulty', filters.difficulty.filter(d => d !== difficulty));
                              }
                            }}
                          />
                          <Label htmlFor={`difficulty-${difficulty}`}>{difficulty}</Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Grant Sources</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {sources.map((source) => (
                        <div key={source.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={`source-${source.id}`}
                            checked={filters.sources.includes(source.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                handleFilterChange('sources', [...filters.sources, source.id]);
                              } else {
                                handleFilterChange('sources', filters.sources.filter(s => s !== source.id));
                              }
                            }}
                          />
                          <Label htmlFor={`source-${source.id}`} className="text-sm">
                            {source.name}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="include-expired"
                      checked={filters.includeExpired}
                      onCheckedChange={(checked) => handleFilterChange('includeExpired', checked)}
                    />
                    <Label htmlFor="include-expired">Include expired grants</Label>
                  </div>
                </CollapsibleContent>
              </Collapsible>
            </CardContent>
          </Card>

          {/* Search Results */}
          <div className="grid gap-6 lg:grid-cols-4">
            <div className="lg:col-span-3">
              {/* Results Header */}
              {searchResult && (
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <h3 className="text-lg font-medium text-navy">
                      {searchResult.total} grants found
                    </h3>
                    {searchResult.suggestions && searchResult.suggestions.length > 0 && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-slate-600">Suggestions:</span>
                        {searchResult.suggestions.map((suggestion, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              handleFilterChange('keyword', suggestion);
                              handleSearch();
                            }}
                            className="text-xs"
                          >
                            {suggestion}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">Sort:</Label>
                    <Select value={`${filters.sortBy}-${filters.sortOrder}`} onValueChange={(value) => {
                      const [sortBy, sortOrder] = value.split('-');
                      handleFilterChange('sortBy', sortBy);
                      handleFilterChange('sortOrder', sortOrder);
                    }}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="relevance-desc">Relevance</SelectItem>
                        <SelectItem value="deadline-asc">Deadline (Soon first)</SelectItem>
                        <SelectItem value="deadline-desc">Deadline (Late first)</SelectItem>
                        <SelectItem value="amount-desc">Amount (High to Low)</SelectItem>
                        <SelectItem value="amount-asc">Amount (Low to High)</SelectItem>
                        <SelectItem value="updated-desc">Recently Updated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {/* Grant Cards */}
              {loading ? (
                <div className="grid gap-4">
                  {[...Array(6)].map((_, i) => (
                    <Card key={i} className="border-slate-200">
                      <CardContent className="p-6">
                        <div className="animate-pulse space-y-3">
                          <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                          <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                          <div className="h-3 bg-slate-200 rounded w-full"></div>
                          <div className="h-3 bg-slate-200 rounded w-2/3"></div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : grants.length > 0 ? (
                <div className="grid gap-4">
                  {grants.map((grant) => (
                    <GrantCard key={grant.id} grant={grant} />
                  ))}
                </div>
              ) : (
                <Card className="border-slate-200">
                  <CardContent className="p-12 text-center">
                    <Search className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-navy mb-2">
                      No grants found
                    </h3>
                    <p className="text-slate-600 mb-4">
                      Try adjusting your search criteria or clearing filters to see more results.
                    </p>
                    <Button onClick={clearFilters} variant="outline">
                      Clear All Filters
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-4">
              <SourceStatus />
              
              {/* Quick Actions */}
              <Card className="border-slate-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg font-space-grotesk text-navy">
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => onNavigate('kanban')}
                  >
                    <Zap className="h-4 w-4" />
                    View Grant Pipeline
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => setActiveTab('saved')}
                  >
                    <Bookmark className="h-4 w-4" />
                    View Saved Grants
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => onNavigate('alerts')}
                  >
                    <AlertCircle className="h-4 w-4" />
                    Set Up Alerts
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Saved Grants Tab */}
        <TabsContent value="saved">
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="text-lg font-space-grotesk text-navy">
                Saved Grants
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Bookmark className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-navy mb-2">
                  No saved grants yet
                </h3>
                <p className="text-slate-600 mb-4">
                  Save grants while searching to keep track of opportunities you're interested in.
                </p>
                <Button onClick={() => setActiveTab('search')}>
                  Start Searching
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sources Tab */}
        <TabsContent value="sources">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {sources.map((source) => (
              <Card key={source.id} className="border-slate-200">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-space-grotesk text-navy flex items-center gap-2">
                      {getSourceIcon(source.id)}
                      {source.name}
                    </CardTitle>
                    <Badge 
                      className={source.enabled 
                        ? 'bg-emerald text-white' 
                        : 'bg-slate-200 text-slate-700'
                      }
                    >
                      {source.enabled ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-slate-600">
                    {source.description}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {source.categories.map((category, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {category}
                      </Badge>
                    ))}
                  </div>
                  <div className="text-xs text-slate-500">
                    Last updated: {new Date(source.lastUpdated).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics">
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="text-lg font-space-grotesk text-navy">
                Search Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <TrendingUp className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-navy mb-2">
                  Analytics Coming Soon
                </h3>
                <p className="text-slate-600">
                  View insights about your search patterns, grant trends, and success rates.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Grant Detail Modal */}
      {selectedGrant && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl font-space-grotesk text-navy mb-2">
                    {selectedGrant.title}
                  </CardTitle>
                  <p className="text-slate-600">{selectedGrant.funder}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedGrant(null)}
                >
                  ×
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Amount</Label>
                  <p className="text-lg font-semibold text-navy">{selectedGrant.amount}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Deadline</Label>
                  <p className="text-lg font-semibold text-navy">
                    {new Date(selectedGrant.deadline).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Category</Label>
                  <p>{selectedGrant.category}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Location</Label>
                  <p>{selectedGrant.location}</p>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Description</Label>
                <p className="text-slate-700 mt-1">{selectedGrant.description}</p>
              </div>

              <div>
                <Label className="text-sm font-medium">Eligibility</Label>
                <ul className="list-disc list-inside mt-1 space-y-1">
                  {selectedGrant.eligibility.map((item, index) => (
                    <li key={index} className="text-slate-700">{item}</li>
                  ))}
                </ul>
              </div>

              <div>
                <Label className="text-sm font-medium">Sources</Label>
                <div className="mt-1 space-y-2">
                  {selectedGrant.sources.map((source, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-sky-50 rounded-md">
                      <div className="flex items-center gap-2">
                        {getSourceIcon(source.source)}
                        <span className="text-sm font-medium">{source.source}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-600">
                          Confidence: {Math.round(source.confidence * 100)}%
                        </span>
                        <Button size="sm" variant="outline" asChild>
                          <a href={source.sourceUrl} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  onClick={() => handleSaveGrant(selectedGrant)}
                  className="flex-1"
                  variant={selectedGrant.saved ? "outline" : "default"}
                >
                  {selectedGrant.saved ? (
                    <>
                      <BookmarkCheck className="h-4 w-4 mr-2" />
                      Saved
                    </>
                  ) : (
                    <>
                      <Bookmark className="h-4 w-4 mr-2" />
                      Save Grant
                    </>
                  )}
                </Button>
                <Button 
                  onClick={() => {
                    onNavigate('kanban');
                    setSelectedGrant(null);
                  }}
                  className="flex-1 bg-navy hover:bg-navy/90"
                >
                  Add to Pipeline
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}