import React, { useState, useRef } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Alert, AlertDescription } from '../ui/alert';
import { 
  Upload, 
  FileText, 
  Image, 
  File, 
  X, 
  Download, 
  Eye, 
  Loader2,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../../utils/supabase/client';

export interface DocumentFile {
  id: string;
  name: string;
  type: string;
  size: number;
  url?: string;
  uploadedAt: string;
  category: string;
  description?: string;
}

interface DocumentUploadProps {
  category: string;
  title: string;
  description?: string;
  acceptedTypes: string[];
  maxFileSize: number; // in MB
  maxFiles: number;
  existingFiles: DocumentFile[];
  onFilesChange: (files: DocumentFile[]) => void;
  disabled?: boolean;
  required?: boolean;
}

export function DocumentUpload({
  category,
  title,
  description,
  acceptedTypes,
  maxFileSize,
  maxFiles,
  existingFiles,
  onFilesChange,
  disabled = false,
  required = false
}: DocumentUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return Image;
    if (fileType.includes('pdf')) return FileText;
    return File;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const validateFile = (file: File): string | null => {
    // Check file type
    if (!acceptedTypes.some(type => {
      if (type.includes('*')) {
        const baseType = type.split('/')[0];
        return file.type.startsWith(baseType);
      }
      return file.type === type;
    })) {
      return `File type ${file.type} is not accepted`;
    }

    // Check file size
    if (file.size > maxFileSize * 1024 * 1024) {
      return `File size exceeds ${maxFileSize}MB limit`;
    }

    return null;
  };

  const handleFileUpload = async (files: FileList) => {
    setError(null);
    
    // Check total file count
    if (existingFiles.length + files.length > maxFiles) {
      setError(`Cannot upload more than ${maxFiles} files for this category`);
      return;
    }

    const validFiles: File[] = [];
    const errors: string[] = [];

    // Validate all files
    Array.from(files).forEach(file => {
      const validationError = validateFile(file);
      if (validationError) {
        errors.push(`${file.name}: ${validationError}`);
      } else {
        validFiles.push(file);
      }
    });

    if (errors.length > 0) {
      setError(errors.join(', '));
      return;
    }

    if (validFiles.length === 0) return;

    setUploading(true);
    setUploadProgress(0);

    try {
      const uploadedFiles: DocumentFile[] = [];
      
      for (let i = 0; i < validFiles.length; i++) {
        const file = validFiles[i];
        const formData = new FormData();
        formData.append('file', file);
        formData.append('category', category);
        
        const response = await apiRequest('/documents/upload', {
          method: 'POST',
          body: formData
        });

        if (response.success) {
          uploadedFiles.push({
            id: response.file.id,
            name: file.name,
            type: file.type,
            size: file.size,
            url: response.file.url,
            uploadedAt: new Date().toISOString(),
            category: category,
            description: response.file.description
          });
        }

        setUploadProgress(((i + 1) / validFiles.length) * 100);
      }

      onFilesChange([...existingFiles, ...uploadedFiles]);
      toast.success(`${uploadedFiles.length} file(s) uploaded successfully`);
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error: any) {
      console.error('Upload error:', error);
      setError(error.message || 'Failed to upload files');
      toast.error('Failed to upload files');
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (disabled) return;
    
    const files = e.dataTransfer.files;
    if (files?.length) {
      handleFileUpload(files);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files?.length) {
      handleFileUpload(files);
    }
  };

  const removeFile = async (fileId: string) => {
    try {
      await apiRequest(`/documents/${fileId}`, {
        method: 'DELETE'
      });
      
      const updatedFiles = existingFiles.filter(f => f.id !== fileId);
      onFilesChange(updatedFiles);
      toast.success('File removed successfully');
    } catch (error: any) {
      console.error('Error removing file:', error);
      toast.error('Failed to remove file');
    }
  };

  const downloadFile = async (file: DocumentFile) => {
    try {
      const response = await apiRequest(`/documents/${file.id}/download`);
      if (response.downloadUrl) {
        window.open(response.downloadUrl, '_blank');
      }
    } catch (error: any) {
      console.error('Error downloading file:', error);
      toast.error('Failed to download file');
    }
  };

  return (
    <Card className="border-slate-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-space-grotesk text-navy">
              {title}
              {required && <span className="text-red-500 ml-1">*</span>}
            </CardTitle>
            {description && (
              <p className="text-sm text-slate-600 mt-1">{description}</p>
            )}
          </div>
          <Badge variant="outline" className="text-xs">
            {existingFiles.length}/{maxFiles} files
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Upload Area */}
        <div
          className={`
            border-2 border-dashed rounded-lg p-6 text-center transition-colors
            ${dragActive ? 'border-indigo bg-sky-50' : 'border-slate-200'}
            ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:border-indigo hover:bg-sky-50'}
          `}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => !disabled && fileInputRef.current?.click()}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept={acceptedTypes.join(',')}
            onChange={handleFileInputChange}
            className="hidden"
            disabled={disabled}
          />
          
          <div className="space-y-2">
            <Upload className="h-8 w-8 text-slate-400 mx-auto" />
            <div>
              <p className="text-sm font-medium text-slate-700">
                Drop files here or click to browse
              </p>
              <p className="text-xs text-slate-500">
                Accepted types: {acceptedTypes.map(type => type.split('/')[1] || type).join(', ')} 
                • Max {maxFileSize}MB per file
              </p>
            </div>
          </div>
        </div>

        {/* Upload Progress */}
        {uploading && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin text-indigo" />
              <span className="text-sm text-slate-600">Uploading files...</span>
            </div>
            <Progress value={uploadProgress} className="h-2" />
          </div>
        )}

        {/* Error Display */}
        {error && (
          <Alert className="border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-700">
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Existing Files */}
        {existingFiles.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-slate-700">Uploaded Files</h4>
            <div className="space-y-2">
              {existingFiles.map((file) => {
                const FileIcon = getFileIcon(file.type);
                return (
                  <div
                    key={file.id}
                    className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200"
                  >
                    <FileIcon className="h-5 w-5 text-slate-600 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-700 truncate">
                        {file.name}
                      </p>
                      <p className="text-xs text-slate-500">
                        {formatFileSize(file.size)} • {new Date(file.uploadedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => downloadFile(file)}
                        className="h-8 w-8 p-0"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => removeFile(file.id)}
                        className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                        disabled={disabled}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}