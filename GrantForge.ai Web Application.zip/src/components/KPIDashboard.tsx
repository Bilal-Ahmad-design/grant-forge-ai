import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { UserAvatar } from './ui/user-avatar';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Clock, 
  Users, 
  Award, 
  Target, 
  FileText,
  Calendar,
  Download,
  Mail,
  Zap,
  BarChart3,
  PieChart as PieIcon,
  Activity,
  CheckCircle,
  AlertTriangle,
  Timer,
  Calculator,
  Send,
  Loader2,
  Upload,
  Database,
  Minus
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';
import { DataUploadDialog } from './DataUploadDialog';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

interface KPIDashboardProps {
  user: User;
}

interface KPIMetrics {
  winRate: number;
  avgProposalTime: number;
  totalRevenue: number;
  pipelineValue: number;
  activeGrants: number;
  completedGrants: number;
  billableHours: number;
  avgHoursPerGrant: number;
  clientSatisfaction: number;
  teamEfficiency: number;
}

interface HistoricalComparison {
  current: KPIMetrics;
  historical: KPIMetrics;
  hasHistoricalData: boolean;
}

interface WriterPerformance {
  id: string;
  name: string;
  role: string;
  grantsCompleted: number;
  billableHours: number;
  avgHoursPerGrant: number;
  winRate: number;
  revenue: number;
  efficiency: number;
  avatar?: string;
}

interface ClientMetrics {
  id: string;
  name: string;
  grantsSubmitted: number;
  grantsAwarded: number;
  totalRevenue: number;
  avgGrantSize: number;
  winRate: number;
  relationship: 'new' | 'ongoing' | 'returning';
}

interface TimeSeriesData {
  month: string;
  grants: number;
  revenue: number;
  winRate: number;
  avgTime: number;
  historical?: {
    grants: number;
    revenue: number;
    winRate: number;
    avgTime: number;
  };
}

export function KPIDashboard({ user }: KPIDashboardProps) {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedPeriod, setSelectedPeriod] = useState('last12months');
  const [selectedWriter, setSelectedWriter] = useState('all');
  const [selectedClient, setSelectedClient] = useState('all');
  const [generatingReport, setGeneratingReport] = useState(false);
  const [sendingReports, setSendingReports] = useState(false);
  const [selectedClientForReport, setSelectedClientForReport] = useState('');
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [showHistoricalComparison, setShowHistoricalComparison] = useState(false);

  // KPI Data with historical comparison
  const [kpiComparison, setKpiComparison] = useState<HistoricalComparison>({
    current: {
      winRate: 0,
      avgProposalTime: 0,
      totalRevenue: 0,
      pipelineValue: 0,
      activeGrants: 0,
      completedGrants: 0,
      billableHours: 0,
      avgHoursPerGrant: 0,
      clientSatisfaction: 0,
      teamEfficiency: 0
    },
    historical: {
      winRate: 0,
      avgProposalTime: 0,
      totalRevenue: 0,
      pipelineValue: 0,
      activeGrants: 0,
      completedGrants: 0,
      billableHours: 0,
      avgHoursPerGrant: 0,
      clientSatisfaction: 0,
      teamEfficiency: 0
    },
    hasHistoricalData: false
  });

  const [writerPerformance, setWriterPerformance] = useState<WriterPerformance[]>([]);
  const [clientMetrics, setClientMetrics] = useState<ClientMetrics[]>([]);
  const [timeSeriesData, setTimeSeriesData] = useState<TimeSeriesData[]>([]);

  useEffect(() => {
    loadKPIData();
  }, [user, selectedPeriod]);

  const loadKPIData = async () => {
    try {
      setLoading(true);
      
      const [kpiResponse, writerResponse, clientResponse, timeSeriesResponse, historicalResponse] = await Promise.all([
        apiRequest(`/analytics/kpi?period=${selectedPeriod}`),
        apiRequest(`/analytics/writers?period=${selectedPeriod}`),
        apiRequest(`/analytics/clients?period=${selectedPeriod}`),
        apiRequest(`/analytics/timeseries?period=${selectedPeriod}`),
        apiRequest(`/analytics/historical-comparison?period=${selectedPeriod}`)
      ]);

      // Enhanced KPI data based on user role
      const getKPIMetricsData = () => {
        if (user.role === 'admin') {
          // Comprehensive team-level metrics for admin users
          return {
            winRate: 82, // Improved from 75%
            avgProposalTime: 11.8, // Improved from 13.2 days
            totalRevenue: 5285000, // Increased from 4,035,000
            pipelineValue: 6800000, // Increased from 5,200,000
            activeGrants: 38, // Increased from 32
            completedGrants: 84, // Increased from 69
            billableHours: 5420, // Increased from 4,700
            avgHoursPerGrant: 64.5, // Improved efficiency from 68.1
            clientSatisfaction: 4.9, // Improved from 4.8
            teamEfficiency: 94 // Improved from 89
          };
        } else {
          // Standard metrics for other roles
          return {
            winRate: 76, // Improved from 68%
            avgProposalTime: 12.8, // Improved from 14.5 days
            totalRevenue: 3125000, // Increased from 2,450,000
            pipelineValue: 4150000, // Increased from 3,200,000
            activeGrants: 29, // Increased from 24
            completedGrants: 58, // Increased from 47
            billableHours: 3950, // Increased from 3,240
            avgHoursPerGrant: 65.2, // Improved efficiency from 68.9
            clientSatisfaction: 4.8, // Improved from 4.7
            teamEfficiency: 91 // Improved from 87
          };
        }
      };

      const mockCurrentKpiMetrics: KPIMetrics = getKPIMetricsData();

      // Enhanced historical data based on user role
      const getHistoricalKPIMetricsData = () => {
        if (user.role === 'admin') {
          // Historical team-level metrics for admin users
          return {
            winRate: 68,
            avgProposalTime: 15.8,
            totalRevenue: 3200000,
            pipelineValue: 4100000,
            activeGrants: 26,
            completedGrants: 54,
            billableHours: 3850,
            avgHoursPerGrant: 71.3,
            clientSatisfaction: 4.5,
            teamEfficiency: 82
          };
        } else {
          // Standard historical metrics for other roles
          return {
            winRate: 62,
            avgProposalTime: 16.8,
            totalRevenue: 2100000,
            pipelineValue: 2800000,
            activeGrants: 20,
            completedGrants: 38,
            billableHours: 2890,
            avgHoursPerGrant: 76.1,
            clientSatisfaction: 4.4,
            teamEfficiency: 79
          };
        }
      };

      const mockHistoricalKpiMetrics: KPIMetrics = getHistoricalKPIMetricsData();

      // Check if historical data exists (simulate checking uploaded data)
      const hasHistoricalData = localStorage.getItem('grantforge-historical-data') !== null;

      setKpiComparison({
        current: kpiResponse.metrics || mockCurrentKpiMetrics,
        historical: historicalResponse.metrics || mockHistoricalKpiMetrics,
        hasHistoricalData
      });

      // Enhanced team data with more comprehensive analytics for admin users
      const getTeamPerformanceData = () => {
        if (user.role === 'admin') {
          // Rich team analytics for admin users
          return [
            {
              id: 'writer1',
              name: 'Dr. Lisa Chen',
              role: 'Senior Writer',
              grantsCompleted: 19, // Increased
              billableHours: 1180, // Increased
              avgHoursPerGrant: 62.1, // Improved efficiency
              winRate: 89, // Improved from 83%
              revenue: 1125000, // Increased from 875K
              efficiency: 97, // Improved from 95
              avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            },
            {
              id: 'writer2',
              name: 'James Wilson',
              role: 'Junior Writer',
              grantsCompleted: 12, // Increased 
              billableHours: 850, // Increased
              avgHoursPerGrant: 70.8, // Improved efficiency
              winRate: 75, // Improved from 65%
              revenue: 585000, // Increased from 420K
              efficiency: 86, // Improved from 78
              avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            },
            {
              id: 'writer3',
              name: 'Maria Santos',
              role: 'Senior Writer',
              grantsCompleted: 24, // Increased significantly
              billableHours: 1420, // Increased
              avgHoursPerGrant: 59.2, // Improved efficiency
              winRate: 92, // Improved from 88%
              revenue: 1685000, // Increased from 1.25M
              efficiency: 98, // Improved from 97
              avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            },
            {
              id: 'writer4',
              name: 'David Thompson',
              role: 'Senior Writer',
              grantsCompleted: 16, // Increased
              billableHours: 950, // Increased
              avgHoursPerGrant: 59.4, // Improved efficiency
              winRate: 84, // Improved from 75%
              revenue: 925000, // Increased from 685K
              efficiency: 95, // Improved from 89
              avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            },
            {
              id: 'writer5',
              name: 'Emily Rodriguez',
              role: 'Junior Writer',
              grantsCompleted: 9, // Increased
              billableHours: 650, // Increased
              avgHoursPerGrant: 72.2, // Improved efficiency
              winRate: 72, // Improved from 58%
              revenue: 425000, // Increased from 285K
              efficiency: 84, // Improved from 74
              avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            },
            {
              id: 'writer6',
              name: 'Alex Martinez',
              role: 'Junior Writer',
              grantsCompleted: 14, // Increased
              billableHours: 920, // Increased
              avgHoursPerGrant: 65.7, // Improved efficiency
              winRate: 82, // Improved from 70%
              revenue: 745000, // Increased from 520K
              efficiency: 91, // Improved from 82
              avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            }
          ];
        } else {
          // Limited team view for other roles
          return [
            {
              id: 'writer1',
              name: 'Lisa Thompson',
              role: 'Senior Writer',
              grantsCompleted: 12,
              billableHours: 820,
              avgHoursPerGrant: 68.3,
              winRate: 75,
              revenue: 650000,
              efficiency: 92,
              avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            },
            {
              id: 'writer2',
              name: 'Alex Martinez',
              role: 'Junior Writer',
              grantsCompleted: 8,
              billableHours: 640,
              avgHoursPerGrant: 80.0,
              winRate: 62,
              revenue: 380000,
              efficiency: 78,
              avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            },
            {
              id: 'writer3',
              name: 'Maria Santos',
              role: 'Senior Writer',
              grantsCompleted: 15,
              billableHours: 950,
              avgHoursPerGrant: 63.3,
              winRate: 80,
              revenue: 820000,
              efficiency: 95,
              avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            },
            {
              id: 'writer4',
              name: 'David Chen',
              role: 'Junior Writer',
              grantsCompleted: 6,
              billableHours: 480,
              avgHoursPerGrant: 80.0,
              winRate: 50,
              revenue: 285000,
              efficiency: 72,
              avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=150&h=150&q=80'
            }
          ];
        }
      };

      const mockWriterPerformance: WriterPerformance[] = getTeamPerformanceData();

      // Enhanced client data for admin users
      const getClientMetricsData = () => {
        if (user.role === 'admin') {
          // Comprehensive client portfolio for admin users
          return [
            {
              id: 'client1',
              name: 'Roosevelt Elementary School',
              grantsSubmitted: 11, // Increased activity
              grantsAwarded: 10, // Increased awards
              totalRevenue: 1285000, // Increased from 875K
              avgGrantSize: 128500, // Improved grant size
              winRate: 91, // Improved from 88%
              relationship: 'returning'
            },
            {
              id: 'client2',
              name: 'Jefferson High School',
              grantsSubmitted: 9, // Increased activity
              grantsAwarded: 7, // Increased awards
              totalRevenue: 945000, // Increased from 620K
              avgGrantSize: 135000, // Better average
              winRate: 78, // Improved from 67%
              relationship: 'ongoing'
            },
            {
              id: 'client3',
              name: 'Lincoln Middle School',
              grantsSubmitted: 10, // Increased activity
              grantsAwarded: 9, // Increased awards
              totalRevenue: 1150000, // Increased from 785K
              avgGrantSize: 127778, // Good average maintained
              winRate: 90, // Improved from 86%
              relationship: 'returning'
            },
            {
              id: 'client4',
              name: 'Washington Elementary',
              grantsSubmitted: 4,
              grantsAwarded: 4,
              totalRevenue: 385000,
              avgGrantSize: 96250,
              winRate: 100,
              relationship: 'returning'
            },
            {
              id: 'client5',
              name: 'Madison Charter Academy',
              grantsSubmitted: 5,
              grantsAwarded: 3,
              totalRevenue: 420000,
              avgGrantSize: 140000,
              winRate: 60,
              relationship: 'ongoing'
            },
            {
              id: 'client6',
              name: 'Franklin STEM Institute',
              grantsSubmitted: 3,
              grantsAwarded: 3,
              totalRevenue: 485000,
              avgGrantSize: 161667,
              winRate: 100,
              relationship: 'new'
            },
            {
              id: 'client7',
              name: 'Oak Valley School District',
              grantsSubmitted: 6,
              grantsAwarded: 5,
              totalRevenue: 750000,
              avgGrantSize: 150000,
              winRate: 83,
              relationship: 'returning'
            }
          ];
        } else {
          // Standard client view for other roles
          return [
            {
              id: 'client1',
              name: 'Roosevelt Elementary School',
              grantsSubmitted: 5,
              grantsAwarded: 4,
              totalRevenue: 450000,
              avgGrantSize: 112500,
              winRate: 80,
              relationship: 'returning'
            },
            {
              id: 'client2',
              name: 'Jefferson High School',
              grantsSubmitted: 3,
              grantsAwarded: 2,
              totalRevenue: 285000,
              avgGrantSize: 142500,
              winRate: 67,
              relationship: 'ongoing'
            },
            {
              id: 'client3',
              name: 'Lincoln Middle School',
              grantsSubmitted: 4,
              grantsAwarded: 3,
              totalRevenue: 375000,
              avgGrantSize: 125000,
              winRate: 75,
              relationship: 'returning'
            },
            {
              id: 'client4',
              name: 'Washington Elementary',
              grantsSubmitted: 2,
              grantsAwarded: 2,
              totalRevenue: 195000,
              avgGrantSize: 97500,
              winRate: 100,
              relationship: 'new'
            }
          ];
        }
      };

      const mockClientMetrics: ClientMetrics[] = getClientMetricsData();

      // Enhanced time series data for admin users
      const getTimeSeriesData = () => {
        const baseData = user.role === 'admin' ? [
          { 
            month: 'Jan 2024', 
            grants: 6, 
            revenue: 485000, 
            winRate: 78, 
            avgTime: 14.8,
            historical: hasHistoricalData ? { grants: 5, revenue: 420000, winRate: 72, avgTime: 16.5 } : undefined
          },
          { 
            month: 'Feb 2024', 
            grants: 8, 
            revenue: 685000, 
            winRate: 71, 
            avgTime: 14.2,
            historical: hasHistoricalData ? { grants: 6, revenue: 540000, winRate: 65, avgTime: 16.0 } : undefined
          },
          { 
            month: 'Mar 2024', 
            grants: 7, 
            revenue: 595000, 
            winRate: 82, 
            avgTime: 13.5,
            historical: hasHistoricalData ? { grants: 7, revenue: 560000, winRate: 75, avgTime: 15.2 } : undefined
          },
          { 
            month: 'Apr 2024', 
            grants: 9, 
            revenue: 820000, 
            winRate: 75, 
            avgTime: 13.8,
            historical: hasHistoricalData ? { grants: 8, revenue: 720000, winRate: 68, avgTime: 15.8 } : undefined
          },
          { 
            month: 'May 2024', 
            grants: 11, 
            revenue: 925000, 
            winRate: 68, 
            avgTime: 12.9,
            historical: hasHistoricalData ? { grants: 9, revenue: 780000, winRate: 63, avgTime: 15.2 } : undefined
          },
          { 
            month: 'Jun 2024', 
            grants: 8, 
            revenue: 675000, 
            winRate: 88, 
            avgTime: 13.1,
            historical: hasHistoricalData ? { grants: 7, revenue: 590000, winRate: 80, avgTime: 14.5 } : undefined
          },
          { 
            month: 'Jul 2024', 
            grants: 12, 
            revenue: 1050000, 
            winRate: 80, 
            avgTime: 12.8,
            historical: hasHistoricalData ? { grants: 11, revenue: 890000, winRate: 73, avgTime: 14.0 } : undefined
          },
          { 
            month: 'Aug 2024', 
            grants: 10, 
            revenue: 885000, 
            winRate: 89, 
            avgTime: 11.9,
            historical: hasHistoricalData ? { grants: 8, revenue: 745000, winRate: 82, avgTime: 13.5 } : undefined
          },
          { 
            month: 'Sep 2024', 
            grants: 11, 
            revenue: 975000, 
            winRate: 78, 
            avgTime: 12.2,
            historical: hasHistoricalData ? { grants: 10, revenue: 850000, winRate: 71, avgTime: 13.8 } : undefined
          },
          { 
            month: 'Oct 2024', 
            grants: 13, 
            revenue: 1185000, 
            winRate: 73, 
            avgTime: 12.9,
            historical: hasHistoricalData ? { grants: 12, revenue: 1020000, winRate: 67, avgTime: 14.8 } : undefined
          },
          { 
            month: 'Nov 2024', 
            grants: 9, 
            revenue: 785000, 
            winRate: 70, 
            avgTime: 13.8,
            historical: hasHistoricalData ? { grants: 7, revenue: 650000, winRate: 65, avgTime: 15.5 } : undefined
          },
          { 
            month: 'Dec 2024', 
            grants: 7, 
            revenue: 615000, 
            winRate: 65, 
            avgTime: 14.5,
            historical: hasHistoricalData ? { grants: 6, revenue: 520000, winRate: 60, avgTime: 16.2 } : undefined
          }
        ] : [
          { 
            month: 'Jan 2024', 
            grants: 4, 
            revenue: 320000, 
            winRate: 75, 
            avgTime: 16.2,
            historical: hasHistoricalData ? { grants: 3, revenue: 285000, winRate: 67, avgTime: 18.5 } : undefined
          },
          { 
            month: 'Feb 2024', 
            grants: 6, 
            revenue: 485000, 
            winRate: 67, 
            avgTime: 15.8,
            historical: hasHistoricalData ? { grants: 4, revenue: 380000, winRate: 60, avgTime: 17.2 } : undefined
          },
          { 
            month: 'Mar 2024', 
            grants: 5, 
            revenue: 420000, 
            winRate: 80, 
            avgTime: 14.9,
            historical: hasHistoricalData ? { grants: 5, revenue: 395000, winRate: 70, avgTime: 16.8 } : undefined
          },
          { 
            month: 'Apr 2024', 
            grants: 7, 
            revenue: 590000, 
            winRate: 71, 
            avgTime: 15.3,
            historical: hasHistoricalData ? { grants: 6, revenue: 520000, winRate: 65, avgTime: 17.5 } : undefined
          },
          { 
            month: 'May 2024', 
            grants: 8, 
            revenue: 645000, 
            winRate: 62, 
            avgTime: 13.7,
            historical: hasHistoricalData ? { grants: 7, revenue: 580000, winRate: 58, avgTime: 16.9 } : undefined
          },
          { 
            month: 'Jun 2024', 
            grants: 6, 
            revenue: 478000, 
            winRate: 83, 
            avgTime: 14.1,
            historical: hasHistoricalData ? { grants: 5, revenue: 420000, winRate: 75, avgTime: 15.8 } : undefined
          },
          { 
            month: 'Jul 2024', 
            grants: 9, 
            revenue: 720000, 
            winRate: 78, 
            avgTime: 13.9,
            historical: hasHistoricalData ? { grants: 8, revenue: 650000, winRate: 70, avgTime: 15.2 } : undefined
          },
          { 
            month: 'Aug 2024', 
            grants: 7, 
            revenue: 615000, 
            winRate: 86, 
            avgTime: 12.8,
            historical: hasHistoricalData ? { grants: 6, revenue: 545000, winRate: 78, avgTime: 14.5 } : undefined
          },
          { 
            month: 'Sep 2024', 
            grants: 8, 
            revenue: 685000, 
            winRate: 75, 
            avgTime: 13.4,
            historical: hasHistoricalData ? { grants: 7, revenue: 620000, winRate: 68, avgTime: 15.1 } : undefined
          },
          { 
            month: 'Oct 2024', 
            grants: 10, 
            revenue: 825000, 
            winRate: 70, 
            avgTime: 14.2,
            historical: hasHistoricalData ? { grants: 9, revenue: 750000, winRate: 63, avgTime: 16.3 } : undefined
          },
          { 
            month: 'Nov 2024', 
            grants: 6, 
            revenue: 520000, 
            winRate: 67, 
            avgTime: 15.1,
            historical: hasHistoricalData ? { grants: 5, revenue: 485000, winRate: 60, avgTime: 17.8 } : undefined
          },
          { 
            month: 'Dec 2024', 
            grants: 5, 
            revenue: 385000, 
            winRate: 60, 
            avgTime: 16.8,
            historical: hasHistoricalData ? { grants: 4, revenue: 350000, winRate: 55, avgTime: 18.2 } : undefined
          }
        ];
        
        return baseData;
      };

      const mockTimeSeriesData: TimeSeriesData[] = getTimeSeriesData();

      setWriterPerformance(writerResponse.writers || mockWriterPerformance);
      setClientMetrics(clientResponse.clients || mockClientMetrics);
      setTimeSeriesData(timeSeriesResponse.data || mockTimeSeriesData);

    } catch (error) {
      console.error('Error loading KPI data:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const handleDataUploaded = () => {
    // Mark that historical data has been uploaded
    localStorage.setItem('grantforge-historical-data', 'true');
    setKpiComparison(prev => ({ ...prev, hasHistoricalData: true }));
    setShowHistoricalComparison(true);
    loadKPIData(); // Reload data to include historical comparison
    toast.success('Historical data integrated! Now comparing with current performance.');
  };

  const handleGenerateReport = async (type: 'monthly' | 'quarterly' | 'annual') => {
    try {
      setGeneratingReport(true);
      
      const response = await apiRequest('/reports/generate', {
        method: 'POST',
        body: JSON.stringify({
          type,
          period: selectedPeriod,
          includeCharts: true,
          includeClientBreakdown: true,
          includeHistoricalComparison: kpiComparison.hasHistoricalData
        })
      });

      if (response.reportUrl) {
        window.open(response.reportUrl, '_blank');
        toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} report generated successfully!`);
      }
    } catch (error: any) {
      console.error('Error generating report:', error);
      toast.error(error.message || 'Failed to generate report');
    } finally {
      setGeneratingReport(false);
    }
  };

  const handleSendClientReport = async (clientId: string) => {
    try {
      setSelectedClientForReport(clientId);
      setSendingReports(true);
      
      const client = clientMetrics.find(c => c.id === clientId);
      const response = await apiRequest('/reports/send-client', {
        method: 'POST',
        body: JSON.stringify({
          clientId,
          period: selectedPeriod,
          includeCharts: true
        })
      });

      if (response.success) {
        toast.success(`Report sent to ${client?.name} successfully!`);
      }
    } catch (error: any) {
      console.error('Error sending client report:', error);
      toast.success(`Report sent to ${clientMetrics.find(c => c.id === clientId)?.name}! (Demo mode)`);
    } finally {
      setSendingReports(false);
      setSelectedClientForReport('');
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`;
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`;
    }
    return `$${amount.toLocaleString()}`;
  };

  const calculatePercentageChange = (current: number, historical: number) => {
    if (historical === 0) return 0;
    return ((current - historical) / historical) * 100;
  };

  const getPerformanceColor = (value: number, threshold: number = 70) => {
    if (value >= threshold + 10) return 'text-emerald';
    if (value >= threshold) return 'text-amber';
    return 'text-red-500';
  };

  const getChangeIcon = (change: number) => {
    if (change > 0) return <TrendingUp className="h-3 w-3 text-emerald" />;
    if (change < 0) return <TrendingDown className="h-3 w-3 text-red-500" />;
    return <Minus className="h-3 w-3 text-slate-400" />;
  };

  const getChangeText = (change: number, isTime: boolean = false) => {
    const prefix = change > 0 ? '+' : '';
    const suffix = isTime ? (change > 0 ? ' days vs historical' : ' days vs historical') : '% vs historical';
    const colorClass = isTime ? 
      (change > 0 ? 'text-red-500' : 'text-emerald') : 
      (change > 0 ? 'text-emerald' : 'text-red-500');
    
    return (
      <span className={`text-xs ${colorClass}`}>
        {prefix}{isTime ? change.toFixed(1) : change.toFixed(1)}{suffix}
      </span>
    );
  };

  const getRelationshipBadge = (relationship: string) => {
    const colors = {
      'new': 'bg-emerald text-white',
      'ongoing': 'bg-indigo text-white',
      'returning': 'bg-amber text-navy'
    };
    return colors[relationship as keyof typeof colors] || 'bg-slate-500 text-white';
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center min-h-96">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-indigo mx-auto mb-4" />
            <p className="text-slate-600">Loading KPI dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">KPI Dashboard</h1>
          <p className="text-slate-600">
            {user.role === 'admin' 
              ? 'Comprehensive team performance metrics and automated reporting'
              : 'Performance metrics and automated reporting'
            }
          </p>
          {user.role === 'admin' && (
            <p className="text-sm text-indigo mt-1">
              Viewing district-level analytics for {user.organization}
            </p>
          )}
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last30days">Last 30 Days</SelectItem>
              <SelectItem value="last3months">Last 3 Months</SelectItem>
              <SelectItem value="last6months">Last 6 Months</SelectItem>
              <SelectItem value="last12months">Last 12 Months</SelectItem>
              <SelectItem value="thisyear">This Year</SelectItem>
              <SelectItem value="lastyear">Last Year</SelectItem>
            </SelectContent>
          </Select>
          
          {kpiComparison.hasHistoricalData && (
            <Button
              variant="outline"
              onClick={() => setShowHistoricalComparison(!showHistoricalComparison)}
              className="gap-2"
            >
              <Database className="h-4 w-4" />
              {showHistoricalComparison ? 'Hide' : 'Show'} Historical
            </Button>
          )}
          
          <Button 
            onClick={() => setUploadDialogOpen(true)}
            className="gap-2 bg-indigo hover:bg-indigo/90"
          >
            <Upload className="h-4 w-4" />
            Upload Past Data
          </Button>
        </div>
      </div>

      {/* Historical Data Banner */}
      {kpiComparison.hasHistoricalData && (
        <Card className="border-emerald/20 bg-emerald/5">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-emerald" />
              <div>
                <h3 className="font-medium text-emerald-800">Historical Data Active</h3>
                <p className="text-sm text-emerald-700">
                  Performance metrics now include comparison with uploaded historical data. 
                  Toggle the "Show Historical" button to view comparisons.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-emerald/20 bg-emerald/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Win Rate</p>
                <p className={`text-2xl font-bold ${getPerformanceColor(kpiComparison.current.winRate)}`}>
                  {kpiComparison.current.winRate}%
                </p>
                <div className="flex items-center gap-1 mt-1">
                  {kpiComparison.hasHistoricalData && showHistoricalComparison ? (
                    <>
                      {getChangeIcon(calculatePercentageChange(kpiComparison.current.winRate, kpiComparison.historical.winRate))}
                      {getChangeText(calculatePercentageChange(kpiComparison.current.winRate, kpiComparison.historical.winRate))}
                    </>
                  ) : (
                    <>
                      <TrendingUp className="h-3 w-3 text-emerald" />
                      <span className="text-xs text-emerald">+5.2% vs last period</span>
                    </>
                  )}
                </div>
              </div>
              <Award className="h-8 w-8 text-emerald" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-indigo/20 bg-indigo/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Avg Proposal Time</p>
                <p className="text-2xl font-bold text-indigo">
                  {kpiComparison.current.avgProposalTime} days
                </p>
                <div className="flex items-center gap-1 mt-1">
                  {kpiComparison.hasHistoricalData && showHistoricalComparison ? (
                    <>
                      {getChangeIcon(-(kpiComparison.current.avgProposalTime - kpiComparison.historical.avgProposalTime))}
                      {getChangeText(kpiComparison.current.avgProposalTime - kpiComparison.historical.avgProposalTime, true)}
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-3 w-3 text-emerald" />
                      <span className="text-xs text-emerald">-1.8 days vs last period</span>
                    </>
                  )}
                </div>
              </div>
              <Clock className="h-8 w-8 text-indigo" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-amber/20 bg-amber/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Revenue</p>
                <p className="text-2xl font-bold text-amber">
                  {formatCurrency(kpiComparison.current.totalRevenue)}
                </p>
                <div className="flex items-center gap-1 mt-1">
                  {kpiComparison.hasHistoricalData && showHistoricalComparison ? (
                    <>
                      {getChangeIcon(calculatePercentageChange(kpiComparison.current.totalRevenue, kpiComparison.historical.totalRevenue))}
                      {getChangeText(calculatePercentageChange(kpiComparison.current.totalRevenue, kpiComparison.historical.totalRevenue))}
                    </>
                  ) : (
                    <>
                      <TrendingUp className="h-3 w-3 text-emerald" />
                      <span className="text-xs text-emerald">+12.4% vs last period</span>
                    </>
                  )}
                </div>
              </div>
              <DollarSign className="h-8 w-8 text-amber" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Team Efficiency</p>
                <p className={`text-2xl font-bold ${getPerformanceColor(kpiComparison.current.teamEfficiency)}`}>
                  {kpiComparison.current.teamEfficiency}%
                </p>
                <div className="flex items-center gap-1 mt-1">
                  {kpiComparison.hasHistoricalData && showHistoricalComparison ? (
                    <>
                      {getChangeIcon(calculatePercentageChange(kpiComparison.current.teamEfficiency, kpiComparison.historical.teamEfficiency))}
                      {getChangeText(calculatePercentageChange(kpiComparison.current.teamEfficiency, kpiComparison.historical.teamEfficiency))}
                    </>
                  ) : (
                    <>
                      <TrendingUp className="h-3 w-3 text-emerald" />
                      <span className="text-xs text-emerald">+3.1% vs last period</span>
                    </>
                  )}
                </div>
              </div>
              <Activity className="h-8 w-8 text-slate-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="writers">Writer Performance</TabsTrigger>
          <TabsTrigger value="clients">Client Metrics</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue Trend Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Revenue Trend
                  {kpiComparison.hasHistoricalData && showHistoricalComparison && (
                    <Badge variant="outline" className="ml-2">vs Historical</Badge>
                  )}
                </CardTitle>
                <CardDescription>
                  {kpiComparison.hasHistoricalData && showHistoricalComparison ? 
                    'Current revenue vs historical performance' : 
                    'Monthly revenue over time'
                  }
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={timeSeriesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis tickFormatter={(value) => formatCurrency(value)} />
                    <Tooltip formatter={(value: any, name: string) => [
                      formatCurrency(value), 
                      name === 'revenue' ? 'Current Revenue' : 'Historical Revenue'
                    ]} />
                    {kpiComparison.hasHistoricalData && showHistoricalComparison && (
                      <Legend />
                    )}
                    <Area 
                      type="monotone" 
                      dataKey="revenue" 
                      stroke="#2B5EA5" 
                      fill="#2B5EA5" 
                      fillOpacity={0.3}
                      name="Current Revenue" 
                    />
                    {kpiComparison.hasHistoricalData && showHistoricalComparison && (
                      <Area 
                        type="monotone" 
                        dataKey="historical.revenue" 
                        stroke="#94A3B8" 
                        fill="#94A3B8" 
                        fillOpacity={0.2}
                        name="Historical Revenue" 
                      />
                    )}
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Win Rate Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Win Rate Trend
                  {kpiComparison.hasHistoricalData && showHistoricalComparison && (
                    <Badge variant="outline" className="ml-2">vs Historical</Badge>
                  )}
                </CardTitle>
                <CardDescription>
                  {kpiComparison.hasHistoricalData && showHistoricalComparison ? 
                    'Current win rate vs historical performance' : 
                    'Monthly win rate percentage'
                  }
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={timeSeriesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[0, 100]} tickFormatter={(value) => `${value}%`} />
                    <Tooltip formatter={(value: any, name: string) => [
                      `${value}%`, 
                      name === 'winRate' ? 'Current Win Rate' : 'Historical Win Rate'
                    ]} />
                    {kpiComparison.hasHistoricalData && showHistoricalComparison && (
                      <Legend />
                    )}
                    <Line 
                      type="monotone" 
                      dataKey="winRate" 
                      stroke="#2BB673" 
                      strokeWidth={3}
                      name="Current Win Rate" 
                    />
                    {kpiComparison.hasHistoricalData && showHistoricalComparison && (
                      <Line 
                        type="monotone" 
                        dataKey="historical.winRate" 
                        stroke="#94A3B8" 
                        strokeWidth={2}
                        strokeDasharray="5 5"
                        name="Historical Win Rate" 
                      />
                    )}
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Additional Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Grant Pipeline
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Active Grants</span>
                  <span className="font-medium">{kpiComparison.current.activeGrants}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Completed</span>
                  <span className="font-medium">{kpiComparison.current.completedGrants}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Pipeline Value</span>
                  <span className="font-medium text-emerald">{formatCurrency(kpiComparison.current.pipelineValue)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Timer className="h-5 w-5" />
                  Time Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Billable Hours</span>
                  <span className="font-medium">{kpiComparison.current.billableHours.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Avg Hours/Grant</span>
                  <span className="font-medium">{kpiComparison.current.avgHoursPerGrant}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Efficiency Rate</span>
                  <span className={`font-medium ${getPerformanceColor(kpiComparison.current.teamEfficiency)}`}>
                    {kpiComparison.current.teamEfficiency}%
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  Quality Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Client Satisfaction</span>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{kpiComparison.current.clientSatisfaction}/5.0</span>
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <span 
                          key={star}
                          className={star <= kpiComparison.current.clientSatisfaction ? 'text-amber' : 'text-slate-300'}
                        >
                          ★
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Avg Proposal Time</span>
                  <span className="font-medium">{kpiComparison.current.avgProposalTime} days</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Win Rate</span>
                  <span className={`font-medium ${getPerformanceColor(kpiComparison.current.winRate)}`}>
                    {kpiComparison.current.winRate}%
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="writers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Writer Performance Metrics</CardTitle>
              <CardDescription>Individual writer statistics and efficiency</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {writerPerformance.map((writer) => (
                  <div key={writer.id} className="border border-slate-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <UserAvatar
                          src={writer.avatar}
                          name={writer.name}
                          size="md"
                        />
                        <div>
                          <h4 className="font-medium text-navy">{writer.name}</h4>
                          <p className="text-sm text-slate-600">{writer.role}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-emerald">{formatCurrency(writer.revenue)}</p>
                        <p className="text-sm text-slate-600">Revenue generated</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-slate-500">Grants Completed</p>
                        <p className="font-medium">{writer.grantsCompleted}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Billable Hours</p>
                        <p className="font-medium">{writer.billableHours}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Avg Hours/Grant</p>
                        <p className="font-medium">{writer.avgHoursPerGrant}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Win Rate</p>
                        <p className={`font-medium ${getPerformanceColor(writer.winRate)}`}>
                          {writer.winRate}%
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Efficiency</p>
                        <p className={`font-medium ${getPerformanceColor(writer.efficiency)}`}>
                          {writer.efficiency}%
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Performance Score</span>
                        <span>{writer.efficiency}%</span>
                      </div>
                      <Progress value={writer.efficiency} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="clients" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Client Performance Metrics</CardTitle>
              <CardDescription>Client success rates and relationship status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {clientMetrics.map((client) => (
                  <div key={client.id} className="border border-slate-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-medium text-navy">{client.name}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className={getRelationshipBadge(client.relationship)}>
                            {client.relationship}
                          </Badge>
                          <span className="text-sm text-slate-600">
                            {client.winRate}% win rate
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-emerald">{formatCurrency(client.totalRevenue)}</p>
                        <p className="text-sm text-slate-600">Total revenue</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-slate-500">Grants Submitted</p>
                        <p className="font-medium">{client.grantsSubmitted}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Grants Awarded</p>
                        <p className="font-medium text-emerald">{client.grantsAwarded}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Avg Grant Size</p>
                        <p className="font-medium">{formatCurrency(client.avgGrantSize)}</p>
                      </div>
                      <div className="flex justify-end">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleSendClientReport(client.id)}
                          disabled={sendingReports}
                          className="gap-2"
                        >
                          {sendingReports && selectedClientForReport === client.id ? (
                            <>
                              <Loader2 className="h-3 w-3 animate-spin" />
                              Sending...
                            </>
                          ) : (
                            <>
                              <Send className="h-3 w-3" />
                              Send Report
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5" />
                  Generate Reports
                </CardTitle>
                <CardDescription>
                  Download comprehensive analytics reports
                  {kpiComparison.hasHistoricalData && ' (includes historical comparison)'}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={() => handleGenerateReport('monthly')}
                  disabled={generatingReport}
                  className="w-full justify-start gap-2"
                  variant="outline"
                >
                  <Calendar className="h-4 w-4" />
                  Monthly Report
                </Button>
                <Button
                  onClick={() => handleGenerateReport('quarterly')}
                  disabled={generatingReport}
                  className="w-full justify-start gap-2"
                  variant="outline"
                >
                  <BarChart3 className="h-4 w-4" />
                  Quarterly Report
                </Button>
                <Button
                  onClick={() => handleGenerateReport('annual')}
                  disabled={generatingReport}
                  className="w-full justify-start gap-2"
                  variant="outline"
                >
                  <PieIcon className="h-4 w-4" />
                  Annual Report
                </Button>
                {generatingReport && (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Generating report...
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  Automated Reporting
                </CardTitle>
                <CardDescription>
                  Configure automatic report delivery
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border border-slate-200 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">Weekly Summary</p>
                      <p className="text-xs text-slate-600">Every Monday at 9 AM</p>
                    </div>
                    <Badge className="bg-emerald text-white">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border border-slate-200 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">Monthly Analytics</p>
                      <p className="text-xs text-slate-600">1st of each month</p>
                    </div>
                    <Badge className="bg-emerald text-white">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border border-slate-200 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">Client Reports</p>
                      <p className="text-xs text-slate-600">Quarterly to stakeholders</p>
                    </div>
                    <Badge variant="outline">Configured</Badge>
                  </div>
                </div>
                <Button className="w-full gap-2" variant="outline">
                  <Zap className="h-4 w-4" />
                  Configure Automation
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Data Upload Dialog */}
      <DataUploadDialog
        user={user}
        onDataUploaded={handleDataUploaded}
        open={uploadDialogOpen}
        onOpenChange={setUploadDialogOpen}
      />
    </div>
  );
}