import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Plus, 
  Users, 
  Mail, 
  Building, 
  Calendar, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  FileText,
  Eye,
  Send,
  Loader2,
  ExternalLink,
  Download,
  Edit,
  Trash2,
  Search,
  Save
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

interface Client {
  id: string;
  name: string;
  email: string;
  district: string;
  phone?: string;
  title?: string;
  status: 'active' | 'pending' | 'inactive';
  created_at: string;
  updated_at: string;
  created_by: string;
  intake_form_sent: boolean;
  intake_form_completed: boolean;
  intake_form_completed_at?: string;
  intake_form_url?: string;
  notes?: string;
  projects_count?: number;
  total_funding?: number;
}

interface IntakeInvitation {
  client_id: string;
  client_name: string;
  client_email: string;
  sent_at: string;
  completed: boolean;
  completed_at?: string;
  form_data?: any;
}

interface ClientManagementProps {
  user: User;
}

export function ClientManagement({ user }: ClientManagementProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [clients, setClients] = useState<Client[]>([]);
  const [intakeInvitations, setIntakeInvitations] = useState<IntakeInvitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [addClientDialogOpen, setAddClientDialogOpen] = useState(false);
  const [viewIntakeDialogOpen, setViewIntakeDialogOpen] = useState(false);
  const [selectedIntake, setSelectedIntake] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);

  // New client form state
  const [newClient, setNewClient] = useState({
    name: '',
    email: '',
    district: '',
    phone: '',
    title: '',
    notes: ''
  });

  useEffect(() => {
    loadClientsData();
  }, []);

  const loadClientsData = async () => {
    try {
      setLoading(true);
      
      // Load clients and intake data
      const [clientsResponse, intakeResponse] = await Promise.all([
        apiRequest('/clients/managed'),
        apiRequest('/clients/intake-invitations')
      ]);

      // For demo purposes, create some mock data if none exists
      const mockClients: Client[] = [
        {
          id: 'client1',
          name: 'Roosevelt Elementary School',
          email: 'principal@roosevelt-elem.edu',
          district: 'Metro City School District',
          phone: '(555) 123-4567',
          title: 'Principal',
          status: 'active',
          created_at: '2024-01-15T10:00:00Z',
          updated_at: '2024-01-15T10:00:00Z',
          created_by: user.id,
          intake_form_sent: true,
          intake_form_completed: true,
          intake_form_completed_at: '2024-01-16T14:30:00Z',
          projects_count: 3,
          total_funding: 450000,
          notes: 'High priority client with strong track record'
        },
        {
          id: 'client2',
          name: 'Jefferson High School',
          email: 'superintendent@jefferson.edu',
          district: 'Springfield School District',
          phone: '(555) 987-6543',
          title: 'Superintendent',
          status: 'pending',
          created_at: '2024-01-20T09:00:00Z',
          updated_at: '2024-01-20T09:00:00Z',
          created_by: user.id,
          intake_form_sent: true,
          intake_form_completed: false,
          projects_count: 0,
          total_funding: 0,
          notes: 'New client, intake form sent pending completion'
        },
        {
          id: 'client3',
          name: 'Lincoln Middle School',
          email: 'admin@lincoln-middle.edu',
          district: 'Riverside School District',
          status: 'active',
          created_at: '2024-01-10T11:30:00Z',
          updated_at: '2024-01-10T11:30:00Z',
          created_by: user.id,
          intake_form_sent: false,
          intake_form_completed: false,
          projects_count: 1,
          total_funding: 125000
        }
      ];

      const mockIntakeInvitations: IntakeInvitation[] = [
        {
          client_id: 'client1',
          client_name: 'Roosevelt Elementary School',
          client_email: 'principal@roosevelt-elem.edu',
          sent_at: '2024-01-15T10:30:00Z',
          completed: true,
          completed_at: '2024-01-16T14:30:00Z',
          form_data: {
            districtSize: 'Medium (1,000-5,000 students)',
            currentChallenges: ['Funding shortfalls', 'Technology gaps', 'Infrastructure needs'],
            grantExperience: 'Some experience',
            fundingPriorities: ['STEM programs', 'Special education', 'Technology upgrades'],
            timeline: 'Within 6 months'
          }
        },
        {
          client_id: 'client2',
          client_name: 'Jefferson High School',
          client_email: 'superintendent@jefferson.edu',
          sent_at: '2024-01-20T09:15:00Z',
          completed: false
        }
      ];

      setClients(clientsResponse.clients?.length ? clientsResponse.clients : mockClients);
      setIntakeInvitations(intakeResponse.invitations?.length ? intakeResponse.invitations : mockIntakeInvitations);

    } catch (error) {
      console.error('Error loading clients data:', error);
      
      // Use mock data as fallback
      const mockClients: Client[] = [
        {
          id: 'client1',
          name: 'Roosevelt Elementary School',
          email: 'principal@roosevelt-elem.edu',
          district: 'Metro City School District',
          phone: '(555) 123-4567',
          title: 'Principal',
          status: 'active',
          created_at: '2024-01-15T10:00:00Z',
          updated_at: '2024-01-15T10:00:00Z',
          created_by: user.id,
          intake_form_sent: true,
          intake_form_completed: true,
          intake_form_completed_at: '2024-01-16T14:30:00Z',
          projects_count: 3,
          total_funding: 450000,
          notes: 'High priority client with strong track record'
        },
        {
          id: 'client2',
          name: 'Jefferson High School',
          email: 'superintendent@jefferson.edu',
          district: 'Springfield School District',
          phone: '(555) 987-6543',
          title: 'Superintendent',
          status: 'pending',
          created_at: '2024-01-20T09:00:00Z',
          updated_at: '2024-01-20T09:00:00Z',
          created_by: user.id,
          intake_form_sent: true,
          intake_form_completed: false,
          projects_count: 0,
          total_funding: 0,
          notes: 'New client, intake form sent pending completion'
        }
      ];

      setClients(mockClients);
      toast.error('Failed to load clients data, using demo data');
    } finally {
      setLoading(false);
    }
  };

  const handleAddClient = async () => {
    if (!newClient.name || !newClient.email || !newClient.district) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      setSubmitting(true);
      
      const response = await apiRequest('/clients/managed', {
        method: 'POST',
        body: JSON.stringify(newClient)
      });

      if (response.client) {
        toast.success('Client added successfully!');
        setAddClientDialogOpen(false);
        setNewClient({ name: '', email: '', district: '', phone: '', title: '', notes: '' });
        loadClientsData();
      }
    } catch (error: any) {
      console.error('Error adding client:', error);
      toast.error(error.message || 'Failed to add client');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSendIntakeForm = async (client: Client) => {
    try {
      setSubmitting(true);
      
      const response = await apiRequest('/clients/send-intake-invitation', {
        method: 'POST',
        body: JSON.stringify({
          client_id: client.id,
          client_name: client.name,
          client_email: client.email
        })
      });

      if (response.success) {
        toast.success(`Intake form sent to ${client.name}!`);
        loadClientsData();
      }
    } catch (error: any) {
      console.error('Error sending intake form:', error);
      toast.error(error.message || 'Failed to send intake form');
    } finally {
      setSubmitting(false);
    }
  };

  const handleViewIntake = async (clientId: string) => {
    const invitation = intakeInvitations.find(inv => inv.client_id === clientId && inv.completed);
    if (invitation) {
      setSelectedIntake(invitation);
      setViewIntakeDialogOpen(true);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-emerald text-white';
      case 'pending': return 'bg-amber text-navy';
      case 'inactive': return 'bg-slate-500 text-white';
      default: return 'bg-slate-200 text-slate-700';
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`;
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`;
    }
    return `$${amount.toLocaleString()}`;
  };

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.district.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    totalClients: clients.length,
    activeClients: clients.filter(c => c.status === 'active').length,
    pendingIntake: clients.filter(c => !c.intake_form_completed).length,
    completedIntake: clients.filter(c => c.intake_form_completed).length,
    totalFunding: clients.reduce((sum, c) => sum + (c.total_funding || 0), 0)
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center min-h-96">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-indigo mx-auto mb-4" />
            <p className="text-slate-600">Loading client management...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">Client Management</h1>
          <p className="text-slate-600">Manage client relationships and intake forms</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-indigo text-white">
            {filteredClients.length} clients
          </Badge>
          <Dialog open={addClientDialogOpen} onOpenChange={setAddClientDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-navy hover:bg-indigo gap-2">
                <Plus className="h-4 w-4" />
                Add Client
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Client</DialogTitle>
                <DialogDescription>
                  Enter client details to add them to your client management system.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Contact Name *</Label>
                    <Input
                      id="name"
                      value={newClient.name}
                      onChange={(e) => setNewClient(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="John Smith"
                      className="bg-sky-50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={newClient.title}
                      onChange={(e) => setNewClient(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Principal"
                      className="bg-sky-50"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newClient.email}
                    onChange={(e) => setNewClient(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="john.smith@district.edu"
                    className="bg-sky-50"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="district">School District *</Label>
                  <Input
                    id="district"
                    value={newClient.district}
                    onChange={(e) => setNewClient(prev => ({ ...prev, district: e.target.value }))}
                    placeholder="Springfield School District"
                    className="bg-sky-50"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    value={newClient.phone}
                    onChange={(e) => setNewClient(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="(555) 123-4567"
                    className="bg-sky-50"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={newClient.notes}
                    onChange={(e) => setNewClient(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="Additional notes about this client..."
                    className="bg-sky-50 min-h-20"
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    onClick={handleAddClient}
                    disabled={submitting || !newClient.name || !newClient.email || !newClient.district}
                    className="flex-1"
                  >
                    {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Add Client'}
                  </Button>
                  <Button variant="outline" onClick={() => setAddClientDialogOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Clients</p>
                <p className="text-2xl font-bold text-navy">{stats.totalClients}</p>
              </div>
              <Users className="h-8 w-8 text-indigo" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Active Clients</p>
                <p className="text-2xl font-bold text-emerald">{stats.activeClients}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-emerald" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Pending Intake</p>
                <p className="text-2xl font-bold text-amber">{stats.pendingIntake}</p>
              </div>
              <Clock className="h-8 w-8 text-amber" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Completed Intake</p>
                <p className="text-2xl font-bold text-indigo">{stats.completedIntake}</p>
              </div>
              <FileText className="h-8 w-8 text-indigo" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Funding</p>
                <p className="text-2xl font-bold text-emerald">{formatCurrency(stats.totalFunding)}</p>
              </div>
              <Building className="h-8 w-8 text-emerald" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Client Overview</TabsTrigger>
          <TabsTrigger value="intake">Intake Forms</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Search */}
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-600" />
              <Input
                placeholder="Search clients..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-sky-50"
              />
            </div>
          </div>

          {/* Clients Grid */}
          <div className="grid gap-6">
            {filteredClients.map((client) => (
              <Card key={client.id} className="border-slate-200 hover:border-indigo transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-space-grotesk text-lg text-navy">{client.name}</h3>
                        <Badge className={getStatusColor(client.status)}>
                          {client.status.charAt(0).toUpperCase() + client.status.slice(1)}
                        </Badge>
                      </div>
                      <p className="text-slate-600 mb-1">{client.district}</p>
                      <p className="text-sm text-slate-500">{client.email}</p>
                      {client.phone && (
                        <p className="text-sm text-slate-500">{client.phone}</p>
                      )}
                    </div>
                    
                    <div className="flex flex-col items-end gap-2">
                      <div className="text-right">
                        <p className="text-sm text-slate-600">Projects: {client.projects_count || 0}</p>
                        {client.total_funding && client.total_funding > 0 && (
                          <p className="text-sm font-medium text-emerald">{formatCurrency(client.total_funding)} secured</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Intake Status */}
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg mb-4">
                    <div className="flex items-center gap-2">
                      {client.intake_form_completed ? (
                        <>
                          <CheckCircle className="h-4 w-4 text-emerald" />
                          <span className="text-sm text-emerald">Intake form completed</span>
                          <span className="text-xs text-slate-500">
                            {client.intake_form_completed_at && 
                              new Date(client.intake_form_completed_at).toLocaleDateString()
                            }
                          </span>
                        </>
                      ) : client.intake_form_sent ? (
                        <>
                          <Clock className="h-4 w-4 text-amber" />
                          <span className="text-sm text-amber">Intake form sent, awaiting completion</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="h-4 w-4 text-slate-500" />
                          <span className="text-sm text-slate-500">Intake form not sent</span>
                        </>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                      {client.intake_form_completed && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-3 text-xs gap-1"
                          onClick={() => handleViewIntake(client.id)}
                        >
                          <Eye className="h-3 w-3" />
                          View
                        </Button>
                      )}
                      
                      {!client.intake_form_sent && (
                        <Button
                          size="sm"
                          className="h-7 px-3 text-xs gap-1 bg-indigo hover:bg-indigo/90"
                          onClick={() => handleSendIntakeForm(client)}
                          disabled={submitting}
                        >
                          {submitting ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <>
                              <Send className="h-3 w-3" />
                              Send Form
                            </>
                          )}
                        </Button>
                      )}
                      
                      {client.intake_form_sent && !client.intake_form_completed && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-3 text-xs gap-1"
                          onClick={() => handleSendIntakeForm(client)}
                          disabled={submitting}
                        >
                          {submitting ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <>
                              <Send className="h-3 w-3" />
                              Resend
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Notes */}
                  {client.notes && (
                    <div className="border-t border-slate-200 pt-3">
                      <p className="text-sm text-slate-600">
                        <span className="font-medium">Notes:</span> {client.notes}
                      </p>
                    </div>
                  )}

                  {/* Footer */}
                  <div className="flex items-center justify-between text-xs text-slate-500 mt-4 pt-3 border-t border-slate-100">
                    <span>Added {new Date(client.created_at).toLocaleDateString()}</span>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 px-2 text-xs"
                        onClick={() => setSelectedClient(client)}
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {filteredClients.length === 0 && (
              <Card className="border-slate-200">
                <CardContent className="py-12 text-center">
                  <Users className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="font-space-grotesk text-lg mb-2">No clients found</h3>
                  <p className="text-slate-600 mb-4">
                    {searchTerm ? 'Try adjusting your search terms.' : 'Get started by adding your first client.'}
                  </p>
                  {!searchTerm && (
                    <Button onClick={() => setAddClientDialogOpen(true)}>
                      Add First Client
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="intake" className="space-y-6">
          <div className="grid gap-6">
            {intakeInvitations.map((invitation) => (
              <Card key={invitation.client_id} className="border-slate-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-space-grotesk text-lg text-navy mb-1">{invitation.client_name}</h3>
                      <p className="text-slate-600 mb-2">{invitation.client_email}</p>
                      <p className="text-sm text-slate-500">
                        Sent: {new Date(invitation.sent_at).toLocaleDateString()}
                      </p>
                      {invitation.completed_at && (
                        <p className="text-sm text-emerald">
                          Completed: {new Date(invitation.completed_at).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Badge className={invitation.completed ? 'bg-emerald text-white' : 'bg-amber text-navy'}>
                        {invitation.completed ? 'Completed' : 'Pending'}
                      </Badge>
                      
                      {invitation.completed && (
                        <Button
                          size="sm"
                          onClick={() => {
                            setSelectedIntake(invitation);
                            setViewIntakeDialogOpen(true);
                          }}
                          className="gap-2"
                        >
                          <Eye className="h-4 w-4" />
                          View Details
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {intakeInvitations.length === 0 && (
              <Card className="border-slate-200">
                <CardContent className="py-12 text-center">
                  <Mail className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="font-space-grotesk text-lg mb-2">No intake invitations sent</h3>
                  <p className="text-slate-600">
                    Send intake forms to clients to gather detailed information for grant writing.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* View Intake Dialog */}
      <Dialog open={viewIntakeDialogOpen} onOpenChange={setViewIntakeDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Intake Form Details</DialogTitle>
            <DialogDescription>
              Client information collected through the intake form.
            </DialogDescription>
          </DialogHeader>
          
          {selectedIntake && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-slate-700">Client</p>
                  <p className="text-slate-600">{selectedIntake.client_name}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-700">Completed</p>
                  <p className="text-slate-600">
                    {new Date(selectedIntake.completed_at).toLocaleDateString()}
                  </p>
                </div>
              </div>

              {selectedIntake.form_data && (
                <div className="space-y-4">
                  <div>
                    <p className="font-medium text-slate-700 mb-2">District Size</p>
                    <p className="text-slate-600">{selectedIntake.form_data.districtSize}</p>
                  </div>

                  <div>
                    <p className="font-medium text-slate-700 mb-2">Current Challenges</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedIntake.form_data.currentChallenges?.map((challenge: string, index: number) => (
                        <Badge key={index} className="bg-slate-200 text-slate-700">
                          {challenge}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="font-medium text-slate-700 mb-2">Grant Experience</p>
                    <p className="text-slate-600">{selectedIntake.form_data.grantExperience}</p>
                  </div>

                  <div>
                    <p className="font-medium text-slate-700 mb-2">Funding Priorities</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedIntake.form_data.fundingPriorities?.map((priority: string, index: number) => (
                        <Badge key={index} className="bg-indigo text-white">
                          {priority}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="font-medium text-slate-700 mb-2">Timeline</p>
                    <p className="text-slate-600">{selectedIntake.form_data.timeline}</p>
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <Button className="flex-1 gap-2">
                  <FileText className="h-4 w-4" />
                  Start Grant Research
                </Button>
                <Button variant="outline" className="gap-2">
                  <Download className="h-4 w-4" />
                  Export PDF
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Client Edit Dialog */}
      <ClientEditDialog 
        client={selectedClient}
        open={!!selectedClient}
        onOpenChange={(open) => !open && setSelectedClient(null)}
        onClientUpdate={() => {
          loadClientsData();
          setSelectedClient(null);
        }}
      />
    </div>
  );
}

// Client Edit Dialog Component
interface ClientEditDialogProps {
  client: Client | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onClientUpdate: () => void;
}

function ClientEditDialog({ client, open, onOpenChange, onClientUpdate }: ClientEditDialogProps) {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('basic');
  
  // Basic information form
  const [basicForm, setBasicForm] = useState({
    name: '',
    email: '',
    district: '',
    phone: '',
    title: '',
    status: 'active' as 'active' | 'pending' | 'inactive',
    notes: ''
  });

  // Organization details from intake form
  const [orgForm, setOrgForm] = useState({
    districtSize: '',
    studentCount: '',
    annualBudget: '',
    organizationType: '',
    demographics: '',
    location: ''
  });

  // Funding and challenges
  const [fundingForm, setFundingForm] = useState({
    currentChallenges: [] as string[],
    grantExperience: '',
    fundingPriorities: [] as string[],
    timeline: '',
    budgetNeeds: '',
    previousGrants: ''
  });

  // Success metrics and goals
  const [goalsForm, setGoalsForm] = useState({
    successMetrics: [] as string[],
    measurementMethods: '',
    partnerships: '',
    communityImpact: '',
    longTermGoals: ''
  });

  useEffect(() => {
    if (client) {
      setBasicForm({
        name: client.name || '',
        email: client.email || '',
        district: client.district || '',
        phone: client.phone || '',
        title: client.title || '',
        status: client.status || 'active',
        notes: client.notes || ''
      });

      // Load intake form data if available
      // In a real app, this would come from the intake form data
      setOrgForm({
        districtSize: 'Medium (1,000-5,000 students)',
        studentCount: '2,500',
        annualBudget: '$25M',
        organizationType: 'Public School District',
        demographics: '65% Free/Reduced Lunch',
        location: 'Urban'
      });

      setFundingForm({
        currentChallenges: ['Funding shortfalls', 'Technology gaps', 'Infrastructure needs'],
        grantExperience: 'Some experience',
        fundingPriorities: ['STEM programs', 'Special education', 'Technology upgrades'],
        timeline: 'Within 6 months',
        budgetNeeds: '$500K - $1M',
        previousGrants: 'Title I, IDEA, E-rate'
      });

      setGoalsForm({
        successMetrics: ['Student achievement scores', 'Technology usage rates', 'Teacher satisfaction'],
        measurementMethods: 'Pre/post assessments, surveys, usage analytics',
        partnerships: 'Local universities, community organizations',
        communityImpact: 'Improved educational outcomes for underserved populations',
        longTermGoals: 'Become a model district for technology integration'
      });
    }
  }, [client]);

  const handleSave = async () => {
    if (!client) return;

    setLoading(true);
    try {
      // For now, we'll work in demo mode since the backend endpoints aren't implemented
      // In a full implementation, this would make an actual API call
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      toast.success('Client information updated successfully! (Demo mode)');
      onClientUpdate();
    } catch (error: any) {
      console.error('Error updating client:', error);
      toast.error('Failed to update client information');
    } finally {
      setLoading(false);
    }
  };

  const challengeOptions = [
    'Funding shortfalls',
    'Technology gaps',
    'Infrastructure needs',
    'Teacher retention',
    'Student achievement',
    'Special education resources',
    'Transportation issues',
    'Facility maintenance',
    'Curriculum updates',
    'Professional development'
  ];

  const priorityOptions = [
    'STEM programs',
    'Special education',
    'Technology upgrades',
    'Infrastructure improvements',
    'Professional development',
    'Student support services',
    'Arts programs',
    'Athletics',
    'Early childhood education',
    'Career and technical education'
  ];

  const metricsOptions = [
    'Student achievement scores',
    'Graduation rates',
    'Technology usage rates',
    'Teacher satisfaction',
    'Parent engagement',
    'Attendance rates',
    'College readiness',
    'Career placement',
    'Community involvement',
    'Budget efficiency'
  ];

  if (!client) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="flex items-center gap-2">
            <Edit className="h-5 w-5" />
            Edit Client Profile
          </DialogTitle>
          <DialogDescription>
            Update comprehensive client information including intake form details
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <div className="px-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="organization">Organization</TabsTrigger>
              <TabsTrigger value="funding">Funding Needs</TabsTrigger>
              <TabsTrigger value="goals">Goals & Metrics</TabsTrigger>
            </TabsList>
          </div>

          <div className="flex-1 overflow-y-auto px-6 pb-6">
            <TabsContent value="basic" className="mt-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Contact Name</Label>
                  <Input
                    id="edit-name"
                    value={basicForm.name}
                    onChange={(e) => setBasicForm(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-sky-50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-title">Title</Label>
                  <Input
                    id="edit-title"
                    value={basicForm.title}
                    onChange={(e) => setBasicForm(prev => ({ ...prev, title: e.target.value }))}
                    className="bg-sky-50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-email">Email Address</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={basicForm.email}
                    onChange={(e) => setBasicForm(prev => ({ ...prev, email: e.target.value }))}
                    className="bg-sky-50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-phone">Phone Number</Label>
                  <Input
                    id="edit-phone"
                    value={basicForm.phone}
                    onChange={(e) => setBasicForm(prev => ({ ...prev, phone: e.target.value }))}
                    className="bg-sky-50"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-district">School District</Label>
                <Input
                  id="edit-district"
                  value={basicForm.district}
                  onChange={(e) => setBasicForm(prev => ({ ...prev, district: e.target.value }))}
                  className="bg-sky-50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-status">Status</Label>
                <Input
                  id="edit-status"
                  value={basicForm.status}
                  onChange={(e) => setBasicForm(prev => ({ ...prev, status: e.target.value as any }))}
                  className="bg-sky-50"
                  placeholder="active, pending, or inactive"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-notes">Notes</Label>
                <Textarea
                  id="edit-notes"
                  value={basicForm.notes}
                  onChange={(e) => setBasicForm(prev => ({ ...prev, notes: e.target.value }))}
                  className="bg-sky-50 min-h-24"
                  placeholder="Additional notes about this client..."
                />
              </div>
            </TabsContent>

            <TabsContent value="organization" className="mt-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="districtSize">District Size</Label>
                  <Input
                    id="districtSize"
                    value={orgForm.districtSize}
                    onChange={(e) => setOrgForm(prev => ({ ...prev, districtSize: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., Medium (1,000-5,000 students)"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="studentCount">Student Count</Label>
                  <Input
                    id="studentCount"
                    value={orgForm.studentCount}
                    onChange={(e) => setOrgForm(prev => ({ ...prev, studentCount: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., 2,500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="annualBudget">Annual Budget</Label>
                  <Input
                    id="annualBudget"
                    value={orgForm.annualBudget}
                    onChange={(e) => setOrgForm(prev => ({ ...prev, annualBudget: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., $25M"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="organizationType">Organization Type</Label>
                  <Input
                    id="organizationType"
                    value={orgForm.organizationType}
                    onChange={(e) => setOrgForm(prev => ({ ...prev, organizationType: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., Public School District"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="demographics">Student Demographics</Label>
                  <Input
                    id="demographics"
                    value={orgForm.demographics}
                    onChange={(e) => setOrgForm(prev => ({ ...prev, demographics: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., 65% Free/Reduced Lunch"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location Type</Label>
                  <Input
                    id="location"
                    value={orgForm.location}
                    onChange={(e) => setOrgForm(prev => ({ ...prev, location: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="Urban, Suburban, or Rural"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="funding" className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label>Current Challenges</Label>
                <Textarea
                  value={fundingForm.currentChallenges.join(', ')}
                  onChange={(e) => setFundingForm(prev => ({ 
                    ...prev, 
                    currentChallenges: e.target.value.split(', ').filter(c => c.trim())
                  }))}
                  className="bg-sky-50 min-h-20"
                  placeholder="Enter challenges separated by commas..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="grantExperience">Grant Experience</Label>
                  <Input
                    id="grantExperience"
                    value={fundingForm.grantExperience}
                    onChange={(e) => setFundingForm(prev => ({ ...prev, grantExperience: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., Some experience"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timeline">Timeline</Label>
                  <Input
                    id="timeline"
                    value={fundingForm.timeline}
                    onChange={(e) => setFundingForm(prev => ({ ...prev, timeline: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., Within 6 months"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Funding Priorities</Label>
                <Textarea
                  value={fundingForm.fundingPriorities.join(', ')}
                  onChange={(e) => setFundingForm(prev => ({ 
                    ...prev, 
                    fundingPriorities: e.target.value.split(', ').filter(p => p.trim())
                  }))}
                  className="bg-sky-50 min-h-20"
                  placeholder="Enter priorities separated by commas..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="budgetNeeds">Budget Needs</Label>
                  <Input
                    id="budgetNeeds"
                    value={fundingForm.budgetNeeds}
                    onChange={(e) => setFundingForm(prev => ({ ...prev, budgetNeeds: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., $500K - $1M"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="previousGrants">Previous Grants</Label>
                  <Input
                    id="previousGrants"
                    value={fundingForm.previousGrants}
                    onChange={(e) => setFundingForm(prev => ({ ...prev, previousGrants: e.target.value }))}
                    className="bg-sky-50"
                    placeholder="e.g., Title I, IDEA, E-rate"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="goals" className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label>Success Metrics</Label>
                <Textarea
                  value={goalsForm.successMetrics.join(', ')}
                  onChange={(e) => setGoalsForm(prev => ({ 
                    ...prev, 
                    successMetrics: e.target.value.split(', ').filter(m => m.trim())
                  }))}
                  className="bg-sky-50 min-h-20"
                  placeholder="Enter metrics separated by commas..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="measurementMethods">Measurement Methods</Label>
                <Textarea
                  id="measurementMethods"
                  value={goalsForm.measurementMethods}
                  onChange={(e) => setGoalsForm(prev => ({ ...prev, measurementMethods: e.target.value }))}
                  className="bg-sky-50 min-h-20"
                  placeholder="How will you measure success..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="partnerships">Key Partnerships</Label>
                <Textarea
                  id="partnerships"
                  value={goalsForm.partnerships}
                  onChange={(e) => setGoalsForm(prev => ({ ...prev, partnerships: e.target.value }))}
                  className="bg-sky-50 min-h-20"
                  placeholder="Existing or planned partnerships..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="communityImpact">Community Impact</Label>
                <Textarea
                  id="communityImpact"
                  value={goalsForm.communityImpact}
                  onChange={(e) => setGoalsForm(prev => ({ ...prev, communityImpact: e.target.value }))}
                  className="bg-sky-50 min-h-20"
                  placeholder="Expected impact on the community..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="longTermGoals">Long-term Goals</Label>
                <Textarea
                  id="longTermGoals"
                  value={goalsForm.longTermGoals}
                  onChange={(e) => setGoalsForm(prev => ({ ...prev, longTermGoals: e.target.value }))}
                  className="bg-sky-50 min-h-20"
                  placeholder="Long-term vision and goals..."
                />
              </div>
            </TabsContent>
          </div>
        </Tabs>

        <div className="flex justify-end gap-2 p-6 border-t border-slate-200">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={loading} className="gap-2">
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}