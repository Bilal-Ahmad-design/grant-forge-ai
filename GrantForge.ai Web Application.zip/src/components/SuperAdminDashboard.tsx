import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Building2, 
  Activity,
  UserCheck,
  UserX,
  DollarSign,
  Loader2,
  BarChart3,
  PieChart as PieIcon
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

interface SuperAdminDashboardProps {
  user: User;
}

interface UserMetrics {
  totalUsers: number;
  activeUsers: number;
  inactiveUsers: number;
  totalOrganizations: number;
  totalSecuredValue: number;
  avgSecuredValuePerUser: number;
  newUsersThisMonth: number;
  activeUsersThisMonth: number;
}

interface RoleDistribution {
  role: string;
  count: number;
  percentage: number;
  color: string;
}

interface OrganizationSummary {
  id: string;
  name: string;
  userCount: number;
  activeUsers: number;
  lastActivity: string;
  totalSecuredValue: number;
  status: 'active' | 'inactive' | 'trial';
}

interface UserGrowthData {
  month: string;
  totalUsers: number;
  activeUsers: number;
  newUsers: number;
  securedValue: number;
}

export function SuperAdminDashboard({ user }: SuperAdminDashboardProps) {
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('last12months');
  
  // User-focused data
  const [userMetrics, setUserMetrics] = useState<UserMetrics>({
    totalUsers: 0,
    activeUsers: 0,
    inactiveUsers: 0,
    totalOrganizations: 0,
    totalSecuredValue: 0,
    avgSecuredValuePerUser: 0,
    newUsersThisMonth: 0,
    activeUsersThisMonth: 0
  });

  const [roleDistribution, setRoleDistribution] = useState<RoleDistribution[]>([]);
  const [organizationSummary, setOrganizationSummary] = useState<OrganizationSummary[]>([]);
  const [userGrowthData, setUserGrowthData] = useState<UserGrowthData[]>([]);

  useEffect(() => {
    loadUserData();
  }, [selectedPeriod]);

  const loadUserData = async () => {
    try {
      setLoading(true);
      
      // Mock data for demonstration - replace with actual API calls
      const mockUserMetrics: UserMetrics = {
        totalUsers: 952, // Increased from 847
        activeUsers: 734, // Increased from 623
        inactiveUsers: 218, // Decreased inactive users
        totalOrganizations: 178, // Increased from 156
        totalSecuredValue: 32800000, // Significantly increased from 24.5M to 32.8M
        avgSecuredValuePerUser: 34453, // Increased from 28922
        newUsersThisMonth: 89, // Increased from 67
        activeUsersThisMonth: 734
      };

      const mockRoleDistribution: RoleDistribution[] = [
        { role: 'Super Admin', count: 4, percentage: 0.4, color: '#0E2A47' },
        { role: 'Admin', count: 52, percentage: 5.5, color: '#2B5EA5' },
        { role: 'Senior Writer', count: 186, percentage: 19.5, color: '#F5A524' },
        { role: 'Junior Writer', count: 710, percentage: 74.6, color: '#2BB673' }
      ];

      const mockOrganizationSummary: OrganizationSummary[] = [
        {
          id: 'org1',
          name: 'Propel Grant Solutions',
          userCount: 18, // Increased from 12
          activeUsers: 16, // Increased from 9
          lastActivity: '2024-12-09',
          totalSecuredValue: 1850000, // Increased from 1.2M
          status: 'active'
        },
        {
          id: 'org2',
          name: 'EduGrant Partners',
          userCount: 14, // Increased from 8
          activeUsers: 12, // Increased from 6
          lastActivity: '2024-12-08',
          totalSecuredValue: 1320000, // Increased from 850K
          status: 'active'
        },
        {
          id: 'org3',
          name: 'Grant Writing Associates',
          userCount: 22, // Increased from 15
          activeUsers: 19, // Increased from 12
          lastActivity: '2024-12-07',
          totalSecuredValue: 780000, // Increased from 450K
          status: 'active' // Changed from trial to active
        },
        {
          id: 'org4',
          name: 'Strategic Funding Solutions',
          userCount: 11, // Increased from 6
          activeUsers: 9, // Increased from 2
          lastActivity: '2024-12-05', // More recent activity
          totalSecuredValue: 420000, // Increased from 180K
          status: 'active' // Changed from inactive to active
        }
      ];

      const mockUserGrowthData: UserGrowthData[] = [
        { month: 'Jan 2024', totalUsers: 421, activeUsers: 312, newUsers: 28, securedValue: 1450000 },
        { month: 'Feb 2024', totalUsers: 465, activeUsers: 348, newUsers: 44, securedValue: 1750000 },
        { month: 'Mar 2024', totalUsers: 512, activeUsers: 385, newUsers: 47, securedValue: 2120000 },
        { month: 'Apr 2024', totalUsers: 563, activeUsers: 425, newUsers: 51, securedValue: 2580000 },
        { month: 'May 2024', totalUsers: 619, activeUsers: 468, newUsers: 56, securedValue: 3050000 },
        { month: 'Jun 2024', totalUsers: 682, activeUsers: 518, newUsers: 63, securedValue: 3620000 },
        { month: 'Jul 2024', totalUsers: 748, activeUsers: 572, newUsers: 66, securedValue: 4280000 },
        { month: 'Aug 2024', totalUsers: 821, activeUsers: 631, newUsers: 73, securedValue: 4950000 },
        { month: 'Sep 2024', totalUsers: 895, activeUsers: 692, newUsers: 74, securedValue: 5720000 },
        { month: 'Oct 2024', totalUsers: 967, activeUsers: 748, newUsers: 72, securedValue: 6580000 },
        { month: 'Nov 2024', totalUsers: 1034, activeUsers: 798, newUsers: 67, securedValue: 7450000 },
        { month: 'Dec 2024', totalUsers: 1121, activeUsers: 867, newUsers: 87, securedValue: 8420000 }
      ];

      setUserMetrics(mockUserMetrics);
      setRoleDistribution(mockRoleDistribution);
      setOrganizationSummary(mockOrganizationSummary);
      setUserGrowthData(mockUserGrowthData);

    } catch (error) {
      console.error('Error loading user data:', error);
      toast.error('Failed to load user analytics');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`;
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`;
    }
    return `$${amount.toLocaleString()}`;
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(0)}K`;
    }
    return num.toLocaleString();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-emerald';
      case 'trial': return 'text-amber';
      case 'inactive': return 'text-slate-500';
      default: return 'text-slate-500';
    }
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      'active': 'bg-emerald text-white',
      'trial': 'bg-amber text-navy',
      'inactive': 'bg-slate-500 text-white'
    };
    return colors[status as keyof typeof colors] || 'bg-slate-500 text-white';
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center min-h-96">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-indigo mx-auto mb-4" />
            <p className="text-slate-600">Loading user analytics...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">Super Admin Dashboard</h1>
          <p className="text-slate-600">User analytics and platform overview</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last30days">Last 30 Days</SelectItem>
              <SelectItem value="last3months">Last 3 Months</SelectItem>
              <SelectItem value="last6months">Last 6 Months</SelectItem>
              <SelectItem value="last12months">Last 12 Months</SelectItem>
              <SelectItem value="thisyear">This Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Key User Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-indigo/20 bg-indigo/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Users</p>
                <p className="text-2xl font-bold text-indigo">
                  {formatNumber(userMetrics.totalUsers)}
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-emerald" />
                  <span className="text-xs text-emerald">+{userMetrics.newUsersThisMonth} this month (+32% growth)</span>
                </div>
              </div>
              <Users className="h-8 w-8 text-indigo" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald/20 bg-emerald/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Active Users</p>
                <p className="text-2xl font-bold text-emerald">
                  {formatNumber(userMetrics.activeUsers)}
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <Activity className="h-3 w-3 text-emerald" />
                  <span className="text-xs text-emerald">
{((userMetrics.activeUsers / userMetrics.totalUsers) * 100).toFixed(1)}% active (+15% MoM)
                  </span>
                </div>
              </div>
              <UserCheck className="h-8 w-8 text-emerald" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-amber/20 bg-amber/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Secured Value</p>
                <p className="text-2xl font-bold text-amber">
                  {formatCurrency(userMetrics.totalSecuredValue)}
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-emerald" />
                  <span className="text-xs text-emerald">+28% vs last quarter</span>
                </div>
              </div>
              <DollarSign className="h-8 w-8 text-amber" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Avg Value Per User</p>
                <p className="text-2xl font-bold text-navy">
                  {formatCurrency(userMetrics.avgSecuredValuePerUser)}
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <Building2 className="h-3 w-3 text-indigo" />
                  <span className="text-xs text-emerald">{userMetrics.totalOrganizations} orgs (+19% growth)</span>
                </div>
              </div>
              <BarChart3 className="h-8 w-8 text-navy" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              User Growth & Value
            </CardTitle>
            <CardDescription>Total users and secured value over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={userGrowthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" tickFormatter={(value) => formatCurrency(value)} />
                <Tooltip 
                  formatter={(value: any, name: string) => {
                    if (name === 'securedValue') return [formatCurrency(value), 'Secured Value'];
                    return [formatNumber(value), name];
                  }}
                />
                <Legend />
                <Area yAxisId="left" type="monotone" dataKey="totalUsers" stackId="1" stroke="#2B5EA5" fill="#2B5EA5" fillOpacity={0.6} name="Total Users" />
                <Area yAxisId="left" type="monotone" dataKey="activeUsers" stackId="2" stroke="#2BB673" fill="#2BB673" fillOpacity={0.6} name="Active Users" />
                <Line yAxisId="right" type="monotone" dataKey="securedValue" stroke="#F5A524" strokeWidth={3} name="Secured Value" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Role Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieIcon className="h-5 w-5" />
              User Role Distribution
            </CardTitle>
            <CardDescription>Breakdown of user roles across platform</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center mb-6">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={roleDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="count"
                  >
                    {roleDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: any) => [value, 'Users']} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2">
              {roleDistribution.map((role) => (
                <div key={role.role} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: role.color }} />
                    <span className="text-sm font-medium">{role.role}</span>
                  </div>
                  <span className="text-sm text-slate-600">{role.count} ({role.percentage}%)</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Organizations Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Organization Summary</CardTitle>
          <CardDescription>Overview of all organizations and their performance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {organizationSummary.map((org) => (
              <div key={org.id} className="border border-slate-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-medium text-navy">{org.name}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge className={getStatusBadge(org.status)}>
                        {org.status}
                      </Badge>
                      <span className="text-sm text-slate-600">
                        {org.userCount} users ({org.activeUsers} active)
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-emerald">{formatCurrency(org.totalSecuredValue)}</p>
                    <p className="text-sm text-slate-600">secured value</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-slate-500">Total Users</p>
                    <p className="font-medium">{org.userCount}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Active Users</p>
                    <p className="font-medium text-emerald">{org.activeUsers}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Last Activity</p>
                    <p className="font-medium">{new Date(org.lastActivity).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Status</p>
                    <p className={`font-medium ${getStatusColor(org.status)}`}>
                      {org.status}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}