import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Target, 
  Clock,
  Award,
  FileText,
  AlertCircle,
  Download
} from 'lucide-react';
import { kpis, teamPerformance, clientMetrics, alerts } from './data/adminData';

export function Analytics() {
  const [timeRange, setTimeRange] = useState('30d');

  const iconMap = {
    DollarSign,
    Users,
    Award,
    Clock,
    Target
  };

  const getEfficiencyColor = (efficiency: number) => {
    if (efficiency >= 90) return 'text-emerald';
    if (efficiency >= 80) return 'text-amber';
    return 'text-red-500';
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertCircle className="h-4 w-4 text-amber" />;
      case 'success': return <Award className="h-4 w-4 text-emerald" />;
      case 'info': return <FileText className="h-4 w-4 text-indigo" />;
      default: return <AlertCircle className="h-4 w-4 text-slate-600" />;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">Analytics</h1>
          <p className="text-slate-600">Monitor team performance, track time automatically, and view organizational KPIs</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {kpis.map((kpi, index) => {
          const Icon = iconMap[kpi.icon as keyof typeof iconMap];
          return (
            <Card key={index} className="border-slate-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <Icon className={`h-8 w-8 ${kpi.color}`} />
                  <Badge className={`${
                    kpi.trend === 'up' ? 'bg-emerald/20 text-emerald' : 'bg-red-100 text-red-700'
                  }`}>
                    {kpi.trend === 'up' ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                    {kpi.change}
                  </Badge>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-slate-600 mb-1">{kpi.title}</h3>
                  <p className="text-2xl font-bold text-navy mb-1">{kpi.value}</p>
                  <p className="text-xs text-slate-500">{kpi.period}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Team Performance */}
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle className="font-space-grotesk">Team Performance</CardTitle>
            <CardDescription>Individual grant writer metrics and efficiency</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {teamPerformance.map((member, index) => (
                <div key={index} className="p-4 border border-slate-200 rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-navy">{member.name}</h4>
                      <p className="text-sm text-slate-600">{member.role}</p>
                    </div>
                    <Badge className={`${getEfficiencyColor(member.efficiency)} bg-transparent border`}>
                      {member.efficiency}% efficient
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-slate-600">Grants</p>
                      <p className="font-medium">{member.grants}</p>
                    </div>
                    <div>
                      <p className="text-slate-600">Value</p>
                      <p className="font-medium text-emerald">{member.value}</p>
                    </div>
                    <div>
                      <p className="text-slate-600">Win Rate</p>
                      <p className="font-medium">{member.winRate}%</p>
                    </div>
                    <div>
                      <p className="text-slate-600">Avg Time</p>
                      <p className="font-medium">{member.avgTime}</p>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Win Rate</span>
                      <span>{member.winRate}%</span>
                    </div>
                    <Progress value={member.winRate} className="h-2" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Client Metrics & Alerts */}
        <div className="space-y-6">
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="font-space-grotesk">Client Portfolio</CardTitle>
              <CardDescription>Active clients and relationship health</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {clientMetrics.map((client, index) => (
                  <div key={index} className="p-3 border border-slate-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${client.color}`} />
                        <h4 className="font-medium text-navy text-sm">{client.name}</h4>
                      </div>
                      <Badge className={`text-xs ${
                        client.status === 'Active' ? 'bg-emerald text-white' : 'bg-amber text-navy'
                      }`}>
                        {client.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <p className="text-slate-600">Grants</p>
                        <p className="font-medium">{client.grants}</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Value</p>
                        <p className="font-medium text-emerald">{client.value}</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Satisfaction</p>
                        <p className="font-medium">{client.satisfaction}%</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Alerts */}
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="font-space-grotesk">Recent Alerts</CardTitle>
              <CardDescription>System notifications and updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {alerts.map((alert, index) => (
                  <div key={index} className="flex gap-3 p-3 border border-slate-200 rounded-lg">
                    {getAlertIcon(alert.type)}
                    <div className="flex-1">
                      <h4 className="font-medium text-navy text-sm">{alert.title}</h4>
                      <p className="text-xs text-slate-600 mt-1">{alert.message}</p>
                      <p className="text-xs text-slate-500 mt-2">{alert.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}