import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Settings, 
  Shield, 
  Mail, 
  Database, 
  Bell,
  Globe,
  Lock,
  Save,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Users,
  Calendar,
  BarChart3,
  HardDrive,
  Trash2
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { apiRequest } from '../utils/supabase/client';
import { manualCacheClear } from '../utils/cache/useCacheInit';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'super-admin' | 'admin' | 'senior-writer' | 'junior-writer';
  organization: string;
}

interface SuperAdminSettingsProps {
  user: User;
  onNavigate?: (page: string) => void;
}

export function SuperAdminSettings({ user, onNavigate }: SuperAdminSettingsProps) {
  const [loading, setLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Platform Settings
  const [platformSettings, setPlatformSettings] = useState({
    siteName: 'GrantForge.ai',
    maintenanceMode: false,
    allowSignups: true,
    requireEmailVerification: true,
    sessionTimeout: 8, // hours
    maxFileSize: 10, // MB
    enableBranding: true
  });

  // Email Settings
  const [emailSettings, setEmailSettings] = useState({
    smtpEnabled: true,
    fromEmail: 'noreply@grantforge.ai',
    fromName: 'GrantForge.ai',
    replyToEmail: 'support@grantforge.ai',
    enableNotifications: true,
    enableReports: true,
    enableAlerts: true
  });

  // Security Settings
  const [securitySettings, setSecuritySettings] = useState({
    enableTwoFactor: false,
    passwordMinLength: 8,
    passwordComplexity: true,
    sessionSecurity: 'standard',
    ipWhitelist: '',
    enableAuditLog: true,
    dataRetention: 365 // days
  });

  // Analytics Settings
  const [analyticsSettings, setAnalyticsSettings] = useState({
    enableTracking: true,
    enablePerformanceMetrics: true,
    enableErrorReporting: true,
    dataExportFormat: 'csv',
    reportFrequency: 'monthly',
    enableRealTimeUpdates: true
  });

  const handleSaveSettings = async (settingsType: string, settings: any) => {
    setLoading(true);
    setSaveSuccess(false);

    try {
      // For now, we'll work in demo mode since the backend endpoints aren't implemented
      // In a full implementation, this would make an actual API call
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setSaveSuccess(true);
      toast.success(`${settingsType} settings updated successfully! (Demo mode)`);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error: any) {
      console.error(`Error updating ${settingsType} settings:`, error);
      toast.error(`Failed to update ${settingsType} settings`);
    } finally {
      setLoading(false);
    }
  };

  const handleResetToDefaults = () => {
    setPlatformSettings({
      siteName: 'GrantForge.ai',
      maintenanceMode: false,
      allowSignups: true,
      requireEmailVerification: true,
      sessionTimeout: 8,
      maxFileSize: 10,
      enableBranding: true
    });
    toast.success('Settings reset to defaults');
  };

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-space-grotesk">Platform Settings</h1>
          <p className="text-slate-600">Configure platform-wide settings and preferences</p>
        </div>
        <div className="flex items-center gap-3">
          {saveSuccess && (
            <div className="flex items-center gap-2 text-emerald">
              <CheckCircle className="h-4 w-4" />
              <span className="text-sm">Settings saved</span>
            </div>
          )}
          {onNavigate && (
            <Button variant="outline" onClick={() => onNavigate('dashboard')}>
              Back to Dashboard
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="platform" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="platform" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Platform
          </TabsTrigger>
          <TabsTrigger value="cache" className="flex items-center gap-2">
            <HardDrive className="h-4 w-4" />
            Cache
          </TabsTrigger>
          <TabsTrigger value="email" className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Lock className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        {/* Platform Settings */}
        <TabsContent value="platform" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                General Platform Settings
              </CardTitle>
              <CardDescription>
                Configure basic platform behavior and features
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name</Label>
                  <Input
                    id="siteName"
                    value={platformSettings.siteName}
                    onChange={(e) => setPlatformSettings(prev => ({ ...prev, siteName: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sessionTimeout">Session Timeout (hours)</Label>
                  <Select 
                    value={platformSettings.sessionTimeout.toString()} 
                    onValueChange={(value) => setPlatformSettings(prev => ({ ...prev, sessionTimeout: parseInt(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">2 hours</SelectItem>
                      <SelectItem value="4">4 hours</SelectItem>
                      <SelectItem value="8">8 hours</SelectItem>
                      <SelectItem value="12">12 hours</SelectItem>
                      <SelectItem value="24">24 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxFileSize">Max File Size (MB)</Label>
                  <Select 
                    value={platformSettings.maxFileSize.toString()} 
                    onValueChange={(value) => setPlatformSettings(prev => ({ ...prev, maxFileSize: parseInt(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 MB</SelectItem>
                      <SelectItem value="10">10 MB</SelectItem>
                      <SelectItem value="25">25 MB</SelectItem>
                      <SelectItem value="50">50 MB</SelectItem>
                      <SelectItem value="100">100 MB</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Platform Features</h4>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Maintenance Mode</Label>
                      <p className="text-sm text-slate-600">Prevent user access while updating the platform</p>
                    </div>
                    <Switch
                      checked={platformSettings.maintenanceMode}
                      onCheckedChange={(checked) => setPlatformSettings(prev => ({ ...prev, maintenanceMode: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Allow New Signups</Label>
                      <p className="text-sm text-slate-600">Allow new users to register for accounts</p>
                    </div>
                    <Switch
                      checked={platformSettings.allowSignups}
                      onCheckedChange={(checked) => setPlatformSettings(prev => ({ ...prev, allowSignups: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Require Email Verification</Label>
                      <p className="text-sm text-slate-600">Users must verify their email before accessing the platform</p>
                    </div>
                    <Switch
                      checked={platformSettings.requireEmailVerification}
                      onCheckedChange={(checked) => setPlatformSettings(prev => ({ ...prev, requireEmailVerification: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Enable Branding</Label>
                      <p className="text-sm text-slate-600">Show GrantForge.ai branding throughout the platform</p>
                    </div>
                    <Switch
                      checked={platformSettings.enableBranding}
                      onCheckedChange={(checked) => setPlatformSettings(prev => ({ ...prev, enableBranding: checked }))}
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={handleResetToDefaults}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Reset to Defaults
                </Button>
                <Button onClick={() => handleSaveSettings('platform', platformSettings)} disabled={loading}>
                  {loading ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-r-transparent mr-2" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  Save Platform Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cache Management */}
        <TabsContent value="cache" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="h-5 w-5" />
                Cache Management
              </CardTitle>
              <CardDescription>
                Manage browser cache and performance optimization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <HardDrive className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-blue-900 mb-1">About Cache Management</h4>
                      <p className="text-sm text-blue-700 mb-3">
                        GrantForge.ai automatically manages browser cache to ensure optimal performance. 
                        The system clears cache automatically when:
                      </p>
                      <ul className="text-sm text-blue-700 space-y-1 list-disc list-inside">
                        <li>App version changes</li>
                        <li>More than 24 hours have passed since last clear</li>
                        <li>Authentication errors occur</li>
                        <li>Manual clearing is requested</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <RefreshCw className="h-4 w-4 text-indigo" />
                        <span className="font-medium">Automatic Cache Clearing</span>
                      </div>
                      <p className="text-sm text-slate-600">
                        Cache is automatically cleared on app startup when needed to prevent loading issues.
                      </p>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-emerald" />
                        <span className="text-emerald">Active</span>
                      </div>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Trash2 className="h-4 w-4 text-amber" />
                        <span className="font-medium">Manual Cache Clear</span>
                      </div>
                      <p className="text-sm text-slate-600">
                        Force clear all browser cache immediately if experiencing performance issues.
                      </p>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={manualCacheClear}
                        className="w-full"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Clear Cache Now
                      </Button>
                    </div>
                  </Card>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h4 className="font-medium">Cache Status Information</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <div className="font-medium text-slate-700 mb-1">App Version</div>
                      <div className="text-slate-600">v1.0.0</div>
                    </div>
                    
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <div className="font-medium text-slate-700 mb-1">Cache Strategy</div>
                      <div className="text-slate-600">Auto-managed</div>
                    </div>
                    
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <div className="font-medium text-slate-700 mb-1">Last Clear</div>
                      <div className="text-slate-600">
                        {localStorage.getItem('grantforge_last_cache_clear') 
                          ? new Date(parseInt(localStorage.getItem('grantforge_last_cache_clear') || '0')).toLocaleString()
                          : 'Never'
                        }
                      </div>
                    </div>
                  </div>
                </div>

                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Note:</strong> Manually clearing cache will refresh the page and may log you out. 
                    This should only be done if you're experiencing loading issues.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Email Settings */}
        <TabsContent value="email" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Email Configuration
              </CardTitle>
              <CardDescription>
                Configure email settings and notification preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="fromEmail">From Email</Label>
                  <Input
                    id="fromEmail"
                    type="email"
                    value={emailSettings.fromEmail}
                    onChange={(e) => setEmailSettings(prev => ({ ...prev, fromEmail: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fromName">From Name</Label>
                  <Input
                    id="fromName"
                    value={emailSettings.fromName}
                    onChange={(e) => setEmailSettings(prev => ({ ...prev, fromName: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="replyToEmail">Reply-To Email</Label>
                  <Input
                    id="replyToEmail"
                    type="email"
                    value={emailSettings.replyToEmail}
                    onChange={(e) => setEmailSettings(prev => ({ ...prev, replyToEmail: e.target.value }))}
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Email Features</h4>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>SMTP Enabled</Label>
                      <p className="text-sm text-slate-600">Enable email sending through SMTP</p>
                    </div>
                    <Switch
                      checked={emailSettings.smtpEnabled}
                      onCheckedChange={(checked) => setEmailSettings(prev => ({ ...prev, smtpEnabled: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>User Notifications</Label>
                      <p className="text-sm text-slate-600">Send system notifications to users</p>
                    </div>
                    <Switch
                      checked={emailSettings.enableNotifications}
                      onCheckedChange={(checked) => setEmailSettings(prev => ({ ...prev, enableNotifications: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Automated Reports</Label>
                      <p className="text-sm text-slate-600">Send automated monthly reports to clients</p>
                    </div>
                    <Switch
                      checked={emailSettings.enableReports}
                      onCheckedChange={(checked) => setEmailSettings(prev => ({ ...prev, enableReports: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>System Alerts</Label>
                      <p className="text-sm text-slate-600">Send alerts for system events and errors</p>
                    </div>
                    <Switch
                      checked={emailSettings.enableAlerts}
                      onCheckedChange={(checked) => setEmailSettings(prev => ({ ...prev, enableAlerts: checked }))}
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <Button onClick={() => handleSaveSettings('email', emailSettings)} disabled={loading}>
                  {loading ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-r-transparent mr-2" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  Save Email Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Security Configuration
              </CardTitle>
              <CardDescription>
                Configure security policies and access controls
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="passwordMinLength">Minimum Password Length</Label>
                  <Select 
                    value={securitySettings.passwordMinLength.toString()} 
                    onValueChange={(value) => setSecuritySettings(prev => ({ ...prev, passwordMinLength: parseInt(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="6">6 characters</SelectItem>
                      <SelectItem value="8">8 characters</SelectItem>
                      <SelectItem value="10">10 characters</SelectItem>
                      <SelectItem value="12">12 characters</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sessionSecurity">Session Security Level</Label>
                  <Select 
                    value={securitySettings.sessionSecurity} 
                    onValueChange={(value) => setSecuritySettings(prev => ({ ...prev, sessionSecurity: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic</SelectItem>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="high">High Security</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dataRetention">Data Retention (days)</Label>
                  <Select 
                    value={securitySettings.dataRetention.toString()} 
                    onValueChange={(value) => setSecuritySettings(prev => ({ ...prev, dataRetention: parseInt(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="180">180 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                      <SelectItem value="730">2 years</SelectItem>
                      <SelectItem value="1095">3 years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Security Features</h4>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Two-Factor Authentication</Label>
                      <p className="text-sm text-slate-600">Require 2FA for all user accounts</p>
                    </div>
                    <Switch
                      checked={securitySettings.enableTwoFactor}
                      onCheckedChange={(checked) => setSecuritySettings(prev => ({ ...prev, enableTwoFactor: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Password Complexity</Label>
                      <p className="text-sm text-slate-600">Require complex passwords with special characters</p>
                    </div>
                    <Switch
                      checked={securitySettings.passwordComplexity}
                      onCheckedChange={(checked) => setSecuritySettings(prev => ({ ...prev, passwordComplexity: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Audit Logging</Label>
                      <p className="text-sm text-slate-600">Log all user actions and system events</p>
                    </div>
                    <Switch
                      checked={securitySettings.enableAuditLog}
                      onCheckedChange={(checked) => setSecuritySettings(prev => ({ ...prev, enableAuditLog: checked }))}
                    />
                  </div>
                </div>
              </div>

              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Warning:</strong> Changing security settings may affect all users. Test changes in a development environment first.
                </AlertDescription>
              </Alert>

              <div className="flex justify-end pt-4">
                <Button onClick={() => handleSaveSettings('security', securitySettings)} disabled={loading}>
                  {loading ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-r-transparent mr-2" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  Save Security Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Settings */}
        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Analytics & Reporting
              </CardTitle>
              <CardDescription>
                Configure analytics tracking and reporting preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="dataExportFormat">Default Export Format</Label>
                  <Select 
                    value={analyticsSettings.dataExportFormat} 
                    onValueChange={(value) => setAnalyticsSettings(prev => ({ ...prev, dataExportFormat: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="csv">CSV</SelectItem>
                      <SelectItem value="xlsx">Excel (XLSX)</SelectItem>
                      <SelectItem value="pdf">PDF</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reportFrequency">Report Frequency</Label>
                  <Select 
                    value={analyticsSettings.reportFrequency} 
                    onValueChange={(value) => setAnalyticsSettings(prev => ({ ...prev, reportFrequency: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="annual">Annual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Analytics Features</h4>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Usage Tracking</Label>
                      <p className="text-sm text-slate-600">Track user activity and platform usage</p>
                    </div>
                    <Switch
                      checked={analyticsSettings.enableTracking}
                      onCheckedChange={(checked) => setAnalyticsSettings(prev => ({ ...prev, enableTracking: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Performance Metrics</Label>
                      <p className="text-sm text-slate-600">Monitor system performance and response times</p>
                    </div>
                    <Switch
                      checked={analyticsSettings.enablePerformanceMetrics}
                      onCheckedChange={(checked) => setAnalyticsSettings(prev => ({ ...prev, enablePerformanceMetrics: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Error Reporting</Label>
                      <p className="text-sm text-slate-600">Automatically report system errors and issues</p>
                    </div>
                    <Switch
                      checked={analyticsSettings.enableErrorReporting}
                      onCheckedChange={(checked) => setAnalyticsSettings(prev => ({ ...prev, enableErrorReporting: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Real-time Updates</Label>
                      <p className="text-sm text-slate-600">Enable real-time dashboard updates</p>
                    </div>
                    <Switch
                      checked={analyticsSettings.enableRealTimeUpdates}
                      onCheckedChange={(checked) => setAnalyticsSettings(prev => ({ ...prev, enableRealTimeUpdates: checked }))}
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <Button onClick={() => handleSaveSettings('analytics', analyticsSettings)} disabled={loading}>
                  {loading ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-r-transparent mr-2" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  Save Analytics Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}