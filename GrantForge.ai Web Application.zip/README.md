
  # GrantForge.ai Web Application

  This is a code bundle for GrantForge.ai Web Application. The original project is available at https://www.figma.com/design/EtqfVaVUrtqdNIrIyIpEAj/GrantForge.ai-Web-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  